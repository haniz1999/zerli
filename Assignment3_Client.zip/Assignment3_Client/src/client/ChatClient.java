// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

package client;

import java.io.IOException;
import java.util.ArrayList;

import common.Branch;
import common.BranchManager;
import common.BranchWorker;
import common.ChatIF;
import common.Complaint;
import common.ComplaintsDataReports;
import common.CreditCard;
import common.Customer;
import common.IncomeDataReport;
import common.IncomeQuarterDataReports;
import common.Item;
import common.ItemsWithImage;
import common.OrderDataReport;
import common.Orders;
import common.Products;
import common.Report;
import common.ReportAndItsBranches;
import common.Survey;
import common.SurveyAnswer;
import common.TranslateMessage;
import common.Users;
import ocsf.client.AbstractClient;


public class ChatClient extends AbstractClient {
	// Instance variables **********************************************
	/**
	 * The interface type variable. It allows the implementation of the display
	 * method in the client.
	 * 
	 * @author Laith Sadik  & Othamn & Majd zbedat & Rani & Hani
 *
	 */
	ChatIF clientUI;
	public static boolean awaitResponse = false;
	public static Users user;
	public static ArrayList<ItemsWithImage> itemList;
	public static ArrayList<Products> productList;
	public static ArrayList<Item> ItemList;
	public static ArrayList<Item> itemIncatalog;//// add by othman

	public static ArrayList<Report> reportsList;// add by Rani Rani
	public static ArrayList<ReportAndItsBranches> reportsAndBranchesList; // add by Rani
	public static ArrayList<Branch> branchesList; // add by Rani
	public static ArrayList<Users> userList; /// add by Majd Zbedat
	public static ArrayList<Users> regestirationList; /// add by Majd Zbedat newwwwwwwwwwwwwwwwwwwwwwwwwwwwww
	public static ArrayList<Users> deleteCustomer; /// add by Majd Zbedat
	public static ArrayList<Users> detailsCustomer; /// add by Majd Zbedat
	public static ArrayList<Users> editStatus; /// add by Majd Zbedat
	public static ArrayList<Users> editIsLoggedIn; // add by Majd Zbedat
	public static ArrayList<Users> workerList; // add by Majd Zbedat
	public static ArrayList<BranchWorker> branchWorker; // add by Majd Zbedat
	public static ArrayList<BranchManager> branchManagerList;

	////////////////////////////////////////////////////////////////////////////
	public static ArrayList<CreditCard> creditcardlist; // add by new Majd Zbedat in 29/5/2022
	/////////////////////////////////////////////////////////////////////////////

	public static ArrayList<Orders> ordersToConfirmList; // add by rani -------- updated 2.6
	public static ArrayList<Customer> customersList; // add by rani

	public static Boolean isSurveySaved; // add by rani 30.5
	public static BranchWorker branchWorkerById; // add by rani 31.5

	public static Boolean isBalanceAdded;// add by rani 3.6
	public static ArrayList<Survey> surveysList; // add by rani 4.6
	public static ArrayList<SurveyAnswer> surveysAnswersList; // add by rani 5.6
	public static ArrayList<Orders> listToGiveOrders;// laith
	public static Customer customer;

	/////////////////////////////////////////////////// add by majd in 4/6/2022
	public static ArrayList<Users> branchWorkerUserList;
	public static ArrayList<BranchWorker> branchWorkerByIdtoGetWorkerPosition;
	public static ArrayList<BranchWorker> editBranchWorkerStatuslist;
	public static ArrayList<Orders> OrdersDetailsForDeliveryArrayList;
	public static ArrayList<Customer> CustomeTotalPriceList;
	////////////////////////////////////////////////////////////////
	
	
	//add by othman 
	public static ArrayList<Complaint> processedcomplaints;////add by othman 
	public static ArrayList<Complaint> warncomplaints;////add by othman 
	public static ArrayList<Customer> listCustomer;//add by othman 
	
	
	
	
	
	///////////////////////////////////////////////
	///////////////////////////////////////////////
	//////////////////////////////////////////////////
	public static ArrayList<Object> objectList;//laith
    public static boolean checkIfThereIncome;//laith
    public static boolean checkIfThereOrder;//laith
    public static boolean checkIfThereComplaitns;//laith
    public static ArrayList<ComplaintsDataReports> quarterComplaintsReports;
	public static ArrayList<IncomeDataReport> incomeDataList;//laith
	public static boolean checkQuarterIncome;
	public static ArrayList<IncomeQuarterDataReports> secondQuarterIncomeReports;//laith
	public static ArrayList<IncomeQuarterDataReports> quarterIncomeReports;//laith
	public static ArrayList<OrderDataReport> OrderDataList;//laith
    ////////////////////////////////////////////////////////
    //////////////////////////////////////////////////
    /////////////////////////////////////////////

	public static boolean isSurveyAnswerWithPdfSavedSuccefully= false; // add by rani-hani 5.6

	
///////////////////////// line 39++ 

	// Constructors ****************************************************
	// Constructors ****************************************************

	/**
	 * Constructs an instance of the chat client.
	 *
	 * @param host     The server to connect to.
	 * @param port     The port number to connect on.
	 * @param clientUI The interface type variable.
	 */

	public ChatClient(String host, int port, ChatIF clientUI) throws IOException {
		super(host, port); // Call the superclass constructor
		this.clientUI = clientUI;
		// openConnection();
	}

	// Instance methods ************************************************

	/**
	 * This method handles all data that comes in from the server.
	 *
	 * @param msg The message from the server.
	 */
	public void handleMessageFromServer(Object msg) {
		awaitResponse = false;
		TranslateMessage translateMessage = (TranslateMessage) msg;

		switch (translateMessage.getTranslateMessageTybe()) {

		case CorrectIp:
			System.out.println("Correct ip");
			break;

		case checkUserLoggedIn:
			ChatClient.user = (Users) translateMessage.getTranslate();
			break;

		case CatalogViewItems:
			itemList = (ArrayList<ItemsWithImage>) translateMessage.getTranslate();
			break;

		case CatalogViewItem:
			ItemList = (ArrayList<Item>) translateMessage.getTranslate();
			break;

		case CatalogViewProducts:
			productList = (ArrayList<Products>) translateMessage.getTranslate();
			break;

		case DetailsItemsForCatalog:
			ItemList = (ArrayList<Item>) translateMessage.getTranslate();
			break;

		case FinishOrder:
			break;

		///////// laith

		case GiveOrdersForCustomer:
			this.listToGiveOrders = (ArrayList<Orders>) translateMessage.getTranslate();
			break;

		case GiveBalanceEmailCustomerType:
			this.customer = (Customer) translateMessage.getTranslate();
			break;

		case UpdateBalanceCustomerType:
			break;

		case ChangeOrderToCanceled:
			break;

		////////// laith
			
			
		case GetIncomeDataReport:
			this.incomeDataList = (ArrayList<IncomeDataReport>) translateMessage.getTranslate();
			break;
			
		case GetIncomeReadyReport:
			this.objectList = (ArrayList<Object>) translateMessage.getTranslate();
			break;
			
		case CheckIfThereIncomeReport:
			this.checkIfThereIncome = (boolean) translateMessage.getTranslate();
			break;
			
		case CheckIfThereOrdersReport:
			this.checkIfThereOrder = (boolean) translateMessage.getTranslate();
			break;
			
		case GetOrderReadyReport:
			this.objectList = (ArrayList<Object>) translateMessage.getTranslate();
			break;
			
		case GetOrderDataReport:
			this.OrderDataList = (ArrayList<OrderDataReport>) translateMessage.getTranslate(); 
			break;
			
		case CheckIfThereFirstQIncomeReport:
			this.checkQuarterIncome = (boolean) translateMessage.getTranslate();
			break;
			
		case GetReadyQuarterIncomeRerports:
			this.objectList = (ArrayList<Object>) translateMessage.getTranslate();
			break;
			
		case GetQuarterIncomeRerports:
			this.quarterIncomeReports= (ArrayList<IncomeQuarterDataReports>) translateMessage.getTranslate();
			break;
		case GetSecondQuarterIncomeRerports:
			this.secondQuarterIncomeReports= (ArrayList<IncomeQuarterDataReports>) translateMessage.getTranslate();
			break;
			
		case CheckIfThereComplaintsReport:
			this.checkIfThereComplaitns =  (boolean) translateMessage.getTranslate();
			break;
			
		case GetComplaintsDataReport:
			this.quarterComplaintsReports= (ArrayList<ComplaintsDataReports>) translateMessage.getTranslate();
			break;
			
		case GetComplaintsReadyReport:
			this.objectList = (ArrayList<Object>) translateMessage.getTranslate();
			break;
		////////// laith
///////////////////////
			
			
			
			
			
///////////////////////
		case ReportsList:
			reportsList = (ArrayList<Report>) translateMessage.getTranslate();
			System.out.println("hello from chatClient reportsList");
			break;

		case ReportsAndBranchesList:

			reportsAndBranchesList = (ArrayList<ReportAndItsBranches>) translateMessage.getTranslate();
			System.out.println("hello from chatClient reportsList");
			break;

//		case BranchesList:
//			branchesList = (ArrayList<Branch>) translateMessage.getTranslate(); 
//			for (Branch r : branchesList) {
//				System.out.println(r.getBranch_id() + r.getBranch_name() + r.getBranch_email()
//						+ r.getBranch_phoneNumber() + r.getBranch_revenueFee() + r.getBranch_statusInSystem());
//			}
//			break;
////////////////////////////////////////
/// add by Majd Zbedat
		case UserListStatus:
			userList = (ArrayList<Users>) translateMessage.getTranslate();
			break;
////////////////////////////////////////
/// add by Majd Zbedat
		case UserListRegistration:
			regestirationList = (ArrayList<Users>) translateMessage.getTranslate();
			break;
/////////////////////////
/// add by Majd Zbedat
		case DeleteCustomer:
			deleteCustomer = (ArrayList<Users>) translateMessage.getTranslate();
			break;
/////////////////////////////
// add by Majd Zbedat
		case getUserDetalts:
			detailsCustomer = (ArrayList<Users>) translateMessage.getTranslate();
			break;
//////////////////////////////
// add by Majd Zbedat
		case editStatus:
			editStatus = (ArrayList<Users>) translateMessage.getTranslate();
			System.out.println("yyyyyyyyyyyy");
			break;
///////////////////////////////////////////
// add by Majd Zbedat
		case AccountRegistration:
			editIsLoggedIn = (ArrayList<Users>) translateMessage.getTranslate();
			System.out.println("yyyyyyyyyyyy");
			break;



		case OrdersToConfirmList:
			ordersToConfirmList = (ArrayList<Orders>) translateMessage.getTranslate();
			break;

		case CustomersList:
			customersList = (ArrayList<Customer>) translateMessage.getTranslate();
			break;
		//////////////////////////////////////////
		// add by Majd Zbedat
		case WorkerList:
			workerList = (ArrayList<Users>) translateMessage.getTranslate();
			break;
//////////////////////////////////////////////////////
		// add by new Majd Zbedat in 29/5/22
		case CreditCard:
			creditcardlist = (ArrayList<CreditCard>) translateMessage.getTranslate();

			break;
		////////////// add by majd 30/5/2022
		case BranchManager:
			branchManagerList = (ArrayList<BranchManager>) translateMessage.getTranslate();
			break;

////add by new Majd Zbedat in 30/5/22
		case BranchWorker:
			branchWorker = (ArrayList<BranchWorker>) translateMessage.getTranslate();
			break;
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

/////////////////////////////////////////// add by rani 30.5/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////

		case AddSurvey:

			isSurveySaved = (Boolean) translateMessage.getTranslate();
			break;

/////////////////////////////////////////// add by rani 30.5/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////

/////////////////////////////////////////// add by rani 31.5/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////
		case GetBranchWorkerByUserId:
			branchWorkerById = (BranchWorker) translateMessage.getTranslate();
			System.out.println("check");
			System.out.println("the branch of ther worker " + branchWorkerById.getBranchName());
			break;

/////////////////////////////////////////// add by rani 31.5/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////

/////////////////////////////////////////// add by rani 3.6/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////
		case AddRefundToCustomerBalance:
			isBalanceAdded = (Boolean) translateMessage.getTranslate();

			break;
/////////////////////////////////////////// add by rani 3.6/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////

/////////////////////////////////////////// add by rani 4.6/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////
		case GetSurveysList:
			surveysList = (ArrayList<Survey>) translateMessage.getTranslate();
			break;
/////////////////////////////////////////// add by rani 4.6/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////

/////////////////////////////////////////// add by rani 5.6/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////
		case GetSurveysAnswersList:
			surveysAnswersList = (ArrayList<SurveyAnswer>) translateMessage.getTranslate();
			break;

		case SaveSurveyAnswer:
			surveysAnswersList = (ArrayList<SurveyAnswer>) translateMessage.getTranslate();
			break;
		case AddSurveySpecialPdf:
		      surveysAnswersList = (ArrayList<SurveyAnswer>) translateMessage.getTranslate();
		      if(!surveysAnswersList.isEmpty())
		        isSurveyAnswerWithPdfSavedSuccefully = true;
		      break;

/////////////////////////////////////////// add by rani 5.6/////////////////////////////////////
////////////////////////////////////////////                ////////////////////////////////////

		/////////////////// add by othman habib allh////////
		//////////////////////////////// add by othman //////////////
		case ProductListInCatalog:
			productList = (ArrayList<Products>) translateMessage.getTranslate();

			break;
		case Deleteproduct:
			break;

		case addProduct:
			break;
		case ItemListInCatalog:
			itemIncatalog = (ArrayList<Item>) translateMessage.getTranslate();
			break;
		case Deleteitem:
			break;
		case addItem:
			break;
		case addDiscountProduct:
			break;
		case addDiscountItem:
			break;
		//////////////////////////////// add by othman //////////////

		// block for Majd Zbedat create it in 1/6/22
		/////////////////////////////////////////////////
		//////////////////////////////////////
		///////////////////////////
		////////////////////
		/////////////
		///////
		////
		case BranchWorkerUser:
			branchWorkerUserList = (ArrayList<Users>) translateMessage.getTranslate();

		case BranchWorkerByIdtoGetWorkerPosition:
			branchWorkerByIdtoGetWorkerPosition = (ArrayList<BranchWorker>) translateMessage.getTranslate();
			break;
		case OrdersDetailsForDelivery:
			OrdersDetailsForDeliveryArrayList = (ArrayList<Orders>) translateMessage.getTranslate();
			break;

		case CustomeTotalPrice:
			CustomeTotalPriceList = (ArrayList<Customer>) translateMessage.getTranslate();
			break;

		///
		////
		///////
		////////
		///////////////
		//////////////////
		////////////////////////
		////////////////////////////////
		//////////////////////////////////////
			
		case registerComplaint:
			break;
		case complaintsprocessed:
			processedcomplaints=(ArrayList<Complaint>) translateMessage.getTranslate();
			break;
		case complaintswarn:
			warncomplaints=(ArrayList<Complaint>) translateMessage.getTranslate();
			break;
		case responseComplaint:
			break;
		case validcustomers:
			listCustomer=(ArrayList<Customer>) translateMessage.getTranslate();
			break;
			//////////////////////////////// add by othman //////////////

		default:
			break;
		}
		/*
		 * System.out.println("--> handleMessageFromServer");
		 * 
		 * 
		 * String st; st=msg.toString(); String[] result = st.split("\\s");
		 * s1.setId(result[0]); s1.setPName(result[1]); s1.setLName(result[2]);
		 * s1.setFc(new Faculty (result[3],result[4]));
		 */

	}

	/**
	 * This method handles all data coming from the UI
	 *
	 * @param message The message from the UI.
	 */

	public void handleMessageFromClientUI(Object message) {
		try {
			openConnection();// in order to send more than one message
			awaitResponse = true;
			sendToServer(message);
			// wait for response
			while (awaitResponse) {
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e) {
			clientUI.display("Could not send message to server: Terminating client." + e);
			quit();
		}
	}

	/**
	 * This method terminates the client.
	 */
	public void quit() {
		try {
			closeConnection();
		} catch (IOException e) {
		}
		System.exit(0);
	}
}
//End of ChatClient class
