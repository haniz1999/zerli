// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 
package client;
import java.io.IOException;
import java.net.InetAddress;

import common.ChatIF;
import common.TranslateMessage;
import common.TranslateMessageType;



/**
 * This class constructs the UI for a chat client.  It implements the
 * chat interface in order to activate the display() method.
 * Warning: Some of the code here is cloned in ServerConsole 
 *
 
 */
public class ClientController implements ChatIF 
{
  //Class variables *************************************************
  
  /**
   * The default port to connect on.
   */
   public static int DEFAULT_PORT = 5555;
  
  //Instance variables **********************************************
  
  /**
   * The instance of the client that created this ConsoleChat.
   */
  ChatClient client;
  private boolean flag1 = true;

  //Constructors ****************************************************

/**
 * Representing as a client controller to activate the display method
 * @param host  A string representing the host of the client
 * @param port  An int representing the port number
 */
  public ClientController(String host, int port) 
  {
    try 
    {
      client= new ChatClient(host, port, this);

     
    	 Object clientObj = InetAddress.getLocalHost().getHostAddress()+","
    		      +InetAddress.getLocalHost().getHostName()+","+"Connected";
    	  accept(new TranslateMessage(TranslateMessageType.ConnectToServer,clientObj));

      
      
    } 
    catch(IOException exception) 
    {
      System.out.println("Error: Can't setup connection!"+ " Terminating client.");
      System.exit(1);
    }
  }

  
  //Instance methods ************************************************
  
  /**
   * This method waits for input from the console.  Once it is 
   * received, it sends it to the client's message handler.
   */
  public void accept(Object obj) 
  {
	  client.handleMessageFromClientUI(obj);
  }
  
  /**
   * This method overrides the method in the ChatIF interface.  It
   * displays a message onto the screen.
   *
   * @param message The string to be displayed.
   */
  public void display(String message) 
  {
    System.out.println("> " + message);
  }
}
//End of ConsoleChat class
