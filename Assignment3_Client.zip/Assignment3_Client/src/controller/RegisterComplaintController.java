package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Complaint;
import common.ComplaintType;
import common.Customer;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing  a controller of the register compliant screen 
 * @author Othman Laith Sadik
 *
 */
public class RegisterComplaintController implements Initializable {
	/**
	 * Initialize the details of the compliant  
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
	//	List<String> hourArray = new ArrayList<String>();
	

		
	/*	final Date date = new Date();
		final int hour = date.getHours();
		final Callback<DatePicker, DateCell> disableDate = new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(final DatePicker param) {
				return new DateCell() {
					@Override
					public void updateItem(final LocalDate item, final boolean empty) {
						super.updateItem(item, empty);
						final LocalDate today = LocalDate.now();
						this.setDisable(empty || item.compareTo((ChronoLocalDate) today) < 0);
					}
				};
			}
		};
		this.comlaintdate_cmb.setDayCellFactory(disableDate);
		
		this.comlaintdate_cmb.setOnAction(event -> {
			boolean checkIfCustomerPickedCurrentDayForTheSupply = ((LocalDate) this.comlaintdate_cmb.getValue())
					.equals(LocalDate.now());
			hourArray.clear();
			this.hourcomobox.getItems().clear();
			if (checkIfCustomerPickedCurrentDayForTheSupply) {
				if (hour < 11) {
					for (int i = 13; i < 22; ++i) {
						hourArray.add(String.valueOf(String.valueOf(i)) +":" +date.getMinutes());
					}
				} else {
					for (int i = hour ; i < 22; ++i) {
						hourArray.add(String.valueOf(String.valueOf(i)) + ":" +date.getMinutes());
					}
				}
			} else {
				for (int i = 10; i < 22; ++i) {
					hourArray.add(String.valueOf(String.valueOf(i)) + ":" +date.getMinutes());
				}
			}
			this.hourcomobox.getItems().addAll((Collection<? extends String>) hourArray);
		});
*/
	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the register compliant
	 * @param primaryStage  A Stage representing the primary stage of the register compliant 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/RegisterComplaint.fxml"));
		Scene scene = new Scene(root);

		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ComplaintMainController obcc = new ComplaintMainController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the register compliant  screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
	
	@FXML
    private Text alert_txt;

    @FXML
    private TextField customerif_txtf;

    @FXML
    private TextArea detailscomplaint_txtarea;


    


/**
 * Saving the data 
 * @param event An ActionEvent representing the save button 
 */
	@FXML
	void save(ActionEvent event) {
		boolean flag = false;

		if (customerif_txtf.getText().isEmpty() || detailscomplaint_txtarea.getText().isEmpty()) {
			flag = true;
			alert_txt.setText("Please Fill all fields");
			alert_txt.setFill(Color.RED);
			alert_txt.setFont(Font.font("Arial", 14));
			alert_txt.setStyle("-fx-text-fill: red;");
		}
		if(!checktext(customerif_txtf.getText()))
		{
			flag = true;
			alert_txt.setText("Please Fill Valid ID Of Customer ");
			alert_txt.setFill(Color.RED);
			alert_txt.setFont(Font.font("Arial", 14));
			alert_txt.setStyle("-fx-text-fill: red;");
		}
		if(true)//check if the id of customer have an account 
		{
			flag=true;
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.validcustomers,null));
			for(Customer c1:ChatClient.listCustomer)
			{
				if(c1.getCustomerId().equals(customerif_txtf.getText()))
					flag=false;
			}
			if(flag==true)
			{
				alert_txt.setText("Please Fill Valid ID Of Customer that have account ");
				alert_txt.setFill(Color.RED);
				alert_txt.setFont(Font.font("Arial", 14));
				alert_txt.setStyle("-fx-text-fill: red;");
			}
		}

		if(!flag)
		{
			Date timenow=new Date();

			Complaint obj=new Complaint(ChatClient.user.getId(),customerif_txtf.getText(),timenow,detailscomplaint_txtarea.getText()
					,ComplaintType.valueOf("PROCESSING"),false);
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.registerComplaint,obj));
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			ComplaintMainController obcc = new ComplaintMainController();
			try {
				obcc.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
		
		
	}
	/**
	 * checking the fields if its fill in the true way
	 * @return true if the fields true else return false
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

}
