package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
/**
 * Representing as controller of the update screen 
 * @author Othman
 *
 */
public class ChooseToUpdatecontroller implements Initializable {

	private int initialX, initialY;
/**
 * Representing the starting screen for updating 
 * @param primaryStage A Stage representing the primary stage of the update
 * @throws Exception  thrown in case of erroe
 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ChooseToUpdate.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
/**
 * 
 * @param location
 * @param resources
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	@FXML
	private Button backbtn;

	@FXML
	private Button exitbtn;



	@FXML
	private Button updateitembtn;

	@FXML
	private Button updateproductbtn;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		MainMarketingWorkerController gui = new MainMarketingWorkerController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the updating screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) { 
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}


/**
 * Representing the update item screen 
 * @param event An ActionEvent representing the update item button
 */
	@FXML
	void updateitem(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		UpdateItemController gui = new UpdateItemController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Representing the update product screen 
	 * @param event An ActionEvent representing the update product button
	 */
	@FXML
	void updateproduct(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		UpdateProductsController gui = new UpdateProductsController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
