package controller;

import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.LocalDate;
import java.time.Year;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ComplaintsDataReports;
import common.IncomeDataReport;
import common.OrderDataReport;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the system reports screen 
 * @author Laith Sadik
 *
 */
public class ViewSystemReportsController implements Initializable {

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the system report 
	 * @param primaryStage  A Stage representing the primary stage of the system reports
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewSystemReport.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 * Initialize the details of the report 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.year1 = "";
		this.month1 = "";
		this.errorText.setFill(Color.RED);
		this.errorText.setFont(Font.font("Arial", 14));
		this.errorText.setStyle("-fx-text-fill: red;");
		this.errorText.setStyle("-fx-border-color: red");
		this.yearCB.setValue("Year");
		this.monthCB.setValue("Month");
		this.branchCB.setValue("Branch");
		this.quarterCB.setValue("Quarter");
		this.reportsCB.setValue("Reports");
		int i;
		Year y = Year.now();
		for (i = y.getValue(); i > 2000; --i) {
			this.yearCB.getItems().add("" + i);
		}
		for (i = 1; i < 13; ++i) {
			if (i < 10) {
				this.monthCB.getItems().add("0" + i);
				continue;
			}
			this.monthCB.getItems().add("" + i);
		}
		ArrayList<String> list = new ArrayList<>();
		list.add("Incomes");
		list.add("Orders");
		list.add("Performance");
		this.reportsCB.getItems().addAll(list);
		for (i = 1; i < 5; ++i) {
			this.quarterCB.getItems().add("" + i);
		}
		list.clear();
		list.add("NORTH");
		list.add("SOUTH");
		list.add("CENTER");
		this.branchCB.getItems().addAll(list);
		this.quarterCB.setDisable(true);

	}

	@FXML
	private Text errorText;

	@FXML
	private Button backBtn;

	@FXML
	private ComboBox<String> branchCB;

	@FXML
	private Button exitBtn;

	@FXML
	private ComboBox<String> monthCB;

	@FXML
	private ComboBox<String> quarterCB;

	@FXML
	private ComboBox<String> reportsCB;

	@FXML
	private Button viewReportBtn;

	@FXML
	private ComboBox<String> yearCB;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CEOMainController CEOVSR = new CEOMainController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Representing the branch 
 * @param event An ActionEvent representign the branch button 
 */
	@FXML
	void branch(ActionEvent event) {

	}
	/**
	 * Exit from the system reports screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
/**
 * Representing the month 
 * @param event An ActionEvent representign the  month selection
 */
	@FXML
	void month(ActionEvent event) {

	}
	/**
	 * Representing the quarter
	 * @param event An ActionEvent representign the  quarter selection
	 */
	@FXML
	void quarter(ActionEvent event) {

	}
	/**
	 * Representing the year 
	 * @param event An ActionEvent representign the  year selection
	 */
	@FXML
	void year(ActionEvent event) {

	}
/**
 * Representing the reports 
 * @param event An ActionEvent representign the reports button
 */
	@FXML
	void reports(ActionEvent event) {

		if (this.reportsCB.getValue().toString().equals("Performance")) {
			this.quarterCB.setDisable(false);
			this.monthCB.setDisable(true);
			this.branchCB.setDisable(true);
		} else {
			this.branchCB.setDisable(false);
			this.quarterCB.setDisable(true);
			this.monthCB.setDisable(false);
		}
	}

	public static String year1;
	public static String month1;
	public static String quarter1;
	static {
		year1 = "";
		month1 = "";
		quarter1 = "";
	}
/**
 * Viewing the report
 * @param event An ActionEvent representing the view report button 
 */
	@FXML
	void viewReport(ActionEvent event) {
		if (CheckFillingComboBox()) {
			if (this.reportsCB.getValue().toString().equals("Incomes")) {
				Object obj = this.branchCB.getValue() + "," + this.yearCB.getValue() + "," + this.monthCB.getValue();
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CheckIfThereIncomeReport, obj));
				if (!ChatClient.checkIfThereIncome) {
					this.errorText.setText("No Report Income In This Date And In This Branch");
				} else {
					obj = this.branchCB.getValue() + "," + this.yearCB.getValue() + "," + this.monthCB.getValue();
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetIncomeReadyReport, obj));

					if ((boolean) ChatClient.objectList.get(0) == false) {
						ArrayList<String> list = new ArrayList<String>();
						list.add(this.branchCB.getValue());
						list.add(this.yearCB.getValue());
						list.add(this.monthCB.getValue());
						ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetIncomeDataReport, list));
					} else {
						ChatClient.incomeDataList = new ArrayList<IncomeDataReport>();
						for (int i = 1; i < ChatClient.objectList.size(); i++) {
							ChatClient.incomeDataList.add((IncomeDataReport) ChatClient.objectList.get(i));
						}
					}
					this.year1 = this.yearCB.getValue();
					this.month1 = this.monthCB.getValue();
					Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					ViewIncomesReportsController viec = new ViewIncomesReportsController();
					try {
						viec.start(stage);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} else if (this.reportsCB.getValue().toString().equals("Orders")) {
				Object obj = this.branchCB.getValue() + "," + this.yearCB.getValue() + "," + this.monthCB.getValue();
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CheckIfThereOrdersReport, obj));
				if (!ChatClient.checkIfThereOrder) {
					this.errorText.setText("No Report Order In This Date And In This Branch");
				} else {

					obj = this.branchCB.getValue() + "," + this.yearCB.getValue() + "," + this.monthCB.getValue();
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetOrderReadyReport, obj));

					if ((boolean) ChatClient.objectList.get(0) == false) {
						ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetOrderDataReport, obj));
					} else {
						ChatClient.OrderDataList = new ArrayList<OrderDataReport>();
						for (int i = 1; i < ChatClient.objectList.size(); i++) {
							ChatClient.OrderDataList.add((OrderDataReport) ChatClient.objectList.get(i));
						}

						this.year1 = this.yearCB.getValue();
						this.month1 = this.monthCB.getValue();
						Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
						ViewOrdersReportsController viec = new ViewOrdersReportsController();
						try {
							viec.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}

				}

			} else if (this.reportsCB.getValue().toString().equals("Performance")) {

				Object obj = this.yearCB.getValue() + "," + this.quarterCB.getValue();
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CheckIfThereComplaintsReport, obj));
				if (!ChatClient.checkIfThereComplaitns) {
					this.errorText.setText("No Report Order In This Date And In This Quarter");
				} else {

					obj = this.yearCB.getValue() + "," + this.quarterCB.getValue();
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetComplaintsReadyReport, obj));

					if ((boolean) ChatClient.objectList.get(0) == false) {
						ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetComplaintsDataReport, obj));
					} else {
						ChatClient.quarterComplaintsReports = new ArrayList<ComplaintsDataReports>();
						for (int i = 1; i < ChatClient.objectList.size(); i++) {
							ChatClient.quarterComplaintsReports
									.add((ComplaintsDataReports) ChatClient.objectList.get(i));
						}
					} 
					this.year1 = this.yearCB.getValue();
					this.quarter1 = this.quarterCB.getValue();
					Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					ViewComplaintsReportsController viec = new ViewComplaintsReportsController();
					try {
						viec.start(stage);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

		}

	}
	/**
	 * checking the fields if its fill in the true way
	 * @return true if the fields true else return false
	 */
	private boolean CheckFillingComboBox() {
		if (this.reportsCB.getValue().toString().equals("Reports")) {
			this.errorText.setText("please Chose And Fill The Report fields!");
			return false;
		} else if (!((String) this.reportsCB.getValue()).equals("Performance")) {
			if (((String) this.yearCB.getValue()).equals("Year") && ((String) this.monthCB.getValue()).equals("Month")
					&& ((String) this.branchCB.getValue()).equals("Branch")) {
				this.errorText.setText("please Fill All The Fields!");
				return false;
			} else if ((((String) this.yearCB.getValue()).equals("Year")
					&& ((String) this.monthCB.getValue()).equals("Month"))) {
				this.errorText.setText("please Fill The Year And Month Fields!");
				return false;
			} else if ((((String) this.monthCB.getValue()).equals("Month")
					&& ((String) this.branchCB.getValue()).equals("Branch"))) {
				this.errorText.setText("please Fill The Month And Branch Fields!");
				return false;
			} else if ((((String) this.yearCB.getValue()).equals("Year")
					&& ((String) this.branchCB.getValue()).equals("Branch"))) {
				this.errorText.setText("Please Fill The Year And Branch Fields!");
				return false;
			} else if (((String) this.yearCB.getValue()).equals("Year")) {
				this.errorText.setText("Please Fill The Year Fields!");
				return false;
			} else if (((String) this.monthCB.getValue()).equals("Month")) {
				this.errorText.setText("Please Fill The Month Fields!");
				return false;
			} else if (((String) this.branchCB.getValue()).equals("Branch")) {
				this.errorText.setText("Please Fill The Branch Fields!");
				return false;
			}
		} else {
			if ((((String) this.yearCB.getValue()).equals("Year")
					&& ((String) this.quarterCB.getValue()).equals("Quarter"))) {
				this.errorText.setText("Please The Yaer And Quarter Fields!");
				return false;
			} else if (((String) this.yearCB.getValue()).equals("Year")) {
				this.errorText.setText("Please Fill The Year Fields!");
				return false;
			} else if (((String) this.quarterCB.getValue()).equals("Quarter")) {
				this.errorText.setText("Please Fill The Quarter Fields!");
				return false;
			}
		}
		return true;
	}

}
