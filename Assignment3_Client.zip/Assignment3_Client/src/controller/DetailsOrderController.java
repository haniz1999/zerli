package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.TypeOfDelivery;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DateCell;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.util.Callback;
/**
 * Representing a controller of the order details screen 
 * @author Laith Sadik
 *
 */
public class DetailsOrderController implements Initializable {

	/**
	 * Initialize the details of the order
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

	//	this.requestedDataDatePicker.setValue(LocalDate.now());
		this.requestedDataDatePicker.getEditor().setDisable(true);
		ArrayList<String> al = new ArrayList<String>();
		this.takeawayOrDeliveryCB.getItems().addAll(TypeOfDelivery.DELIVERY, TypeOfDelivery.TAKEAWAY);
		al.clear();
		al.add("NORTH");
		al.add("SOUTH");
		al.add("CENTER");
		this.branchSelectionCB.getItems().addAll(al.get(0), al.get(1),al.get(2));
		al.clear();
		final List<String> hourArray = new ArrayList<String>();
		final Date date = new Date();
		final int hour = date.getHours();
		final Callback<DatePicker, DateCell> disableDate = new Callback<DatePicker, DateCell>() {
			@Override
			public DateCell call(final DatePicker param) {
				return new DateCell() {
					@Override
					public void updateItem(final LocalDate item, final boolean empty) {
						super.updateItem(item, empty);
						final LocalDate today = LocalDate.now();
						this.setDisable(empty || item.compareTo((ChronoLocalDate) today) < 0);
					}
				};
			}
		};
		this.requestedDataDatePicker.setDayCellFactory(disableDate);
		if (hour < 10) {
			for (int i = 10; i <= 22; ++i) {
				hourArray.add(String.valueOf(String.valueOf(i)) + ":00");
			}
		} else {
			for (int i = hour + 1; i <= 22; ++i) {
				hourArray.add(String.valueOf(String.valueOf(i)) + ":00");
			}
		}
		this.RequestedTimeCB.getItems().addAll((Collection<? extends String>) hourArray);
		this.requestedDataDatePicker.setOnAction(event -> {
			boolean checkIfCustomerPickedCurrentDayForTheSupply = ((LocalDate) this.requestedDataDatePicker.getValue())
					.equals(LocalDate.now());
			hourArray.clear();
			this.RequestedTimeCB.getItems().clear();
			if (checkIfCustomerPickedCurrentDayForTheSupply) {
				if (hour < 11) {
					for (int i = 13; i < 22; ++i) {
						hourArray.add(String.valueOf(String.valueOf(i)) + ":00");
					}
				} else {
					for (int i = hour + 3; i < 22; ++i) {
						hourArray.add(String.valueOf(String.valueOf(i)) + ":00");
					}
				}
			} else {
				for (int i = 10; i < 22; ++i) {
					hourArray.add(String.valueOf(String.valueOf(i)) + ":00");
				}
			}
			this.RequestedTimeCB.getItems().addAll((Collection<String>) hourArray);
		});
	}

	private int initialX;
	private int initialY;
	/**
	 * Representing the screen of the primary screen of the order details
	 * @param primaryStage  A Stage representing the primary stage of the order details
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/DetailsOrderController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Filling Order Details");
		primaryStage.setScene(scene);

		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

    @FXML
    private Text fillErrorText;

	@FXML
	private ComboBox<String> RequestedTimeCB;

	@FXML
	private Button backBtn;

	@FXML
	private ComboBox<String> branchSelectionCB;

	@FXML
	private Button exitBtn;

	@FXML
	private TextArea greeting_txtarea;

	@FXML
	private Button nextBtn;

	@FXML
	private DatePicker requestedDataDatePicker;

	@FXML
	private ComboBox<TypeOfDelivery> takeawayOrDeliveryCB;

	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		CatalogOfPredefinedProductsController.order.setBranch(null);
		CatalogOfPredefinedProductsController.order.setGreeting(null);
		CatalogOfPredefinedProductsController.order.setOrderDeliveryDate(null);
		CatalogOfPredefinedProductsController.order.setTypeOfDelivery(null);

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ListOfAllProductsAndListsController cppc = new ListOfAllProductsAndListsController();
		try {
			cppc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}
	/**
	 * Exit from the order details screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
/**
 * Representing the next window
 * @param event An ActionEvent representing the next button
 */
	@FXML
	void next(ActionEvent event) {
		boolean flag = false;
		if (RequestedTimeCB.getValue() == null) {
			RequestedTimeCB.setStyle("-fx-border-color: red");
			this.fillErrorText.setText("Fill all the fields!");
			this.fillErrorText.setFill(Color.RED);
			this.fillErrorText.setFont(Font.font("Arial", 14));
			this.fillErrorText.setStyle("-fx-text-fill: red;");
			flag = true;
		}
		if (takeawayOrDeliveryCB.getValue() == null) {
			takeawayOrDeliveryCB.setStyle("-fx-border-color: red");
			this.fillErrorText.setText("Fill all the fields!");
			this.fillErrorText.setFill(Color.RED);
			this.fillErrorText.setFont(Font.font("Arial", 14));
			this.fillErrorText.setStyle("-fx-text-fill: red;");
			flag = true;
		}
		if (branchSelectionCB.getValue() == null) {
			branchSelectionCB.setStyle("-fx-border-color: red");
			this.fillErrorText.setText("Fill all the fields!");
			this.fillErrorText.setFill(Color.RED);
			this.fillErrorText.setFont(Font.font("Arial", 14));
			this.fillErrorText.setStyle("-fx-text-fill: red;");
			flag = true;
		}
		if (this.requestedDataDatePicker.getValue() == null) {
			this.requestedDataDatePicker.setStyle("-fx-border-color: red");
			this.fillErrorText.setText("Chose The Date Of The Order!");
			this.fillErrorText.setFill(Color.RED);
			this.fillErrorText.setFont(Font.font("Arial", 14));
			this.fillErrorText.setStyle("-fx-text-fill: red;");
			flag = true;
		}
		
		if (!flag) {
			if (takeawayOrDeliveryCB.getValue() == TypeOfDelivery.TAKEAWAY) {
				CatalogOfPredefinedProductsController.order.setTypeOfDelivery(TypeOfDelivery.TAKEAWAY);
			} else {
				CatalogOfPredefinedProductsController.order.setTypeOfDelivery(TypeOfDelivery.DELIVERY);
			}

			String date = ((LocalDate) this.requestedDataDatePicker.getValue())
					.format(DateTimeFormatter.ofPattern("yyyy/MM/dd"));
			String time = (String) this.RequestedTimeCB.getValue();
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			Date day = null;
			try {
				day = dateFormat.parse(String.valueOf(date) + " " + time + ":00");
			} catch (ParseException e) {
				e.printStackTrace();
			}
			CatalogOfPredefinedProductsController.order.setOrderDeliveryDate(day);
			CatalogOfPredefinedProductsController.order.setBranch(this.branchSelectionCB.getValue().toString());
			CatalogOfPredefinedProductsController.order.setGreeting(greeting_txtarea.getText());
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			switch (CatalogOfPredefinedProductsController.order.getTypeOfDelivery()) {
			case TAKEAWAY:
	
				TakeAwayController cmc = new TakeAwayController();
				try {
					cmc.start(stage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				break;
			case DELIVERY:
				DetailsDeliveryController cmc2 = new DetailsDeliveryController();
		        try {
		          cmc2.start(stage);
		        } catch (Exception e) {
		          // TODO Auto-generated catch block
		          e.printStackTrace();
		        }
				break;
			}
		}
	}
/**
 * representing the selection of the branch 
 * @param event An ActionEvent representing the ranch selection action 
 */
	@FXML
	void branchSelection(ActionEvent event) {

		branchSelectionCB.setStyle("-fx-border-color: black");
	}
/**
 * Request the data 
 * @param event An ActionEvent representing the request data button
 */
	@FXML
	void requestedData(ActionEvent event) {

	}
/**
 * Representing the take away delivery 
 * @param event An ActionEvent representing the take away button
 */
	@FXML
	void takeawayOrDelivery(ActionEvent event) {

		takeawayOrDeliveryCB.setStyle("-fx-border-color: black");

	}
/**
 * Representing the request time for delivery
 * @param event An ActionEvent representing the request time button
 */
	@FXML
	void RequestedTime(ActionEvent event) {
		RequestedTimeCB.setStyle("-fx-border-color: black");
	}

}
