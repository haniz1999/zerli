package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller displays a user registration for the branch manager
 * @author Majd Zbedat
 *
 */
public class BranchManagerUserRegistrationController implements Initializable{
	public static ObservableList<Users> registrationList;
	public static Users PrimaryKeyOfId1;


	private int initialX, initialY;
	    @FXML
	    private Button backBtn;

	    @FXML
	    private Button create;

	    @FXML
	    private Button exitBtn;
	    
	    @FXML
	    private Text Alarttxt;
	    
	    @FXML
	    private TableColumn<Users, String> First_name;

	    @FXML
	    private TableColumn<Users, String> Last_name;

	    @FXML
	    private TableView<Users> RegistrationTable;

	    @FXML
	    private TableColumn<Users, String> User_id;
	    /**
	     * Represents the back button controller 
	     * @param event  An ActionEvent representing the back click action
	     */
	    @FXML
	    void back(ActionEvent event) {
	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	BranchManagerMainController BMMC= new BranchManagerMainController();
			try {
				BMMC.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }
/**
 * Representing the create button action for user creating
 * @param event An ActionEvent representing the create button 
 */
	    @FXML
	    void createFunc(ActionEvent event) {
			 PrimaryKeyOfId1 = this.RegistrationTable.getSelectionModel().getSelectedItem();
			 if (PrimaryKeyOfId1 == null) {
				 Alarttxt.setText("Please select row");
				 Alarttxt.setFill(Color.RED);
				 Alarttxt.setFont(Font.font("Arial", 14));
			      Alarttxt.setStyle("-fx-text-fill: red;");
			 }
			 else {
				 Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			    	BranchManagerURCreateController BMURCC= new BranchManagerURCreateController();
					try {
						BMURCC.start(stage);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 }

		
			
		

	    }
		/**
		 * Representing the exit button controller for branch manager user registration screen
		 * exiting from the updating branch manager screen
		 * @param event An ActionEvent representing the exit's button
		 */ 
	    @FXML
	    void exit(ActionEvent event) {
			Object clientObj;
		    Object logout = ChatClient.user;
		    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		    try {
		      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
		          + "," + "Connected";
		      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		    } catch (UnknownHostException e) {
		      e.printStackTrace();
		    }
		    System.exit(0);
	    }

	 

	
/**
 * Representing the refresh button
 * @param event An ActionEvent representing the refresh button action
 */
		@FXML
		void refresh(ActionEvent event) {
			this.RegistrationTable.getItems().clear();
			initialize(null, null);
		}
	
	
		  /**
		  * Representing the Starting screen of the branch manageruser registration
		  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
		  * @throws IOException   An Exception that the method throws in station of exception
		  */
	    public void start(Stage stage) throws IOException {
			AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerUserRegistration.fxml"));
			Scene scene = new Scene(root);
			stage.setTitle("UsercRegistration");
			stage.setScene(scene);
			stage.show();

			scene.setOnMousePressed(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					scene.setCursor(Cursor.MOVE);
					initialX = (int) (stage.getX() - move.getScreenX());
					initialY = (int) (stage.getY() - move.getScreenY());
				}
			});

			scene.setOnMouseDragged(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					stage.setX(move.getScreenX() + initialX);
					stage.setY(move.getScreenY() + initialY);
				}
			});

			scene.setOnMouseReleased(move -> {
				scene.setCursor(Cursor.DEFAULT);
			});
		}
	    /**
	     * Initializing the details of the user's fields
	     */
		@Override
		public void initialize(URL location, ResourceBundle resources) {
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.UserListRegistration, null));
			this.User_id.setCellValueFactory(new PropertyValueFactory<Users, String>("id"));
			this.First_name.setCellValueFactory(new PropertyValueFactory<Users, String>("firstName"));
			this.Last_name.setCellValueFactory(new PropertyValueFactory<Users, String>("lastName"));
			registrationList = FXCollections.observableArrayList(ChatClient.regestirationList);
			RegistrationTable.setItems(registrationList);			
		}

}
