package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ClientController;
import client.ClientUI;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseButton;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * Representing a controller for the client connection screen
 * 
 * @author Laith Sadik
 *
 */
public class ClientConnectionController implements Initializable {
	public static boolean flagMove = true;

	@FXML
	private Button exitBtn;

	/**
	 * Exit from the client connection screen
	 * 
	 * @param event An ActionEvent representing the exit button action
	 */
	@FXML
	void exit(ActionEvent event) {
		System.exit(1);
	}

	int initialX, initialY;

	/**
	 * Representing the screen of the primary screen of the client connection
	 * 
	 * @param primaryStage A Stage representing the primary stage of the client
	 *                     connection
	 * @throws Exception thrown if an error happen
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ClientController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Client Configuration");
		if (ClientConnectionController.flagMove) {
			primaryStage.initStyle(StageStyle.UNDECORATED);
			ClientConnectionController.flagMove = false;
		}
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	/**
	 * Initialize the connection details
	 * 
	 * @param location  A URL representing the location
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	@FXML
	private Button confirmBtn;

	@FXML
	private TextField ip_txtf;

	/**
	 * Confirm the client connection action
	 * 
	 * @param event An ActioEvent representing the confirm button
	 */
	
	
	///////////////////////////////////////////////////////////// this function changed 7.6.2022 2:00:00
	@FXML
	void confirm(ActionEvent event) {
		String ip;

		ip = ip_txtf.getText();
		if (ip.trim().isEmpty()) {
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("Warning");
			alert.setHeaderText("server ip Text failed !!!");
			alert.setContentText("You must enter an id number");
			alert.showAndWait();
		} else { 

					ClientUI.chat = new ClientController(ip_txtf.getText(), ClientController.DEFAULT_PORT);

				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				WelcomeToZerliController login = new WelcomeToZerliController();
				try {
					login.start(stage);
				} catch (Exception e) {
					e.printStackTrace();
					System.exit(0);
				}

		}
	}

}
