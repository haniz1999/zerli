package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Date;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Complaint;
import common.ComplaintType;
import common.Item;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.text.Text;
/**
 * Representing a controller of the compliant details screen
 * @author Laith Sadik
 *
 */
public class DetailsComplaintController implements Initializable{
	public static ObservableList<Complaint> processingcomplaint;
public static String idCustomer,idcomplaint;
/**
 * Initialize the details of the customer 
 * @param location  A URL representing the location 
 * @param resources A ResourceBundle representing the resources
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		// TODO Auto-generated method stub
		if(!ComplaintMainController.warn)
		{
			
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.complaintsprocessed,null));
			
			this.idcomplaints.setCellValueFactory(new PropertyValueFactory<Complaint, String>("idcomplaint"));
			this.idworker.setCellValueFactory(new PropertyValueFactory<Complaint, String>("idWorker"));
			this.idcostumer.setCellValueFactory(new PropertyValueFactory<Complaint, String>("idCustomer"));
			this.date.setCellValueFactory(new PropertyValueFactory<Complaint, String>("datetotableview"));
			this.ComplaintsDetails.setCellValueFactory(new PropertyValueFactory<Complaint, String>("complaintDetail"));
			processingcomplaint = FXCollections.observableArrayList(ChatClient.processedcomplaints);
			complaintsTable.setItems(processingcomplaint);

		}
		else {
			ComplaintMainController.warn=false;
			this.idcomplaints.setCellValueFactory(new PropertyValueFactory<Complaint, String>("idcomplaint"));
			this.idworker.setCellValueFactory(new PropertyValueFactory<Complaint, String>("idWorker"));
			this.idcostumer.setCellValueFactory(new PropertyValueFactory<Complaint, String>("idCustomer"));
			this.date.setCellValueFactory(new PropertyValueFactory<Complaint, String>("datetotableview"));
			this.ComplaintsDetails.setCellValueFactory(new PropertyValueFactory<Complaint, String>("complaintDetail"));

			processingcomplaint = FXCollections.observableArrayList(ChatClient.warncomplaints);
			complaintsTable.setItems(processingcomplaint);
		}
		
	}
	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the compliant details
	 * @param primaryStage  A Stage representing the primary stage of the compliant details
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/DetailsComplaints.fxml"));
		Scene scene = new Scene(root);

		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

    @FXML
    private Text alert_txt;

	   @FXML
	    private TableColumn<Complaint, String> ComplaintsDetails;
	    @FXML
	    private TableView<Complaint> complaintsTable;

	    @FXML
	    private TableColumn<Complaint, String> date;

	    @FXML
	    private TableColumn<Complaint, String> idcomplaints;

	    @FXML
	    private TableColumn<Complaint, String> idcostumer;

	    @FXML
	    private TableColumn<Complaint, String> idworker;

	    @FXML
		void back(ActionEvent event) {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			ComplaintMainController obcc = new ComplaintMainController();
			try {
				obcc.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		/**
		 * Exit from the copliant details screen 
		 * @param event An ActionEvent representing the exit button action 
		 */
		@FXML
		void exit(ActionEvent event) {
			Object clientObj;
			Object logout = ChatClient.user;
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
			ChatClient.user.setLoggedIn(false);
			try {
				clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
						+ "," + "Connected";
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
			} catch (UnknownHostException e) {
				e.printStackTrace();
			}
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
			ChatClient.user.setLoggedIn(false);
			System.exit(0);
		}
		/**
		 * Representing the respone on compliant 
		 * @param event An ActionEvent representing the responeOnCompliant buuton 
		 */
	    @FXML
	    void responeOnComplaint(ActionEvent event) {
			if (this.complaintsTable.getSelectionModel().getSelectedItem() == null) {
				alert_txt.setText("Please select column");
				alert_txt.setFill(Color.RED);
				alert_txt.setFont(Font.font("Arial", 14));
				alert_txt.setStyle("-fx-text-fill: red;");
			}
			else {
				idCustomer=complaintsTable.getSelectionModel().getSelectedItem().getIdCustomer();
				idcomplaint=complaintsTable.getSelectionModel().getSelectedItem().getIdcomplaint();
				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				MonetaryCompensationController obcc = new MonetaryCompensationController();
				try {
					obcc.start(stage);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	    }

	}

