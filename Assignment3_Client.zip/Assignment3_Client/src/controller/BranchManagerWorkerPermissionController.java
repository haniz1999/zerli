package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing as controller of the branch manager to worker permission 
 * @author Majd Zbedat
 *
 */
public class BranchManagerWorkerPermissionController implements Initializable{

	private int initialX;

	private int initialY;
	
	 String send;
	private String CurrentStatus;

	@FXML
	private Text Alarttxt;

	@FXML
	private Button Back;

	@FXML
	private TextField Emailbtn;

	@FXML
	private Button Exit;

	@FXML
	private TextField First_Namebtn;

	@FXML
	private TextField ID;

	@FXML
	private TextField LastNamebtn;

	@FXML
	private TextField PhoneNumberbtn;

	@FXML
	private Button Save;

	@FXML
	private ComboBox<String > Status;
	/**
	 * Representing the back button
	 * @param event An ActionEvent representing the back button action
	 */
	@FXML
	void backFunction(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerWorkerManagementController BMWMC= new BranchManagerWorkerManagementController();
		try {
			BMWMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Representing the email text field 
 * @param event An ActionEvent representing the text field of the email
 */
	@FXML
	void emailFunction(ActionEvent event) {

	}
	/**
	 * Representing the exit button controller for branch manager income report screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
	void exitFunction(ActionEvent event) {
		Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
	}
	/**
	 * Representing the id text field 
	 * @param event An ActionEvent representing the text field of the id
	 */
	@FXML
	void idFunction(ActionEvent event) {

	}

	
	  
	
	/**
	 * Representing the phone number text field 
	 * @param event An ActionEvent representing the text field of the email
	 */
	@FXML
	void phoneNumberFunction(ActionEvent event) {

	}
/**
 * Representing the save button
 * @param event AnActionEvent representing the save button action
 */
	@FXML
	void saveFunction(ActionEvent event) {
		if(this.Status.getValue().equals(CurrentStatus)) {
    		Alarttxt.setText("it's current status!!");
			 Alarttxt.setFill(Color.RED);
			 Alarttxt.setFont(Font.font("Arial", 14));
		      Alarttxt.setStyle("-fx-text-fill: red;");
    	}
    	else {
       
		if(CurrentStatus.equals("PROFESSIONAL")) 
        	send = "NORMAL";
        
        	else 
        	    send = "PROFESSIONAL";

        Object Obj = BranchManagerWorkerManagementController.branchPrimaryKeyOfIdWorker.getId() + "," + send +",";
        ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.editBranchWorkerStatus,Obj));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        BranchManagerWorkerManagementController BMCMC = new BranchManagerWorkerManagementController();
		try {
			BMCMC.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	}
	}
	
	/**
	 * Representing the status text field 
	 * @param event An ActionEvent representing the text field of the status
	 */
	@FXML
	void statusFunction(ActionEvent event) {

	}
	  /**
	  * Representing the Starting screen of the branch manager worker permission
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */
	public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerBranchWorkerPermission.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("edit status");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
/**
 * Initialize the worker details
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		Object obj = BranchManagerWorkerManagementController.branchPrimaryKeyOfIdWorker.getId()+"," ;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.BranchWorkerUser, obj));
		this.Emailbtn.setText(ChatClient.branchWorkerUserList.get(0).getEmail());
		this.First_Namebtn.setText(ChatClient.branchWorkerUserList.get(0).getFirstName());
		this.ID.setText(ChatClient.branchWorkerUserList.get(0).getId());
		this.LastNamebtn.setText(ChatClient.branchWorkerUserList.get(0).getLastName());
		this.PhoneNumberbtn.setText(ChatClient.branchWorkerUserList.get(0).getPhoneNumber());
		Emailbtn.setDisable(true);
		First_Namebtn.setDisable(true);
		LastNamebtn.setDisable(true);
		ID.setDisable(true);
		PhoneNumberbtn.setDisable(true);
		Status.getItems().add("PROFESSIONAL");
	     Status.getItems().add("NORMAL");
	     Emailbtn.setFont(Font.font("default", 15));
	     First_Namebtn.setFont(Font.font("default", 15));
	     LastNamebtn.setFont(Font.font("default", 15));
	     ID.setFont(Font.font("default", 15));
	     PhoneNumberbtn.setFont(Font.font("default", 15));
	     
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.BranchWorkerByIdtoGetWorkerPosition, obj));

	      CurrentStatus = ChatClient.branchWorkerByIdtoGetWorkerPosition.get(0).getWorkerPosition();

	      Status.setValue(CurrentStatus);

	}

}






















