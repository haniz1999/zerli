package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Optional;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.CreditCard;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import utils.JavaMailUtil;
/**
 * Representing a controller displays the branch manager creating a user screen
 * @author Majd Zbedat
 *
 */
public class BranchManagerURCreateController implements Initializable{

	private int GotIt1=0,GotIt2=0;
	private String id;

    @FXML
    private TextField CreditCardNumberTxtf;

    @FXML
    private TextField CvvTxtf;

    @FXML
    private TextField EmailTxtf;

    @FXML
    private TextField ExpirationDateTxtf;

    @FXML
    private TextField FirstNameTxtf;

    @FXML
    private TextField IdTxtf;

    @FXML
    private TextField LastNameTxtf;

    @FXML
    private TextField PasswordTxtf;

    @FXML
    private TextField PhoneNumberTxtf;

    @FXML
    private Button backBtn;

    @FXML
    private Button helpBtn;

    @FXML
    private Button saveBtn;

    @FXML
    private TextField userNameTxtf;
    /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
    @FXML
    void back(ActionEvent event) {
    	
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerUserRegistrationController BMMC= new BranchManagerUserRegistrationController();
		try {
			BMMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

    }
	/**
	 * Representing the exit button controller for branch manager user creating screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exitFunction(ActionEvent event) {
    	Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
    }

   
    /**
     * Representing the save action to saves the user details
     * @param event An ActionEvent representing the save's click
     */
    @FXML
    void saveFunc(ActionEvent event) {
    	Object Obj = id + ",";
    	 ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.AccountRegistration,Obj));
    
         
 	 	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
 	 	BranchManagerUserRegistrationController BMCMC = new BranchManagerUserRegistrationController();
 	 	try {
			JavaMailUtil.sendMail(ChatClient.detailsCustomer.get(GotIt1).getEmail(), "User Creation", "your User succefully created");
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
 		try {
 			BMCMC.start(stage);
 		} catch (Exception e) {
 			// TODO Auto-generated catch block
 			e.printStackTrace();
 		}
    }
	
	
	
	private int initialX, initialY;
	  /**
	  * Representing the Starting screen of the branch manageruser creating
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */
	public void start(Stage stage) throws IOException {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerURCreate.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("User Create");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
    /**
     * Initializing the details of the user's fields
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.getUserDetalts, null));
		
		 String CheckById;
	      int flag=1,i=0,flag1=1,j=0;
	      CheckById = BranchManagerUserRegistrationController.PrimaryKeyOfId1.getId();
	      System.out.println(CheckById);
	      while(flag == 1) {
	    	 if( ChatClient.detailsCustomer.get(i).getId().equals(CheckById) ) {
	    		 GotIt1 = i;  
	    		 flag= 0;
	    	 }
	    	 i++;
	      }
	      
      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CreditCard, null));

  	      while(flag1 == 1) {
		    	 if( ChatClient.creditcardlist.get(j).getId().equals(CheckById) ) {
		    		 GotIt2 = j;  
		    		 flag1= 0;
		    	 }
		    	 j++;
		      }
	      
	      CreditCardNumberTxtf.setText(ChatClient.creditcardlist.get(GotIt2).getCreditCardNumber());
	      CvvTxtf.setText(ChatClient.creditcardlist.get(GotIt2).getCreditCardCvvCode());
	      ExpirationDateTxtf.setText(ChatClient.creditcardlist.get(GotIt2).getCreditCardValidDate());
	      EmailTxtf.setText(ChatClient.detailsCustomer.get(GotIt1).getEmail());
	      FirstNameTxtf.setText(ChatClient.detailsCustomer.get(GotIt1).getFirstName());
	      LastNameTxtf.setText(ChatClient.detailsCustomer.get(GotIt1).getLastName());
	       id = ChatClient.detailsCustomer.get(GotIt1).getId();
	      IdTxtf.setText(id);
	      PhoneNumberTxtf.setText(ChatClient.detailsCustomer.get(GotIt1).getPhoneNumber());	
	      PasswordTxtf.setText(ChatClient.detailsCustomer.get(GotIt1).getPassword());	
	      userNameTxtf.setText(ChatClient.detailsCustomer.get(GotIt1).getUsername());
	      FirstNameTxtf.setDisable(true);
	      LastNameTxtf.setDisable(true);
	      IdTxtf.setDisable(true);
	      PhoneNumberTxtf.setDisable(true);
	      EmailTxtf.setDisable(true);
	      userNameTxtf.setDisable(true);
	      PasswordTxtf.setDisable(true);
	      CreditCardNumberTxtf.setDisable(true);
	      CvvTxtf.setDisable(true);
	      ExpirationDateTxtf.setDisable(true);
//	      Status.getItems().add("CONFIRMED");
//	      Status.getItems().add("FROZEN");
//	      Emailbtn.setFont(Font.font("default", 15));
//	      First_Namebtn.setFont(Font.font("default", 15));
//	      LastNamebtn.setFont(Font.font("default", 15));
//	      ID.setFont(Font.font("default", 15));
//	      PhoneNumberbtn.setFont(Font.font("default", 15));
//	      CurrentStatus = ChatClient.detailsCustomer.get(GotIt).getStatusInSystem();
// 		  Status.setValue(CurrentStatus);
         		
	}
	
	

}

