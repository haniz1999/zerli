package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Orders;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import utils.JavaMailUtil;
/**
 * Representing a controller of the delivery customer screen 
 * @author USER
 *
 */
public class DeliveryToCustomerController implements Initializable{

	private static final String String = null;
	  int i=0,count=0;
	  double returnMonyToCustomer=0,currentBalance,newBalance,zero=0;
	  String moneyBack = "",EmaiOfCustomer,CustomerId,OrderId;


	public static ObservableList<Orders> OrdersDetailsForDeliveryList;

	
    @FXML
    private Text Alarttxt;

    @FXML
    private TableView<Orders> DeliveryTable;

//    @FXML
//    private TableColumn<Orders, String> OrderDeliveryDate;
    @FXML
    private TableColumn<Orders, Double> Price;

    @FXML
    private TableColumn<Orders, String> Order_Id;

    @FXML
    private TableColumn<Orders, String> Receiver_Name;

    @FXML
    private TableColumn<Orders, String> receiverAddress;

    @FXML
    private TableColumn<Orders, String> receiverPhoneNumber;
/**
 * Representing the complete delivery action 
 * @param event An ActionEvent representing the text fields
 */
    @FXML
    void CompleteFunc(ActionEvent event) {
   	 
	 if ( DeliveryTable.getSelectionModel().getSelectedItem()== null) {
		 Alarttxt.setText("Please select column");
		 Alarttxt.setFill(Color.RED);
		 Alarttxt.setFont(Font.font("Arial", 14));
	      Alarttxt.setStyle("-fx-text-fill: red;");
	 }
	 else {
		 Object obj;
		 obj = this.DeliveryTable.getSelectionModel().getSelectedItems().get(0).getOrderId() + ",";
		 Date date = this.DeliveryTable.getSelectionModel().getSelectedItems().get(0).getOrderDeliveryDate();
		 System.out.println();

		 
		 

		 
		 count = 0;
	    
          for(i =0; i < ChatClient.OrdersDetailsForDeliveryArrayList.size(); i++) {
       	   if(ChatClient.OrdersDetailsForDeliveryArrayList.get(i).getOrderId().equals(DeliveryTable.getSelectionModel().getSelectedItem().getOrderId())) {
       		   break;
       	   }
       	   else {
       		   count++;
       	   }
          }
          
          
        String DeliveryDate = "";
        		DeliveryDate = ChatClient.OrdersDetailsForDeliveryArrayList.get(count).getDateOfDelivery();
          
		 
          convertStringToDate(DeliveryDate);
		 
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.EditByDeliveryToCompleted, obj));
			
			
			
			
			                                  
			                  
			
			      
			
			
			
			 ///////////*********************************************************
			 Date thisDate = new Date();
			 SimpleDateFormat dateForm = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 System.out.println(dateForm.format(convertStringToDate(DeliveryDate)));
			 long minutes = convertStringToDate(DeliveryDate).getTime() / 60000;
			 System.out.println(minutes);
			 //////////////////***************************************************
			 
			 
			 /////////////////////////////////////////////**************************************
			 SimpleDateFormat dateForm1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			 System.out.println(dateForm1.format(thisDate));
			 long minutes1 = thisDate.getTime() / 60000;
			 System.out.println(minutes1);
			 /////////////////////////********************************************************
			 
			 
			 System.out.println(minutes - minutes1);
			 if((minutes - minutes1) < 0 ) {
				 Object obj1 = minutes1 + "";
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.EditByDeliveryToCompleted, obj));
					EmaiOfCustomer = ChatClient.OrdersDetailsForDeliveryArrayList.get(count).getCustomerEmail1();
					CustomerId = ChatClient.OrdersDetailsForDeliveryArrayList.get(count).getCustomerId1();
                    Object obj2 = CustomerId + ",";
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CustomeTotalPrice, obj2));
										
                     currentBalance = ChatClient.CustomeTotalPriceList.get(0).getTotalPrice();
					returnMonyToCustomer = ChatClient.OrdersDetailsForDeliveryArrayList.get(count).getPrice1();
                    newBalance = returnMonyToCustomer + currentBalance;

					Object obj3 = newBalance + "," + CustomerId + ",";
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ReturnMoney, obj3));

				 // mail to reject to sorry for late
					try {
						JavaMailUtil.sendMail(EmaiOfCustomer, "Apology letter", "We are sorry for the poor service,\n to express our regert, we refunded you all the money.\nWe hope that you will accept this compensation.");
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
			 }
			 else {
				 DeliveryTable.refresh();
			 }
			 
			OrderId = ChatClient.OrdersDetailsForDeliveryArrayList.get(count).getOrderId();
			
			Object obj4 = dateForm1.format(thisDate) + "," + OrderId + "," ;
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.actualSupplyDate, obj4));

			
			
			
			
	    initialize(null, null);

	 }
    }
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
    @FXML
    void back(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	DeliveryMainController BMWMC= new DeliveryMainController();
		try {
			BMWMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    /**
     * Exit from the customer delivery screen 
     * @param event An ActionEvent representing the exit button action 
     */
    @FXML
    void exit(ActionEvent event) {
    	Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
    }
    
    
    
    
    private int initialX, initialY;
    /**
     * Representing the screen of the primary screen of the customer delivery
     * @param primaryStage  A Stage representing the primary stage of the customer delivery
     * @throws Exception thrown if an error happen 
     */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/DeliveryToCustomer.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Delivery Details");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 * Initialize the details of the customer 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.OrdersDetailsForDelivery, null));
       //    System.out.println(ChatClient.OrdersDetailsForDeliveryArrayList.get(0).getDateOfDelivery() + " 555555555555555555555555555555555555555");		
     

		this.Order_Id.setCellValueFactory(new PropertyValueFactory<Orders, String>("OrderId"));
		this.Receiver_Name.setCellValueFactory(new PropertyValueFactory<Orders, String>("receiverName"));
		this.receiverPhoneNumber.setCellValueFactory(new PropertyValueFactory<Orders, String>("receiverPhoneNumber"));
		this.receiverAddress.setCellValueFactory(new PropertyValueFactory<Orders, String>("receiverAddress"));
		this.Price.setCellValueFactory(new PropertyValueFactory<Orders, Double>("Price1"));

	//	this.OrderDeliveryDate.setCellValueFactory(new PropertyValueFactory<Orders,Date>("OrderDeliveryDate"));
		OrdersDetailsForDeliveryList = FXCollections.observableArrayList(ChatClient.OrdersDetailsForDeliveryArrayList);
		DeliveryTable.setItems(OrdersDetailsForDeliveryList);			
	}
	
	
	/**
	 * Converting a string datetime to a Date 
	 * @param datetime A string representing the string to convert  
	 * @return A Date converting from string 
	 */
	 public Date convertStringToDate(String datetime) {
	        if (datetime != null) {
	            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	            try {
	                Date d = dateFormat.parse(datetime);
	                return d;
	            }
	            catch (ParseException e) {
	                e.printStackTrace();
	            }
	        }
	        return null;
	    }
	
	/**
	 * Representing the refresh action 
	 * @param event An ActionEvent representing the refresh button 
	 */
		@FXML
		void refresh(ActionEvent event) {
			this.DeliveryTable.getItems().clear();
			initialize(null, null);
		}
	
	
	}
    
    
    
    
    


