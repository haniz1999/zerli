package controller;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * Representing a controller of the marketing department worker main screen 
 * @author Othman
 *
 */
public class MarkatingDepartmentWorkerMainController implements Initializable{

	
	private int initialX,initialY;
	/**
	 * Representing the screen of the primary screen of the marketing department worker 
	 * @param primaryStage  A Stage representing the primary stage of the marketing worker
	 * @throws Exception thrown if an error happen 
	 */ 
	public void start(Stage primaryStage) throws Exception {	
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CustomerMainController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();	
		
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}
}
