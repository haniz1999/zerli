package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Orders;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the customer main screen 
 * @author Laith Sadiks
 *
 */
public class CustomerMainController implements Initializable {

	public static boolean backToDeliveryOrTakeAwayl;

	static {
		CatalogOfSelfdefinedItemsController.order = new Orders();
		CatalogOfPredefinedProductsController.order = new Orders();
		backToDeliveryOrTakeAwayl = false;
	}

	public static boolean viewOrOrderFlag = false;
	@FXML
	private Button logoutBtn;

	@FXML
	private Button myOrderListBtn;

	@FXML
	private Button orderByCatalogBtn;

	@FXML
	private Text userNameText;

	@FXML
	private Button viewOnCatalogBtn;
	/**
	 * log out from the customer main  screen 
	 * @param event An ActionEvent representing the log out button 
	 */
	@FXML
	void logout(ActionEvent event) {

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@FXML
	private Button exitBtn;
	/**
	 * Exit from the customer main screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit1(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
/**
 * Representing the customer's list of orders 
 * @param event An ActionEvent representing the my order list button
 */
	@FXML
	void myOrderList(ActionEvent event) {

		CustomerMainController.viewOrOrderFlag = false;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ListOfOrdersForCustomerController obcc = new ListOfOrdersForCustomerController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Representing the catalog to order
 * @param event An ActionEvent representing the order by catalog button
 */
	@FXML
	void orderByCatalog(ActionEvent event) {
		CustomerMainController.viewOrOrderFlag = false;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		OrderByCatalogController obcc = new OrderByCatalogController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
/**
 * Representing the catalog 
 * @param event An ActionEvent representing the view catalog button
 */
	@FXML
	void viewOnCatalog(ActionEvent event) {
		CustomerMainController.viewOrOrderFlag = true;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		OrderByCatalogController obcc = new OrderByCatalogController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Initialize the details of the customer 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		if(ChatClient.user.getStatusInSystem().equals("FROZEN")) {
			this.myOrderListBtn.setDisable(true);
			this.orderByCatalogBtn.setDisable(true);
			this.viewOnCatalogBtn.setDisable(true);
		}

		userNameText.setText(ChatClient.user.getFirstName() + " " + ChatClient.user.getFirstName());
	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the customer
	 * @param primaryStage  A Stage representing the primary stage of the customer
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CustomerMainController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

}
