package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;
import java.util.concurrent.TimeUnit;

import client.ChatClient;
import client.ClientUI;
import common.Orders;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import utils.JavaMailUtil;
/**
 *  Representing a controller that displays a screen for the branch manager orders screens 
 * @author Rani Khori
 *
 */
public class BranchManagerBranchOrdersController implements Initializable {
	
	public static ObservableList<Orders> ordersToApproveList;

	
	private int initialX, initialY;

    @FXML
    private TableView<Orders> ordersTable;
    
    @FXML
    private TableColumn<Orders, String> branchID_col;

    @FXML
    private TableColumn<Orders, String> customerUserID_col;

    @FXML
    private TableColumn<Orders, String> orderNumber_col;

    @FXML
    private TableColumn<Orders, String> status_col;

    @FXML
    private TableColumn<Orders, Double> totalPrice_col;
    
    @FXML
    private TableColumn<Orders, String> date_col;
    
    

	 @FXML
	 private ImageView Exit;


	    @FXML
	    private Button backBtn;

	    @FXML
	    private Button confirmBtn;

	    @FXML
	    private Button helpBtn;
	    

	    @FXML
	    private Text message_txt;
	    /**
	     * Represents the back button controller 
	     * @param event  An ActionEvent representing the back click action
	     */
	    @FXML
	    void back(ActionEvent event) {
	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	BranchManagerMainController BMMC= new BranchManagerMainController();
			try {
				BMMC.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    }


		/**
		 * Representing the exit button controller for 
		 * exiting from the updating item screen
		 * @param event An ActionEvent representing the exit's button
		 */
	    @FXML
	    void exit(ActionEvent event) {
	    	Object clientObj;
		    Object logout = ChatClient.user;
		    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		    try {
		      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
		          + "," + "Connected";
		      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		    } catch (UnknownHostException e) {
		      e.printStackTrace();
		    }
		    System.exit(0);
	    }

	   

	    @FXML
	    void help(ActionEvent event) {

	    }
/**
 * Representing the confirm button controller for confirming the action
 * @param event            An ActionEvent representing the confirm button 
 * @throws ParseException  Signals that an error has been reached unexpectedly while parsing.
 */
	    @FXML
	    void confirm(ActionEvent event) throws ParseException {
	    	Orders selected_order = ordersTable.getSelectionModel().getSelectedItem();
	        String customer_email = null;

	    	
			if(selected_order == null) {
				message_txt.setText("You must select an order first");
				return;
			}
			
			
			String s = selected_order.getStatus().toString();
			
			if(s.equals("PENDING_APPROVAL")) {
				
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ChangeOrderStatusToApproved, selected_order));
				
				ordersToApproveList = FXCollections.observableArrayList(ChatClient.ordersToConfirmList);
				ordersTable.setItems(ordersToApproveList);
				ordersTable.refresh();
				
		        message_txt.setText("The order you have selected is succefully confirmed");

		        customer_email = selected_order.getCustomerEmail();
		        if(customer_email == null) {
		        	message_txt.setText("The selected customer has no email");
		        	return;
		        }
		        try {
					JavaMailUtil.sendMail(customer_email, "Order " + selected_order.getOrderId() + " APPROVED", "congratulations,\n your order has confirmed by the manager");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			else {
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ChangeOrderStatusToUnApproved, selected_order));
				
				ordersToApproveList = FXCollections.observableArrayList(ChatClient.ordersToConfirmList);
				ordersTable.setItems(ordersToApproveList);
				ordersTable.refresh();
				
		        message_txt.setText("The order you have selected is succefully rejected");
		        
		        customer_email = selected_order.getCustomerEmail();
		        if(customer_email == null) {
		        	message_txt.setText("The selected customer has no email");
		        	return;
		        }

		        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");  
		        String orderdeliveyDate = selected_order.getOrderDeliveryDate1();  
		        String orderCancelDate =  selected_order.getCancelDateTime1();  
		        
		        Date orderdeliveyDateTime  = dateFormat.parse(selected_order.getOrderDeliveryDate1());
		        Date orderCancelDateTime  = dateFormat.parse(selected_order.getCancelDateTime1());

		        long diff = orderdeliveyDateTime.getTime()- orderCancelDateTime.getTime();
		        long diffInHours = TimeUnit.MILLISECONDS.toHours(diff);

		        System.out.println("the differnce is :" +diffInHours);
		        
		        System.out.println("orderdeliveyDateTime is:  " +dateFormat.format(orderdeliveyDateTime) );
		        System.out.println("orderCancelDateTime is:  " +dateFormat.format(orderCancelDateTime) );


		        System.out.println("the delivery time is " + orderdeliveyDate + "the cancel date is"+ orderCancelDate);

		        double refund;
		        if(diffInHours >= 3) {// full zekoi
		        	refund = selected_order.getOrderPrice();
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.AddRefundToCustomerBalance,(Object) (selected_order.getCustomerId() + "," + refund)));
		        }
		        
		        else if(diffInHours <= 3 && diffInHours >= 1) {// 50%
		        	refund = 0.5*selected_order.getOrderPrice();
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.AddRefundToCustomerBalance,(Object) (selected_order.getCustomerId() + "," + refund)));
		        }
		        else { // nothing to return
		        	refund = 0.0;
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.AddRefundToCustomerBalance,(Object) (selected_order.getCustomerId() + "," + refund)));
		        }
		        
		        try {
					JavaMailUtil.sendMail(customer_email, "Order " + selected_order.getOrderId() + " UN_APPROVED",
							"sorry,\n your order has rejected by the manager\n your refund amount is " + Double.toString(refund));
				} catch (Exception e) {
					e.printStackTrace();
				}

			}

	    }
	    
/**
 * Representing the refresh button controller 
 * @param event An ActionEvent representing the refresh button
 */
		@FXML
		void refresh(ActionEvent event) {
			this.ordersTable.getItems().clear();
			initialize(null, null);
		}


		/**
		 * Representing the Starting screen of the branch manager orders 
		 * @param primaryStage A Stage representing the primary stage of the branch manager's screen
		 * @throws IOException   An Exception that the method throws in station of exception
		 */
	    public void start(Stage stage) throws IOException {
			AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerBranchOrders.fxml"));
			Scene scene = new Scene(root);
			stage.setTitle("Branch Orders");
			stage.setScene(scene);
			stage.show();

			scene.setOnMousePressed(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					scene.setCursor(Cursor.MOVE);
					initialX = (int) (stage.getX() - move.getScreenX());
					initialY = (int) (stage.getY() - move.getScreenY());
				}
			});

			scene.setOnMouseDragged(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					stage.setX(move.getScreenX() + initialX);
					stage.setY(move.getScreenY() + initialY);
				}
			});

			scene.setOnMouseReleased(move -> {
				scene.setCursor(Cursor.DEFAULT);
			});
		}
	    /**
	     * Initializing the details of the branch manager fields
	     */
		@Override
		public void initialize(URL location, ResourceBundle resources) {
						
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.OrdersToConfirmList, null));

			orderNumber_col.setCellValueFactory(new PropertyValueFactory<Orders, String>("orderId"));
			branchID_col.setCellValueFactory(new PropertyValueFactory<Orders, String>("branch"));
			customerUserID_col.setCellValueFactory(new PropertyValueFactory<Orders, String>("customerId"));
			status_col.setCellValueFactory(new PropertyValueFactory<Orders, String>("status"));
			date_col.setCellValueFactory(new PropertyValueFactory<Orders, String>("orderDate1"));
			totalPrice_col.setCellValueFactory(new PropertyValueFactory<Orders, Double>("orderPrice"));

			
			ordersToApproveList = FXCollections.observableArrayList(ChatClient.ordersToConfirmList);
			ordersTable.setItems(ordersToApproveList);
		}

	    
	    
	    
	    
	    
	    
	 
	    
	    
	    
	    
	    
	
}
