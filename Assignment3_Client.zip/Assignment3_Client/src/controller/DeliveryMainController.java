
package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the delivery main screen 
 * @author Majd Zbedat
 *
 */
public class DeliveryMainController implements Initializable{

	@FXML
	private Button DeliveryListBtn;

	@FXML
	private Text userNameText;
/**
 * Represening the delivery list 
 * @param event An ActionEvent representing the delivery list button  
 */
	@FXML
	void DeliveryList(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		DeliveryToCustomerController Dli = new DeliveryToCustomerController();
		try {
			Dli.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning view Delivery Details window\n");
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the delivery screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exitFunction(ActionEvent event) {
		Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
	}

	
	
	/**
	 * log out from the delivery main  screen 
	 * @param event An ActionEvent representing the log out button 
	 */ 
    @FXML
    void logOutFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	
	


	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the delivery
	 * @param primaryStage  A Stage representing the primary stage of the delivery 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/Delivery.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Delivery Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 * Initialize the details of the delivery user name
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		userNameText.setText(ChatClient.user.getFirstName());

	}

}
