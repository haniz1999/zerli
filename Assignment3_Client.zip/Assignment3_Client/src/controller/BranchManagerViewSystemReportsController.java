//package controller;
//
//import java.io.IOException;
//import java.net.URL;
//import java.time.Year;
//import java.util.ResourceBundle;
//
//import client.ClientUI;
//import common.ReportAndItsBranches;
//import common.TranslateMessage;
//import common.TranslateMessageType;
//import javafx.application.Platform;
//import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
//import javafx.fxml.FXMLLoader;
//import javafx.fxml.Initializable;
//import javafx.scene.Cursor;
//import javafx.scene.Node;
//import javafx.scene.Scene;
//import javafx.scene.control.Button;
//import javafx.scene.control.ComboBox;
//import javafx.scene.control.Label;
//import javafx.scene.input.MouseButton;
//import javafx.scene.layout.AnchorPane;
//import javafx.stage.Stage;
//
//public class BranchManagerViewSystemReportsController implements Initializable {
//	 private static BranchManagerViewSystemReportsController BranchManagerViewSystemReportsController;
//	    public static ReportAndItsBranches[] branchs;
//
//	private int initialX, initialY;
//
//	    @FXML
//	    private Label WarningMessage;
//		@FXML
//	    private ComboBox<String> MonthComboBox;
//	    @FXML
//	    private ComboBox<String> ReportComboBox;
//
//	    @FXML
//	    private ComboBox<String> QuarterComboBox;
//	    
//	    @FXML
//	    private Button View_Report;
//
//	    @FXML
//	    private ComboBox<String> YearComboBox;
//
//	    @FXML
//	    private Button exitBtn;
//
//	    public static String month;
//	    public static String year;
//
//	    
//	    
//	    @FXML
//	    void BackFunction(ActionEvent event) {
//	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//	    	BranchManagerMainController BMMC= new BranchManagerMainController();
//			try {
//				BMMC.start(stage);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//	    }
//
//	    @FXML
//	    void MonthComboBoxFunction(ActionEvent event) {
//
//	    }
//
//	    @FXML
//	    void ReportComboBoxFunction(ActionEvent event) {
//	    	
//	        String value=ReportComboBox.getSelectionModel().getSelectedItem().toString();
//	        if("Performance".equals(value)) {
//	            QuarterComboBox.setVisible(true);
//	        	MonthComboBox.setVisible(false);
//	        }
//	        else {
//	            QuarterComboBox.setVisible(false);
//	        	MonthComboBox.setVisible(true);
//	        }
//
//	    }
//	    
//
//	    @FXML
//	    void QuarterComboBoxFunction(ActionEvent event) {
//
//	    }
//
//	  /*  @FXML      /////********** RANI****************
//	    void ViewReportFunction(ActionEvent event) {
//	    	
//	    	try {
//	    		BranchManagerViewSystemReportsController.month = MonthComboBox.getSelectionModel().getSelectedItem().toString();
//		    	BranchManagerViewSystemReportsController.year = YearComboBox.getSelectionModel().getSelectedItem().toString();
//	    	}catch (NullPointerException e) {
//	    		 this.labelText("Please select month and year !!!!!!");
//	    		//System.out.println("Please select month and year !!!!!!");
//	    		e.printStackTrace();
//	    		return;
//	    	}
//	    	System.out.println("line 120 viewReortFunction");
//	    	if(ReportComboBox.getSelectionModel().getSelectedItem().equals("income")) {
//	    		
//				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//				BranchManagerVSR_IncomeReportController bmvsrirc = new BranchManagerVSR_IncomeReportController();
//				try {
//					bmvsrirc.start(stage);
//				} catch (Exception e) {
//					System.out.println("Error while openning income report window\n");
//					e.printStackTrace();
//				}
//	    		
//	    	}
//	    	System.out.println("line 133 viewReortFunction");
//
//
//	    	
//	    	
//	    	
//	    	
//
//	    }
//	    */
//	    
//	    
//	    ////////////////////////////////////////////////////////////////////////////////////
//	    
//	    
//	    
//	    
//	    @FXML
//	    void ViewReportFunction(ActionEvent event) {
//	    	
//	    	try {
//	    		BranchManagerViewSystemReportsController.month = MonthComboBox.getSelectionModel().getSelectedItem().toString();
//		    	BranchManagerViewSystemReportsController.year = YearComboBox.getSelectionModel().getSelectedItem().toString();
//	    	}catch (NullPointerException e) {
//	    		 this.labelText("Please select month and year !!!!!!");
//	    		//System.out.println("Please select month and year !!!!!!");
//	    		e.printStackTrace();
//	    		return;
//	    	}
//	    	System.out.println("line 120 viewReortFunction");
//	    	if(ReportComboBox.getSelectionModel().getSelectedItem().equals("income")) {
//	    		
//				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//				BranchManagerVSR_IncomeReportController bmvsrirc = new BranchManagerVSR_IncomeReportController();
//				try {
//					bmvsrirc.start(stage);
//				} catch (Exception e) {
//					System.out.println("Error while openning income report window\n");
//					e.printStackTrace();
//				}
//	    		
//	    	}
//	    	System.out.println("line 133 viewReortFunction");
//
//
//	    	
//	    	
//	    	
//	    	
//
//	    }
//	    
//	    
//	    
//	    
//	   
//	    
//	    
//	    ///////////////////////////////////////////////////////////////
//	    
//	    
//	    
//	    //////////////////////////////////////////////////////////////
//	    
//	    
//	    
//	    @FXML
//	    public void getViewReport(ActionEvent event) {
//	        block13: {
//	            String type;
//	            block14: {
//	                if (!this.checkYear_Month_Type_Quarter()) break block13;
//	                String date = String.valueOf((String)this.YearComboBox.getValue()) + "-" + (String)this.MonthComboBox
//	                		.getValue() + "-01";
//	                String[] branchAndDate = new String[]{connected.getBranchName, date, "monthly"};
//	                Message message = new Message(Task.GET_SYSTEM_REPORTS, Answer.WAIT_RESPONSE, branchAndDate);
//	                ViewSystemReportsScreenController.sendToClient(message);
//	                if (suppliers != null) break block14;
//	                this.setRelevantTextToDisplayMessageText("No reports found for that time period");
//	                break block13;
//	            }
//	            ReportGenerator.setSuppliers(suppliers);
//	            switch (type = (String)this.ReportType.getValue()) {
//	                case "Incomes": {
//	                    this.displaySingleReport(ReportGenerator.generateIncomeReport());
//	                    break;
//	                }
//	                case "Orders": {
//	                    this.displaySingleReport(ReportGenerator.generateOrderReport());
//	                    break;
//	                }
//	                case "Performance": {
//	                    this.displaySingleReport(ReportGenerator.generatePerformanceReport());
//	                    break;
//	                }
//	            }
//	            this.labelText("");
//	            suppliers = null;
//	        }
//	    }
//	    
//	    
//	    
//	    
//	    /////////////////////////////////////////////////////////////////////////////////////
//	    
//	    
//	    
//	    
//	    
//	  
//	   public boolean checkYear_Month_Type_Quarter() {
//	        if (((String)this.YearComboBox.getValue()).equals("YEAR")) {
//	            this.labelText("Please fill all the required fields (*)!");
//	            return false;
//	        }
//	       if (((String)this.MonthComboBox.getValue()).equals("MONTH")) {
//	            this.labelText("Please fill all the required fields (*)!");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("Report Type")) {
//	            this.labelText("Please fill Report Type field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("income") && ((String)this.YearComboBox.getValue()).equals("YEAR") 
//	        		&& ((String)this.YearComboBox.getValue()).equals("Month") ) {
//	        		
//	            this.labelText("Please fill Month and Year field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("Performance") && ((String)this.YearComboBox.getValue()).equals("YEAR") 
//	        		&& ((String)this.YearComboBox.getValue()).equals("Quarter") ) {
//	        		
//	            this.labelText("Please fill Year and Quarter field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("income") && ((String)this.YearComboBox.getValue()).equals("YEAR")) {
//	            this.labelText("Please fill Year field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("income") && ((String)this.YearComboBox.getValue()).equals("MONTH")) {
//	            this.labelText("Please fill Month field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("orders") && ((String)this.YearComboBox.getValue()).equals("MONTH")) {
//	            this.labelText("Please fill Month field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("orders") && ((String)this.YearComboBox.getValue()).equals("YEAR")) {
//	            this.labelText("Please fill Year field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("Performance") && ((String)this.YearComboBox.getValue()).equals("YEAR")) {
//	            this.labelText("Please fill Year field");
//	            return false;
//	        }
//	        if (((String)this.ReportComboBox.getValue()).equals("Performance") && ((String)this.YearComboBox.getValue()).equals("Quarter")) {
//	            this.labelText("Please fill Quarter field");
//	            return false;
//	        }
//	        return true;
//	    }
//	    
//	    
//	    
//	    
//	    private void labelText(final String message) {
//	        Platform.runLater(new Runnable(){
//
//	            @Override
//	            public void run() {
//	                BranchManagerViewSystemReportsController.WarningMessage.setText(message);
//	            }
//	        });
//	    }
//	    
//	    
//	    
//	    //////////////////////////////////////////////////////////////
//	    
//	    
//	    
//	    
//
//	    @FXML
//	    void YearComboBoxFunction(ActionEvent event) {
//
//	    }
//
//	    @FXML
//	    void exit(ActionEvent event) {
//	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
//	    	BranchManagerMainController BMMC= new BranchManagerMainController();
//			try {
//				BMMC.start(stage);
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//	    }
//
//	
//
//
//	
//	public void start(Stage stage) throws IOException {
//		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerViewSystemReports.fxml"));
//		Scene scene = new Scene(root);
//		stage.setTitle("Order Options");
//		stage.setScene(scene);
//		stage.show();
//
//		scene.setOnMousePressed(move -> {
//			if (move.getButton() == MouseButton.PRIMARY) {
//				scene.setCursor(Cursor.MOVE);
//				initialX = (int) (stage.getX() - move.getScreenX());
//				initialY = (int) (stage.getY() - move.getScreenY());
//			}
//		});
//
//		scene.setOnMouseDragged(move -> {
//			if (move.getButton() == MouseButton.PRIMARY) {
//				stage.setX(move.getScreenX() + initialX);
//				stage.setY(move.getScreenY() + initialY);
//			}
//		});
//
//		scene.setOnMouseReleased(move -> {
//			scene.setCursor(Cursor.DEFAULT);
//		});
//	}
//	
//	@Override
//	public void initialize(URL location, ResourceBundle resources) {
//		int i;
//		
//        Year year = Year.now();
//        for (i = year.getValue(); i > 2000; --i) {
//            YearComboBox.getItems().addAll("" + i);
//        }
//        for (i = 1; i < 13; ++i) {
//            if (i < 10) {
//            	MonthComboBox.getItems().add("0" + i);
//            }
//            else {
//            	MonthComboBox.getItems().add("" + i);
//            }
//        }
//        
//        ReportComboBox.getItems().addAll("income","orders","Performance");
//        QuarterComboBox.setVisible(false);
//        MonthComboBox.setVisible(false);
//        QuarterComboBox.getItems().addAll("First Q","Second Q","Third Q","Fourth Q");
//    	ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ReportsList,null));
//    	ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ReportsAndBranchesList,null));
//    	
//    	ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.BranchesList,null));
//
//
//    	//System.out.println(ChatClient.reportsList.get(0).getReport_id() + ChatClient.reportsList.get(1).getReport_id());
//    }
//	
//	
//
//}








package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * Representing a controller displays the system reports
 * @author Majd Zbedat & Laith Sadik 
 *
 */
public class BranchManagerViewSystemReportsController implements Initializable{

 	private int initialX, initialY;

    @FXML
    private Button ViewIncomebtn;

    @FXML
    private Button ViewOrderbtn;

    @FXML
    private Button ViewPerformancebtn;

    /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
    @FXML
    void BackFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerMainController BMMC= new BranchManagerMainController();
		try {
			BMMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
/**
 * Representing the income reports button
 * @param event An ActionEvent representing the view income report button action
 */
    @FXML
    void ViewIncomeReportFunction(ActionEvent event) {
    	
 
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			BranchManagerDetailsIncomeReportsController bmvsrirc = new BranchManagerDetailsIncomeReportsController ();
			try {
				bmvsrirc.start(stage);
			} catch (Exception e) {
				System.out.println("Error while openning income report window\n");
				e.printStackTrace();
			}
    		
    	}

    ////////////////
/**
 * Representing the order button
 * @param event An Action representing the view order button
 */
    @FXML
    void ViewOrderFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerDetailsOrderReportsController bmvsrirc = new BranchManagerDetailsOrderReportsController();
		try {
			bmvsrirc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning income report window\n");
			e.printStackTrace();
		}
    }

    //////////
    /**
     * Representing the performance report button
     * @param event An ActionEvent representing the view performance report button 
     */
    @FXML
    void ViewPerformancReportFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerDetailsPerformanceReportsController  bmvsrirc = new BranchManagerDetailsPerformanceReportsController();
		try {
			bmvsrirc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning income report window\n");
			e.printStackTrace();
		}
    }

    
    
    /**
     * Initializing the details of the 
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		
	}

	/**
	 * Representing the exit button controller for branch manager system reports screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
    void exit(ActionEvent event) {
		Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
    }
	
	  /**
	  * Representing the Starting screen of the branch manager system reports
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */
	public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerViewSystemReports.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("Report Options");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	
	
}












