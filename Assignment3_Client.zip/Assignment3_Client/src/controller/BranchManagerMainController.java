package controller;


import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;



import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
/**
 * Representing a controller displays the main screen of the branch manager
 * @author Majd Zbedat
 *
 */
public class BranchManagerMainController implements Initializable{

	private int initialX,initialY;
    @FXML
    private ImageView Exitbtn;
    @FXML
    private ImageView LogOutbtn;
   
    @FXML
    private Button branchOrdersBtn;

    @FXML
    private Button customerManagementBtn;

    @FXML
    private Button exitBtn;

    @FXML
    private Button logoutBtn;

    @FXML
    private Text userNameText;

    @FXML
    private Button userRegistrationBtn;

    @FXML
    private Button viewSystemReportsBtn;
/**
 * Representing the branch's order button action
 * @param event An ActionEvent Representing the branch's order button action
 */
    @FXML
    void branchOrders(ActionEvent event) {
    	
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerBranchOrdersController bmboc = new BranchManagerBranchOrdersController();
		try {
			bmboc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning view system reports window\n");
			e.printStackTrace();
		}

    }
/**
 * Representing the customer management button action
 * @param event An AcctionEvent representing the customer management button
 */
    @FXML
     void customerManagement(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerCustomerManagementController bmcumc = new BranchManagerCustomerManagementController();
		try {
			bmcumc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning customer management window\n");
			e.printStackTrace();
		}
    }
	/**
	 * Representing the exit button controller for branch manager main screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exitFunction(ActionEvent event) {
    	Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
    }
/**
 * Representing the logout button action 
 * @param event An ActionEvent representing the log out button
 */
    @FXML
    void logOutFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

    }
/**
 * Representing the user registration button for the branch manager action
 * @param event An ActionEvent representing the user registration button
 */
    @FXML
    void userRegistration(ActionEvent event) {

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerUserRegistrationController bmurc = new BranchManagerUserRegistrationController();
		try {
			bmurc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning user registration window\n");
			e.printStackTrace();
		}
    }
/**
 * Representing the view reports button for the branch management 
 * @param event An actionEvent representing the view reports button
 */
    @FXML
    void viewSystemReports(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerViewSystemReportsController bmvsrc = new BranchManagerViewSystemReportsController();
		try {
			bmvsrc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning view system reports window\n");
			e.printStackTrace();
		}
    }

    
    /**
     * Representing theview system report button action for the branch management
     * @param event An ActionEvent representing the system reports button
     */
    @FXML
    void WorkerManagement(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerWorkerManagementController bmvsrc = new BranchManagerWorkerManagementController();
		try {
			bmvsrc.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning view system reports window\n");
			e.printStackTrace();
		}
    }
    
    
    
    
/**
 * Representing the exit action 
 * @param event A mouseEvent representing the click on exit button
 */
    @FXML
    void exitFunction(MouseEvent event) {

    }

    
    
    /**
     * Representing the Starting screen of the branch manager main screen
     * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
     * @throws IOException   An Exception that the method throws in station of exception
     */
    public void start(Stage primaryStage) throws Exception {	
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerMain.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Branch Manager Main");
		primaryStage.setScene(scene);
		primaryStage.show();	
		
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

    
    scene.setOnMouseDragged(move -> {
		if (move.getButton() == MouseButton.PRIMARY) {
			primaryStage.setX(move.getScreenX() + initialX);
			primaryStage.setY(move.getScreenY() + initialY);
		}
	});

	scene.setOnMouseReleased(move -> {
		scene.setCursor(Cursor.DEFAULT);
	});
}
    /**
     * Initializing the details of the branch Manager's fields
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		userNameText.setText(ChatClient.user.getFirstName());
		
	}
    
}
















