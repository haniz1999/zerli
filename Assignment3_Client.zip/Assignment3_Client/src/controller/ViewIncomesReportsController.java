package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;
import javafx.scene.Group;
import client.ChatClient;
import client.ClientUI;
import common.IncomeDataReport;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.beans.value.ChangeListener;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Bounds;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.chart.XYChart.Series;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the income reports screen 
 * @author  Laith Sadik
 *
 */
public class ViewIncomesReportsController implements Initializable {

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the income reports
	 * @param primaryStage  A Stage representing the primary stage of the income reports
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewIncomesReports.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene); 
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}


    @FXML
    private TextArea income_txtarea;
    
	@FXML
	private Button backBtn;

	@FXML
	private BarChart<String, Number> barChart;

	@FXML
	private Button exitBtn;

	@FXML
	private CategoryAxis catagoryAxis;

	@FXML
	private NumberAxis numberAxis;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ViewSystemReportsController CEOVSR = new ViewSystemReportsController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the income reports screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Initialize the details of the income reports  
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		double totalCost=0;
		this.income_txtarea.setEditable(false);
		this.catagoryAxis.setLabel("Weeks");
		this.numberAxis.setLabel("Total Cost per week");
		XYChart.Series<String, Number> series;
		for (IncomeDataReport idr : ChatClient.incomeDataList) {
			series = new XYChart.Series<>();
			Data<String, Number> data = new XYChart.Data<>(idr.getWeek(), idr.getTotalIncome());
			series.getData().add(data);
			series.setName(idr.getWeek());
			this.barChart.getData().add(series);
			totalCost+=idr.getTotalIncome();
		} 
		this.income_txtarea.setText(createIncomeReport(totalCost));
		
	}
	/**
	 * Creating an income reports 
	 * @param totalComplaints an int the number of the income 
	 * @return A string representing the reports 
	 */
	private String createIncomeReport(double totalCost) {
		
		String bs = "\n\n";
		bs+= "        Income Report of " + ViewSystemReportsController.year1 +"/" + ViewSystemReportsController.month1+" \n";
		bs+= "               total income " + totalCost+" \n";
		bs+= "      first week total income: " + ChatClient.incomeDataList.get(0).getTotalIncome() + " \n";
		bs+= "      second week total income: " + ChatClient.incomeDataList.get(1).getTotalIncome() + " \n";
		bs+= "      third week total income: " + ChatClient.incomeDataList.get(2).getTotalIncome() + " \n";
		bs+= "      forth week total income: " + ChatClient.incomeDataList.get(3).getTotalIncome() + " \n";
		bs+= "      fifth week total income: " + ChatClient.incomeDataList.get(4).getTotalIncome() + " \n";
		bs+= "      Zerli increase in percentage: "+ (totalCost/10000)*100+"%";
		return bs;
	}

}
