package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Item;
import common.MyListener;
import common.Orders;
import common.ProductType;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
/**
 * Representing the controller of the predefined products catalog screen
 * @author Laith Sadik
 *
 */
public class CatalogOfPredefinedProductsController implements Initializable {
	static Products addToCartProduct;
	public static Orders order;
	MyListener myListener;
	ArrayList<Products> list = new ArrayList<>();
	public static ArrayList<Products> addToCartList = new ArrayList<>();
	public static double totalPrice = 0;
	//static {
	//	CatalogOfPredefinedProductsController.order = new Orders();
	//}
	int initialX, initialY;
	/**
	 * Representing the starting stage of the predefined products catalog screen
	 * @param primaryStage A Stage representing the primary stage of the predefined products catalog
	 * @throws Exception An Exception that the method throws in station of exception
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CatalogOfPredefinedProducts.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Catalog predfined product");
		primaryStage.setScene(scene);
		primaryStage.show();
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});

	}
	/**
	 * Representing the exit button controller 
	 * exiting from the predefined product catalog	
	 * @param event An ActionEvent representing the exit's button
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

/**
 * Representing the add to cart button to add the product 
 * @param event An ActionEvent representing the add to cart button action 
 */
	@FXML
	void addToCart(ActionEvent event) {
		totalPrice=order.getTotalPrductsPrice();
		errorAddToCart.setText("");
		if (addToCartProduct != null && !quantity_label.getText().equals("0") && !quantity_label.getText().isEmpty()) {
			for (int i = 0; i < Integer.valueOf(quantity_label.getText()); i++) {

				addToCartList.add(addToCartProduct);
				order.getProductsList().add(addToCartProduct);
				totalPrice += addToCartProduct.getPrice();
				order.setTotalPrductsPrice(totalPrice);
			}
		} else {
			errorAddToCart.setText("No items in the cart!");
			errorAddToCart.setFill(Color.RED);
			errorAddToCart.setFont(Font.font("Arial", 14));
			errorAddToCart.setStyle("-fx-text-fill: red;");
		}
		quantity_label.setText("0");
	}
	/**
	 * Representing the back button
	 * @param event An ActionEvent representing the back button action
	 */
	@FXML
	void back(ActionEvent event) {
		CustomerMainController.viewOrOrderFlag = false;
		errorAddToCart.setText("");
		ChatClient.productList.clear();
		addToCartList.clear();
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		OrderByCatalogController obcc = new OrderByCatalogController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
/**
 * Representing the complete order button to complete
 * @param event An ActionEvent representing the completeOrder button action 
 */
	@FXML
	void completeOrder(ActionEvent event) {
		errorAddToCart.setText("");
		quantity_label.setText("0");
		if(CatalogOfPredefinedProductsController.order.getProductsList().size()==0) {
			errorAddToCart.setText("Your Cart Is Empty!");
			errorAddToCart.setFill(Color.RED);
			errorAddToCart.setFont(Font.font("Arial", 14));
			errorAddToCart.setStyle("-fx-text-fill: red;");
		}
		else {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ListOfAllProductsAndListsController doc = new ListOfAllProductsAndListsController();
		try {
			doc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
	}
/**
 * Representing the my list cart button to show the list of cart 
 * @param event An ActionEvent representing the my list cart button action 
 */
	@FXML
	void myListCart(ActionEvent event) {
		errorAddToCart.setText("");
		quantity_label.setText("0");
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CartOfProductsController doc = new CartOfProductsController();
		try {
			doc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

    @FXML
    private Label percentage_discount;
	@FXML
	private Button myListCart_btn;

	@FXML
	private Button back_btn;
	@FXML
	private Text errorAddToCart;
	@FXML
	private Button exit_btn;
	@FXML
	private Button addToCart_btn;

	@FXML
	private VBox chooseProductCard;

	@FXML
	private Label compositionCart;

	@FXML
	private GridPane grid;

	@FXML
	private Label idCart;

	@FXML
	private ImageView imageCart;

	@FXML
	private Label nameCart;

	@FXML
	private Label priceCart;

	@FXML
	private TextField quantity_label;

	@FXML
	private ScrollPane scroll;

	@FXML
	private Label typeCart;

	@FXML
	private Button addBtn;

	@FXML
	private Button completeOrder_btn;

	@FXML
	private Button subBtn;
/**
 * Representing the add button to add product
 * @param event An ActionEvent representing the add button action 
 */
	@FXML
	void add(ActionEvent event) {

		quantity_label.setText(Integer.valueOf(quantity_label.getText()) + 1 + "");
		errorAddToCart.setText("");

	}

	@FXML
	void sub(ActionEvent event) {
		if (quantity_label.getText().equals("0")) {
			errorAddToCart.setText("Error quantity is zero!");
			errorAddToCart.setFill(Color.RED);
			errorAddToCart.setFont(Font.font("Arial", 14));
			errorAddToCart.setStyle("-fx-text-fill: red;");
		} else
			quantity_label.setText(Integer.valueOf(quantity_label.getText()) - 1 + "");
	}

/**
 * Initialize the predefined catalog details 
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		addToCartList.addAll(CatalogOfPredefinedProductsController.order.getProductsList());
		list.addAll(getData());
		this.priceCart.setText("0");
		this.totalPrice=CatalogOfPredefinedProductsController.order.getTotalPrductsPrice();
		quantity_label.setEditable(false);
		quantity_label.setText("0");
		setChooseProduct(list.get(0));
		myListener = new MyListener() {

			@Override
			public void OnClickListener(Products product) {
				setChooseProduct(product);
				quantity_label.setText("0");
				errorAddToCart.setText("");
			}

			@Override
			public void OnClickListener(Item item) {
				// TODO Auto-generated method stub
				
			}

		};

		int col = 0, row = 1;
		try {
			for (int i = 0; i < list.size(); i++) {
				FXMLLoader fxmlLoader = new FXMLLoader();
				fxmlLoader.setLocation(getClass().getResource("/gui/Products.fxml"));

				AnchorPane ap = fxmlLoader.load();

				ProductsController pc = fxmlLoader.getController();
				pc.setData(list.get(i), myListener);

				if (col == 3) {
					col = 0;
					row++;
				}
				grid.add(ap, col++, row);

				GridPane.setMargin(ap, new Insets(10));
				grid.setMaxHeight(Region.USE_COMPUTED_SIZE);
				grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
				grid.setMinHeight(Region.USE_COMPUTED_SIZE);
				grid.setMaxWidth(Region.USE_COMPUTED_SIZE);
				grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
				grid.setMinWidth(Region.USE_COMPUTED_SIZE);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
/**
 * Gets the data of the predefined products catalog 
 * @return An ArrayList<Products> representing the list of the predefined products catalog
 */
	private ArrayList<Products> getData() {

		ArrayList<Products> pList = new ArrayList<>();
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CatalogViewProducts, null));
		pList.addAll(ChatClient.productList);
		Products product;
		return pList;
	}
/**
 * Sets the chosen products into the cart 
 * @param product A Products representing the details of the product 
 */
	public void setChooseProduct(Products product) {
		addToCartProduct = product;
		idCart.setText(product.getProductId());
		nameCart.setText(product.getProductName());
		typeCart.setText(String.valueOf(product.getProductType()));
		compositionCart.setText(product.getProductComposition());
		priceCart.setText(product.getPrice()+"");
		percentage_discount.setText(product.getDiscount()+" %");
		Image image = new Image(getClass().getResourceAsStream(product.getImagePath()));
		imageCart.setImage(image);
		chooseProductCard.setStyle("-fx-background-color: " + "#CCCCCC" + ";\n" + "-fx-background-radius: 30;");
	}

}
