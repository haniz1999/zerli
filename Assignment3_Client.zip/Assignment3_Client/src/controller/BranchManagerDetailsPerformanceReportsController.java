package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.Year;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ComplaintsDataReports;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller that displays a screen for the branch manager performance reports
 * @author Laith Sadik
 *
 */
public class BranchManagerDetailsPerformanceReportsController implements Initializable {

	int initialX;
	int initialY;
  /**
  * Representing the Starting screen of the branch manager performance reports
  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
  * @throws IOException   An Exception that the method throws in station of exception
  */
	public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerDetailsPerformanceReports.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("Report Options");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private Button backBtn;

	@FXML
	private Text errorText;

	@FXML
	private Button exitBtn;

	@FXML
	private ComboBox<String> quarterCB;

	@FXML
	private Button viewReportBtn;

	@FXML
	private ComboBox<String> yearCB;
    /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerViewSystemReportsController CEOVSR = new BranchManagerViewSystemReportsController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Representing the exit button controller for branch manager performance report screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Representing the view performance's reports button 
	 * @param event An AcctionEvent representing the click action on the viewReport button 
	 */
	@FXML
	void viewReport(ActionEvent event) {

		if (CheckFillingComboBox()) {
			Object obj = this.yearCB.getValue() + "," + this.quarterCB.getValue();
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CheckIfThereComplaintsReport, obj));
			if (!ChatClient.checkIfThereComplaitns) {
				this.errorText.setText("No Report Order In This Date And In This Quarter");
			} else {

				obj = this.yearCB.getValue() + "," + this.quarterCB.getValue();
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetComplaintsReadyReport, obj));

				if ((boolean) ChatClient.objectList.get(0) == false) {
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetComplaintsDataReport, obj));
				} else {
					ChatClient.quarterComplaintsReports = new ArrayList<ComplaintsDataReports>();
					for (int i = 1; i < ChatClient.objectList.size(); i++) {
						ChatClient.quarterComplaintsReports.add((ComplaintsDataReports) ChatClient.objectList.get(i));
					}
				}
				this.year1 = this.yearCB.getValue();
				this.quarter1 = this.quarterCB.getValue();
				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				BranchManagerViewPerformanceReportsController viec = new BranchManagerViewPerformanceReportsController();
				try {
					viec.start(stage);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}
	/**
	 * checking if the filling details istrue
	 * @return true if the filling is true else false
	 */
	private boolean CheckFillingComboBox() {

		if ((((String) this.yearCB.getValue()).equals("Year")
				&& ((String) this.quarterCB.getValue()).equals("Quarter"))) {
			this.errorText.setText("please Fill The Year And Quarter Fields!");
			return false;
		} else if (((String) this.yearCB.getValue()).equals("Year")) {
			this.errorText.setText("Please Fill The Year Fields!");
			return false;
		} else if (((String) this.quarterCB.getValue()).equals("Quarter")) {
			this.errorText.setText("Please Fill The Quarter Fields!");
			return false;
		}

		return true;
	}

	public static String year1, quarter1;
    /**
     * Initializing the details of the branch Manager's fields
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.year1 = "";
		this.quarter1 = "";
		this.errorText.setFill(Color.RED);
		this.errorText.setFont(Font.font("Arial", 14));
		this.errorText.setStyle("-fx-text-fill: red;");
		this.errorText.setStyle("-fx-border-color: red");
		this.yearCB.setValue("Year");
		this.quarterCB.setValue("Quarter");
		int i;
		Year y = Year.now();
		for (i = y.getValue(); i > 2000; --i) {
			this.yearCB.getItems().add("" + i);
		}

		for (i = 1; i < 5; ++i) {
			this.quarterCB.getItems().add("" + i);
		}
	}

}
