package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Item;
import common.ItemType;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.ComboBox;
/**
 * Representing a controller that displays a screen for 
 *  updating the Item's details with item's name,id,type,color,price and picture path
 * @author Laith Sadik
 *
 */
public class AddUpdateItemcontroller implements Initializable {
/**
 * Initializing the details of the item's fields
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ObservableList<String> producttype = FXCollections.observableArrayList("Pot","Bouquet","Flower","Seedling","Branch");
		itempTypeCMB.setItems(producttype);
		if (UpdateItemController.me != null) {
			ItemID_txtf.setText(UpdateItemController.me.getItemId());
			ItemID_txtf.setDisable(true);
			ItemName_txtf.setText(UpdateItemController.me.getItemName());
			itempTypeCMB.setValue(UpdateItemController.me.getItemType().name());
			colortxtf.setText(UpdateItemController.me.getColor());
			price_txtf.setText(String.valueOf(UpdateItemController.me.getPrice()));
			imagepath_txtf.setText(UpdateItemController.me.getPicturePath());
			imagepath_txtf.setVisible(false);
		} else {
			imagepath_txtf.setText("/images/white.png");
			imagepath_txtf.setVisible(false);
		}

	}

	private int initialX, initialY;
/**
 * Representing the Starting screen of the updating item
 * @param primaryStage A Stage representing the primary stage of the item's screen
 * @throws Exception   An Exception that the method throws in station of exception
 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ItemDetailsUpdate.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private TextField colortxtf;

	@FXML
	private TextField ItemID_txtf;

	@FXML
	private TextField ItemName_txtf;


	@FXML
	private Button backbtn;

	@FXML
	private Button exitbtn;

	@FXML
	private TextField imagepath_txtf;

	@FXML
	private TextField price_txtf;

	@FXML
	private Text alert_txt;
    @FXML
    private ComboBox<String> itempTypeCMB;
    /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
	@FXML
	void Back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		UpdateItemController gui = new UpdateItemController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Representing the save action to saves the updating details
 * @param event An ActionEvent representing the save's click
 */
	@FXML
	void save(ActionEvent event) {
		if (ItemID_txtf.getText().isEmpty() || ItemName_txtf.getText().isEmpty()|| itempTypeCMB.getValue()==null
				|| colortxtf.getText().isEmpty() || price_txtf.getText().isEmpty()
				|| imagepath_txtf.getText().isEmpty()) {
			UpdateItemController.flag = false;
			alert_txt.setText("Please Fill all fields");
			alert_txt.setFill(Color.RED);
			alert_txt.setFont(Font.font("Arial", 14));
			alert_txt.setStyle("-fx-text-fill: red;");
		}
		if(!checktext(ItemID_txtf.getText()))
		{
			UpdateItemController.flag = false;
			alert_txt.setText("Please Fill Valid Id");
			alert_txt.setFill(Color.RED);
			alert_txt.setFont(Font.font("Arial", 14));
			alert_txt.setStyle("-fx-text-fill: red;");
		}
		if(!checktext(price_txtf.getText()))
		{
			UpdateItemController.flag = false;
			alert_txt.setText("Please Fill Valid Price");
			alert_txt.setFill(Color.RED);
			alert_txt.setFont(Font.font("Arial", 14));
			alert_txt.setStyle("-fx-text-fill: red;");
		}
		
		if (UpdateItemController.flag == true && UpdateItemController.me == null) {
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ItemListInCatalog, null));
			for (Item t1 : ChatClient.itemIncatalog) {
				if (t1.getItemId().equals(ItemID_txtf.getText())) {
					UpdateItemController.flag = false;
					alert_txt.setText("Please Fill another ID ");
					alert_txt.setFill(Color.RED);
					alert_txt.setFont(Font.font("Arial", 14));
					alert_txt.setStyle("-fx-text-fill: red;");
				}
			}
		}

		if (UpdateItemController.flag == true) {
			if (UpdateItemController.me != null) {
				Object ObjRemoveproduct;
				ObjRemoveproduct = (UpdateItemController.me.getItemId());
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Deleteitem, ObjRemoveproduct));
			}
			Item objAddproduct = new Item(ItemID_txtf.getText(), ItemName_txtf.getText(),
					ItemType.valueOf(itempTypeCMB.getValue()), colortxtf.getText(),
					Double.valueOf(price_txtf.getText()), imagepath_txtf.getText());

			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.addItem, objAddproduct));

			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			UpdateItemController gui = new UpdateItemController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		UpdateItemController.flag = true;

	}
	/**
	 * return true if the string strNum parse as duoble else return false
	 * @param strNum A string representing the text to check  
	 * @return false if the strNum is null or get exception else if the strNum representing as double returs true
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	/**
	 * Representing the exit button controller for 
	 * exiting from the updating item screen
	 * @param event An ActionEvent representing the exit's button
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}

}
