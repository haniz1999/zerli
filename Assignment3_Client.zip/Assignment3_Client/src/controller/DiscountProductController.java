package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ProductType;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextField;
/**
 * Representing a controller of the discount product screen 
 * @author Othman
 *
 */
public class DiscountProductController implements Initializable {

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the discount product
	 * @param primaryStage  A Stage representing the primary stage of the discount product
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/DiscountProduct.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private TextField discount_txtf;
    @FXML
    private Text alert_txtf;
    /**
     * Saving the data of the discount product 
     * @param event An ActionEvent representing the save button
     */
	@FXML
	void save(ActionEvent event) {
		boolean flag=true;
		if (discount_txtf.getText().isEmpty()) {
			flag=false;

			alert_txtf.setText("Please Fill Valid Id");
			alert_txtf.setFill(Color.RED);
			alert_txtf.setFont(Font.font("Arial", 14));
			alert_txtf.setStyle("-fx-text-fill: red;");
		}
		if(!checktext(discount_txtf.getText()))
		{
			flag=false;

			alert_txtf.setText("Please Fill Valid Price");
			alert_txtf.setFill(Color.RED);
			alert_txtf.setFont(Font.font("Arial", 14));
			alert_txtf.setStyle("-fx-text-fill: red;");
		}
		if( flag==true&&(Double.parseDouble(discount_txtf.getText())>100||Double.parseDouble(discount_txtf.getText())<0))
		{
			flag=false;
			alert_txtf.setText("Please Fill Valid Percentage");
			alert_txtf.setFill(Color.RED);
			alert_txtf.setFont(Font.font("Arial", 14));
			alert_txtf.setStyle("-fx-text-fill: red;");
		}
		if(flag==true)
		{
			Products objAddproduct = new Products(UpdateProductsController.me.getProductId(), UpdateProductsController.me.getProductName(),
					UpdateProductsController.me.getProductType(), UpdateProductsController.me.getProductComposition(),
					Double.valueOf(UpdateProductsController.me.getPrice()), UpdateProductsController.me.getImagePath(),Double.parseDouble(discount_txtf.getText()));

			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.addDiscountProduct, objAddproduct));

			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			UpdateProductsController gui = new UpdateProductsController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	/**
	 * checking the fields if its fill in the true way
	 * @return true if the fields true else return false
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		UpdateProductsController gui = new UpdateProductsController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the discount product screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}

}
