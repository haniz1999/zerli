package controller;

import java.net.URL;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ItemType;
import common.ItemsWithImage;
import common.ProductType;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * Representing a controller of the catalog of predefined catalog screen 
 * @author  Laith Sadik
 *
 */
public class ViewOnCatalogPredefinedController implements Initializable {
	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the catalog of predefined 
	 * @param primaryStage  A Stage representing the primary stage of the catalog of predefined 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewOnCatalogPredefinedController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("View Predefined catalog");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	ObservableList<Products> productList;
	/**
	 * Initialize the details of the catalog of the predefined 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		productCompositionTableColumn.setCellValueFactory(new PropertyValueFactory<Products, String>("productComposition"));
	    productIdTableColumn.setCellValueFactory(new PropertyValueFactory<Products, String>("productId"));
		productNameTableColumn.setCellValueFactory(new PropertyValueFactory<Products, String>("productName"));
		priceTableColumn.setCellValueFactory(new PropertyValueFactory<Products, Double>("price"));
		typeTableColumn.setCellValueFactory(new PropertyValueFactory<Products, ProductType>("productType"));
		ImageTableColumn.setCellValueFactory(new PropertyValueFactory<Products, ImageView>("image"));
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CatalogViewProducts, null));
		this.productList = FXCollections.observableArrayList(ChatClient.productList);
		viewPredefinedTableView.setItems(productList);
	}

	@FXML
	private TableColumn<Products, ImageView> ImageTableColumn;

	@FXML
	private Button backBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private TableColumn<Products, Double> priceTableColumn;

	@FXML
	private TableColumn<Products, String> productCompositionTableColumn;

	@FXML
	private TableColumn<Products, String> productIdTableColumn;

	@FXML
	private TableColumn<Products, String> productNameTableColumn;

	@FXML
	private TableColumn<Products, ProductType> typeTableColumn;

	@FXML
	private TableView<Products> viewPredefinedTableView;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		OrderByCatalogController obcc = new OrderByCatalogController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the predefined catalog  screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {

	}

}
