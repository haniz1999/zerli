package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Survey;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;



/**
 * Representing a controller displays the survey of the branch worker screen
 * @author Rani Khori
 *
 */
public class BranchWorkerViewSurveysController implements Initializable{


	public static ObservableList<Survey> surveysList;
	public static Survey chosenSurveyToFill;

	
    @FXML
    private Button backBtn;

    @FXML
    private TableColumn<Survey, String> branchNameCol;

    @FXML
    private TableColumn<Survey, String> endDateCol;

    @FXML
    private Text errorText;

    @FXML
    private Button exitBtn;

  

    @FXML
    private TableColumn<Survey, String> periodCol;

    @FXML
    private TableColumn<Survey, String> promotionCol;

    @FXML
    private TableColumn<Survey, String> q1Col;

    @FXML
    private TableColumn<Survey, String> q2Col;

    @FXML
    private TableColumn<Survey, String> q3Col;

    @FXML
    private TableColumn<Survey, String> q4Col;

    @FXML
    private TableColumn<Survey, String> q5Col;

    @FXML
    private TableColumn<Survey, String> q6Col;

    @FXML
    private TableColumn<Survey, String> startDateCol;

    @FXML
    private TableColumn<Survey, String> surveyIdCol;

    @FXML
    private ComboBox<String> surveyTypeComboBox;

    @FXML
    private TableView<Survey> surveysTable;
    
    @FXML
    private Button fillBtn;


	private int initialX;

	private int initialY;

	/**
	 * Representing the back button
	 * @param event An ActionEvent representing the back button action
	 */
    @FXML
    void back(ActionEvent event) {
    	Platform.runLater(new Runnable() {

			@Override
			public void run() {
		 	 	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		 		BranchWorkerMainController bwmc = new BranchWorkerMainController();
		 		try {
		 			bwmc.start(stage);
		 		} catch (Exception e) {
		 			e.printStackTrace();
		 		}				
			}
    	});
    }
	/**
	 * Representing the exit button controller for branch manager income report screen
	 * exiting from the branch worker survey  screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exit(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

 

    /**
     * Representing the survey by type button 
     * @param event An ActionEvent representing the view survey by type button action 
     */
    @FXML
    void viewBySurveyType(ActionEvent event) {
    	
    	if(surveyTypeComboBox.getSelectionModel().getSelectedItem() == null) {
    		errorText.setText("You must select a survey type first");
    		return;
    	}
    	else if(surveyTypeComboBox.getSelectionModel().getSelectedItem().equals("Period")) {
    		periodCol.setVisible(true);
    		branchNameCol.setVisible(false);
    		promotionCol.setVisible(false);
    	}
    	else if(surveyTypeComboBox.getSelectionModel().getSelectedItem().equals("Branch")) {
    		branchNameCol.setVisible(true);
    		promotionCol.setVisible(false);
    		periodCol.setVisible(false);
    	}
    	else if(surveyTypeComboBox.getSelectionModel().getSelectedItem().equals("Sale")) {
    		promotionCol.setVisible(true);
    		branchNameCol.setVisible(false);
    		periodCol.setVisible(false);
    	}
    	
    	ObservableList<Survey> surveysAfterFilteringList = FXCollections.observableArrayList();
    	
    	String temp = "BY"+surveyTypeComboBox.getSelectionModel().getSelectedItem().toUpperCase();
    	
    	ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetSurveysList, null));
		surveysList = FXCollections.observableArrayList(ChatClient.surveysList);
    	for(Survey s:surveysList) {
    		if(s.getSurveyType().equals(temp))
    			surveysAfterFilteringList.add(s);
    	}
    	surveysTable.setItems(surveysAfterFilteringList);
    	surveysTable.refresh();
    	surveysTable.setVisible(true);
    }
    
    
    
    /**
     * Representing the fill button
     * @param event An ActionEvent representing the fill button action 
     */
    @FXML
    void fill(ActionEvent event) {
    	
    	chosenSurveyToFill = surveysTable.getSelectionModel().getSelectedItem();
    	
    	if(chosenSurveyToFill == null) {
    		errorText.setText("You must select an survey first");
    	}
    	else {
        	Platform.runLater(new Runnable() {
    			@Override
    			public void run() {
    		    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    		    	BranchWorkerFillSurveyController bwfsc = new BranchWorkerFillSurveyController();
    				try {
    					bwfsc.start(stage);
    				} catch (Exception e) {
    					System.out.println("Error while openning fill survey window\n");
    					e.printStackTrace();
    				}				
    			}

        	});

    	}

    }
    
    
	
	  /**
	  * Representing the Starting screen of the branch worker survey screen
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */	
    public void start(Stage stage) throws IOException {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchWorkerViewSurveys.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("View Surveys");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 * Initialize the survey's questions 
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetSurveysList, null));
		
		surveyTypeComboBox.getItems().addAll("Period","Branch","Sale");
		
		
		surveyIdCol.setCellValueFactory(new PropertyValueFactory<Survey, String>("idsurvey"));
		q1Col.setCellValueFactory(new PropertyValueFactory<Survey, String>("q1question"));
		q2Col.setCellValueFactory(new PropertyValueFactory<Survey, String>("q2question"));
		q3Col.setCellValueFactory(new PropertyValueFactory<Survey, String>("q3question"));
		q4Col.setCellValueFactory(new PropertyValueFactory<Survey, String>("q4question"));
		q5Col.setCellValueFactory(new PropertyValueFactory<Survey, String>("q5question"));
		q6Col.setCellValueFactory(new PropertyValueFactory<Survey, String>("q6question"));
		startDateCol.setCellValueFactory(new PropertyValueFactory<Survey, String>("startDate"));
		endDateCol.setCellValueFactory(new PropertyValueFactory<Survey, String>("endDate"));
		branchNameCol.setCellValueFactory(new PropertyValueFactory<Survey, String>("branchName"));
		promotionCol.setCellValueFactory(new PropertyValueFactory<Survey, String>("promotion"));
		periodCol.setCellValueFactory(new PropertyValueFactory<Survey, String>("period"));
		
		surveysList = FXCollections.observableArrayList(ChatClient.surveysList);
		surveysTable.setItems(surveysList);
				
		
	}

}
