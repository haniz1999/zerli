package controller;

import java.awt.Button;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Survey;
import common.SurveyAnswer;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import ocsf.server.ConnectionToClient;
/**
 * Representing a controller of the service specialist screen 
 * @author Othman Laith Sadik
 *
 */
public class ServiceSpecialistAOR implements Initializable {
	private int initialX, initialY;
	private String pathLocation, filename;
	private byte[] bytes;

	@FXML
	private Text selectedpdffile;
	
	@FXML
	private Text notselected;
/**
 * opening file chooser to choose conclusions pdf
 * @param event
 * @throws IOException
 */
	@FXML
	void choosepdf(ActionEvent event) throws IOException {
		FileChooser fileChooser = new FileChooser();
		Window stage = null;
		File selectedFile = fileChooser.showOpenDialog(stage);
		if (selectedFile == null) {
			notselected.setText("Error! You didn't choose a file");
			selectedpdffile.setText("");

		} else if (!selectedFile.getName().toLowerCase().endsWith(".pdf")) {
			notselected.setText("Error! you can attach only pdf files");
		}

		else {
			pathLocation = selectedFile.getAbsolutePath().toString();
			filename = selectedFile.getName().toString();
			File file = new File(pathLocation);

			bytes = new byte[(int) file.length()];
			FileInputStream fis = null;
			try {

				fis = new FileInputStream(file);

				// read file into bytes[]
				fis.read(bytes);
				System.out.println(bytes.length);

			} finally {
				if (fis != null) {

					fis.close();
				}
			}

			selectedpdffile.setText(filename);
		}
	}
	/**
	 * Exit from the service specialist screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exitbtn(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}


	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void backbtn(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ServiceSpecialistViewSurveysAnswersController bmcumcasd = new ServiceSpecialistViewSurveysAnswersController();
		try {
			bmcumcasd.start(stage);
		} catch (Exception e) {
			System.out.println("Error while openning service specialist main window\n");
			e.printStackTrace();
		}
	}
/**
 * confirm button when pressed will save the pdf file as blob in DB
 * @param event
 */
	@FXML
	void confirm(ActionEvent event) {

		if (bytes == null) {
			notselected.setText("Please select a file first!");
		} else {

			SurveyAnswer surveyAnswerWithPdf = ServiceSpecialistViewSurveysAnswersController.selected_surveyAnswer;

			surveyAnswerWithPdf.setPdfField(bytes);
			System.out.println("the bytes in survey Answer is:" + surveyAnswerWithPdf.getPdfField());
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.AddSurveySpecialPdf, surveyAnswerWithPdf));

			if (ChatClient.isSurveyAnswerWithPdfSavedSuccefully) {
				System.out.println("file succefully has writen to blob");
				notselected.setText("File has been uploaded successfully");

			}
			else {
				notselected.setText("File has not been uploaded successfully");

			}
		}

	}
	/**
	 * Representing the screen of the primary screen of the service specialist
	 * @param primaryStage  A Stage representing the primary stage of the service specialist
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ServiceSpecialistAOR.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Service Specialist Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}
}
