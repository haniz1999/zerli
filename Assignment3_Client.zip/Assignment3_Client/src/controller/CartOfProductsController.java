package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ProductType;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the product screen 
 * @author Rani Khori
 *
 */
public class CartOfProductsController implements Initializable {

	int initialX, initialY;
	/**
	 * Representing the starting stage of the product screen
	 * @param primaryStage A Stage representing the primary stage of the product
	 * @throws Exception An Exception that the method throws in station of exception
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CartOfProducts.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Catalog predfined product");
		primaryStage.setScene(scene);
		primaryStage.show();
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});

	}

	@FXML
	private Button back_btn;
	/**
	 * Representing the back button
	 * @param event An ActionEvent representing the back button action
	 */
	@FXML
	void back(ActionEvent event) {

		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CatalogOfPredefinedProductsController obcc = new CatalogOfPredefinedProductsController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@FXML
	private Button exit_btn;

	@FXML
	private TextField totalPriceCart;

	@FXML
	private TableColumn<Products, Double> priceCartTableColumn;

	@FXML
	private TableColumn<Products, String> itemNameCartTableColumn;
	@FXML
	private TableView<Products> cartTableView;
	@FXML
	private TableColumn<Products, ProductType> typeCartTableColumn;

	@FXML
	private Button removeItemBtn;

	@FXML
	private Text errorRemove;
	/**
	 * Representing the exit button controller 
	 * exiting from the products screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Representing the remove button 
	 * @param event An ActionEvent representing the remove item button action 
	 */
	@FXML
	void removeItem(ActionEvent event) {

		if (this.cartTableView.getSelectionModel().getSelectedItem() != null
				&& this.cartTableView.getSelectionModel().getSelectedItem() instanceof Products) {
			final Products productRemoveFromCart = this.cartTableView.getSelectionModel().getSelectedItem();
			CatalogOfPredefinedProductsController.totalPrice -= productRemoveFromCart.getPrice();
			CatalogOfPredefinedProductsController.order.setTotalPrductsPrice(CatalogOfPredefinedProductsController.totalPrice);
			CatalogOfPredefinedProductsController.order.getProductsList().remove(productRemoveFromCart);
			CatalogOfPredefinedProductsController.addToCartList.remove(productRemoveFromCart);
			this.totalPriceCart.setText(String.valueOf(CatalogOfPredefinedProductsController.totalPrice));
			this.cartTableView.getItems().remove(productRemoveFromCart);
			totalPriceCart.setPadding(new Insets(5));
			totalPriceCart.setFont(Font.font("Arial", 14));
			totalPriceCart.setStyle("-fx-text-fill: red;");
		} else {
			errorRemove.setText("No Prdoucts For Removing!");
			errorRemove.setFill(Color.RED);
			errorRemove.setFont(Font.font("Arial", 14));
			errorRemove.setStyle("-fx-text-fill: red;");
		}

	}

	private static ObservableList<Products> productsForCart;
/**
 * Inotialize the product's details
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		totalPriceCart.setPadding(new Insets(5));
		totalPriceCart.setFont(Font.font("Arial", 14));
		totalPriceCart.setStyle("-fx-text-fill: red;");
		totalPriceCart.setEditable(false);
		totalPriceCart.setText(CatalogOfPredefinedProductsController.order.getTotalPrductsPrice() + "");
		priceCartTableColumn.setCellValueFactory(new PropertyValueFactory<Products, Double>("price"));
		itemNameCartTableColumn.setCellValueFactory(new PropertyValueFactory<Products, String>("productName"));
		typeCartTableColumn.setCellValueFactory(new PropertyValueFactory<Products, ProductType>("productType"));
		this.productsForCart = FXCollections.observableArrayList(CatalogOfPredefinedProductsController.order.getProductsList());
		cartTableView.setItems(this.productsForCart);
		this.cartTableView.setOnMouseClicked(new EventHandler<Event>() {
			@Override
			public void handle(final Event event) {
				CartOfProductsController.this.cartTableView.getSelectionModel();
			}
		});
	}

}
