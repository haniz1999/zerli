package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Item;
import common.ItemType;
import common.Items;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the updating item screen 
 * @author USER
 *
 */
public class UpdateItemController implements Initializable {
	public static ObservableList<Item> itemList;
	public static Item me;
	public static boolean flag = false;
	/**
	 * Initialize the details of the  item 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */ 
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		me = null;

		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ItemListInCatalog, null));
		this.itemId.setCellValueFactory(new PropertyValueFactory<Item, String>("itemId"));
		this.itemName.setCellValueFactory(new PropertyValueFactory<Item, String>("itemName"));
		this.itemprice.setCellValueFactory(new PropertyValueFactory<Item, Double>("price"));
		this.itemType.setCellValueFactory(new PropertyValueFactory<Item, ItemType>("itemType"));
		this.color.setCellValueFactory(new PropertyValueFactory<Item, String>("color"));
		discountColumn.setCellValueFactory(new PropertyValueFactory<Item, Double>("discount"));
		itemList = FXCollections.observableArrayList(ChatClient.itemIncatalog);
		ItemTable.setItems(itemList);
	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the update item
	 * @param primaryStage  A Stage representing the primary stage of the update item 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/UpdateItem.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private Button discountBTN;

	@FXML
	private TableColumn<Item,Double> discountColumn;
	@FXML
	private Text Alarttxt;

	@FXML
	private TableView<Item> ItemTable;

	@FXML
	private Button back_btn;

	@FXML
	private TableColumn<Item, String> color;

	@FXML
	private Button exit_btn;

	@FXML
	private Button finishupdate_btn;

	@FXML
	private TableColumn<Item, String> itemId;

	@FXML
	private TableColumn<Item, String> itemName;

	@FXML
	private TableColumn<Item, ItemType> itemType;

	@FXML
	private TableColumn<Item, Double> itemprice;
	/**
	 * Representing the discount of the item 
	 * @param event An ActionEvent representing the discount button 
	 */
    @FXML
    void discountBTN(ActionEvent event) {
		if (this.ItemTable.getSelectionModel().getSelectedItem() == null) {
			Alarttxt.setText("Please select column");
			Alarttxt.setFill(Color.RED);
			Alarttxt.setFont(Font.font("Arial", 14));
			Alarttxt.setStyle("-fx-text-fill: red;");
		} else {
			me = this.ItemTable.getSelectionModel().getSelectedItem();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			DiscountItemController gui = new DiscountItemController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
    	
    }
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ChooseToUpdatecontroller gui = new ChooseToUpdatecontroller();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Adding an item action
 * @param event An ActionEvent representing the add button 
 */
	@FXML
	void addItem(ActionEvent event) {
		flag = true;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		AddUpdateItemcontroller gui = new AddUpdateItemcontroller();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
/**
 * Deleting the item action 
 * @param event An ActionEvent representing the delete button 
 */
	@FXML
	void deleteItem(ActionEvent event) {
		if (this.ItemTable.getSelectionModel().getSelectedItem() == null) {
			Alarttxt.setText("Please select column");
			Alarttxt.setFill(Color.RED);
			Alarttxt.setFont(Font.font("Arial", 14));
			Alarttxt.setStyle("-fx-text-fill: red;");
		} else {
			Object ObjRemoveproduct;
			ObjRemoveproduct = (ItemTable.getSelectionModel().getSelectedItem().getItemId());

			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Deleteitem, ObjRemoveproduct));
			initialize(null, null);
			ItemTable.refresh();
		}
	}
	/**
	 * Exit from the update item  screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
/**
 * Finishing the updating operation
 * @param event An ActioEvent representign the finish button 
 */
	@FXML
	void finishupdate(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		MainMarketingWorkerController gui = new MainMarketingWorkerController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Updating the item 
 * @param event An ActionEvent representing the update button 
 */
	@FXML
	void updateItem(ActionEvent event) {
		flag = true;
		if (this.ItemTable.getSelectionModel().getSelectedItem() == null) {
			Alarttxt.setText("Please select column");
			Alarttxt.setFill(Color.RED);
			Alarttxt.setFont(Font.font("Arial", 14));
			Alarttxt.setStyle("-fx-text-fill: red;");
		} else {
			me = this.ItemTable.getSelectionModel().getSelectedItem();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			AddUpdateItemcontroller gui = new AddUpdateItemcontroller();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

}
