package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.CustomerType;
import common.Orders;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.TypeOfPayment;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import utils.JavaMailUtil;
/**
 * Representing a controller of the payment screen 
 * @author Laith Sadik
 *
 */
public class PaymentController implements Initializable {

	
	private Orders order;
	private double leftToPay;
	private int initialX;
	private int initialY;
	/**
	 * Representing the screen of the primary screen of the payment
	 * @param primaryStage  A Stage representing the primary stage of the payment
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/Payment.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Filling Order Details");
		primaryStage.setScene(scene);

		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

    @FXML
    private TextField balance_txtf;
    
	@FXML
	private Button addAmountBtn;

	@FXML
	private TextField amount_txtf;

	@FXML
	private Button backBtn;

	@FXML
	private TextField cash_txtf;

	@FXML
	private TextField credit_txtf;

	@FXML
	private Text errorPayment;

	@FXML
	private Button exitBtn;

	@FXML
	private Button finishPaymentBtn;

	@FXML
	private TextField leftToPay_txtf;

	@FXML
	private ComboBox<TypeOfPayment> paymentOptionsCB;

	@FXML
	private Button removeAmountBtb;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		if (CustomerMainController.backToDeliveryOrTakeAwayl == false) {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			TakeAwayController obcc = new TakeAwayController();
			try {
				obcc.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			DetailsDeliveryController obcc = new DetailsDeliveryController();
			try {
				obcc.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	/**
	 * Exit from the payment screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
/**
 * Representing the adding amount action 
 * @param event An ActionEvent representing the add amony button 
 */
	@FXML
	void addAmount(ActionEvent event) {
		this.errorPayment.setFill(Color.RED);
		this.errorPayment.setFont(Font.font("Arial", 14));
		this.errorPayment.setStyle("-fx-text-fill: red;");
		this.errorPayment.setStyle("-fx-border-color: red");
		if (this.leftToPay == 0) {
			this.errorPayment.setText("You Should Finish!");
		} else if (this.paymentOptionsCB.getValue() == null) {
			this.paymentOptionsCB.setStyle("-fx-border-color: red");
			this.errorPayment.setText("Fill Payment Options Field!");
		} else if (this.amount_txtf.getText().isEmpty()) {
			this.amount_txtf.setStyle("-fx-border-color: red");
		} else if (this.leftToPay == 0) {
			this.amount_txtf.setStyle("-fx-border-color: black");
			this.errorPayment.setText("You Should Finish!");
		} else if (checktext(this.amount_txtf.getText()) == false) {
			this.amount_txtf.setStyle("-fx-border-color: red");
			this.errorPayment.setText("Fill ligal Amount field!");
		} else if (Double.valueOf(this.amount_txtf.getText()) < 0
				|| (Double.valueOf(this.amount_txtf.getText()) > this.leftToPay)) {
			this.amount_txtf.setStyle("-fx-border-color: red");
			this.errorPayment.setText("Fill Correct Amount field!");
		} else {
			this.amount_txtf.setStyle("-fx-border-color: black");
			if (this.paymentOptionsCB.getValue() == TypeOfPayment.CASH) {
				this.cash_txtf.setText(this.amount_txtf.getText());
				this.leftToPay -= Double.valueOf(this.amount_txtf.getText());
				this.leftToPay_txtf.setText(this.leftToPay + "");
				CatalogOfPredefinedProductsController.order.setTop(TypeOfPayment.CASH);
			}
			if (this.paymentOptionsCB.getValue() == TypeOfPayment.CREDITCARD) {
				this.credit_txtf.setText(this.amount_txtf.getText());
				this.leftToPay -= Double.valueOf(this.amount_txtf.getText());
				this.leftToPay_txtf.setText(this.leftToPay + "");
				CatalogOfPredefinedProductsController.order.setTop(TypeOfPayment.CREDITCARD);
			}
			if (this.paymentOptionsCB.getValue() == TypeOfPayment.BALANCE) {
				if(ChatClient.customer.getBalance() >= leftToPay) {
				this.leftToPay -= Double.valueOf(this.amount_txtf.getText());
				this.leftToPay_txtf.setText(this.leftToPay + "");
				ChatClient.customer.setBalance(ChatClient.customer.getBalance()-Double.valueOf(this.amount_txtf.getText()));
				this.balance_txtf.setText(ChatClient.customer.getBalance()+"");
				CatalogOfPredefinedProductsController.order.setTop(TypeOfPayment.BALANCE);
				}else {
					this.amount_txtf.setStyle("-fx-border-color: red");
					this.errorPayment.setText("Fill Correct Amount field You Have Not This Balance Amount!");
				}
		
			}
		}
		this.amount_txtf.setText("");
		this.amount_txtf.setPromptText("0");
	}
	/**
	 * checking the fields if its fill in the true way
	 * @return true if the fields true else return false
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
/**
 * Representing the payment options 
 *  * @param event An ActionEvent representing the payment option button 
 */
	@FXML
	void paymentOptions(ActionEvent event) {
		this.paymentOptionsCB.setStyle("-fx-border-color: black");
	}

	@FXML
	void amountAction(ActionEvent event) {

	}
/**
 * Finishing the payment operation 
 * @param event An ActionEvent representing the finish payment button 
 */
	@FXML
	void finishPayment(ActionEvent event) {

		if (this.leftToPay == 0) {
			Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			alert.setTitle("Finished Order");
			alert.setHeaderText("Finisher Order Successfully");
			alert.setContentText("");

			this.order = CatalogOfPredefinedProductsController.order;
			this.order.setItemsList(CatalogOfSelfdefinedItemsController.order.getItemsList());
			this.order.setTotalItemsPrice(CatalogOfSelfdefinedItemsController.order.getTotalItemsPrice());
			this.order.setOrderPrice(CatalogOfSelfdefinedItemsController.order.getTotalItemsPrice()
					+ CatalogOfPredefinedProductsController.order.getTotalPrductsPrice());
			this.order.setCustomerEmail(ChatClient.user.getEmail());
			this.order.setCustomerFristName(ChatClient.user.getFirstName());
			this.order.setCustomerId(ChatClient.user.getId());
			this.order.setCustomerPhoneNumber(ChatClient.user.getPhoneNumber());
			this.order.setCustomerLastName(ChatClient.user.getLastName());
			if(CustomerMainController.backToDeliveryOrTakeAwayl==true) {
				this.order.setOrderPrice(CatalogOfSelfdefinedItemsController.order.getTotalItemsPrice()
					+ CatalogOfPredefinedProductsController.order.getTotalPrductsPrice() + this.order.deliveryFee);
				this.order.setDilevery(true);
			}
			else {
				this.order.setDilevery(false);
			}
			
			if(ChatClient.customer.getCustomerType()==CustomerType.NEWCUSTOMER) {
				
				this.order.setOrderPrice(this.order.getOrderPrice()*0.8);
				try {
					JavaMailUtil.sendMail(ChatClient.customer.getEmail(), "your first payment", "you have 20% discount for first payment");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			ChatClient.customer.setCustomerType(CustomerType.BUSINESS);
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.UpdateBalanceCustomerType,ChatClient.customer));
			Date orderExecuteDate = new Date();/////
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");/////
			String orderDate = sdf.format(orderExecuteDate);////
			System.out.println(orderDate);
			order.setCurrentOrderDate(orderExecuteDate);
			Object ob = order;
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.FinishOrder,ob));
			//System.out.println(this.order.toString());
			order=new Orders();
			CatalogOfSelfdefinedItemsController.order=new Orders();
			CatalogOfPredefinedProductsController.order=new Orders();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			CustomerMainController cppc = new CustomerMainController();
			try {
				cppc.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			this.errorPayment.setText("The Order Not Finished!");
			this.errorPayment.setFill(Color.RED);
			this.errorPayment.setFont(Font.font("Arial", 14));
			this.errorPayment.setStyle("-fx-text-fill: red;");
			this.errorPayment.setStyle("-fx-border-color: red");
		}
	}
/**
 * Represnting the remove amount operation 
 * @param event An ActionEvent representing the remove amount button 
 */
	@FXML
	void removeAmount(ActionEvent event) {
		this.errorPayment.setFill(Color.RED);
		this.errorPayment.setFont(Font.font("Arial", 14));
		this.errorPayment.setStyle("-fx-text-fill: red;");
		this.errorPayment.setStyle("-fx-border-color: red");

		if (this.paymentOptionsCB.getValue() == null) {
			this.paymentOptionsCB.setStyle("-fx-border-color: red");
			this.errorPayment.setText("Fill Payment Options Field!");
		}
		if (this.amount_txtf.getText().isEmpty()) {
			this.errorPayment.setText("Fill Amount Field!");
			this.amount_txtf.setStyle("-fx-border-color: red");

		} else if (checktext(this.amount_txtf.getText()) == false) {
			this.amount_txtf.setStyle("-fx-border-color: red");
			this.errorPayment.setText("Fill ligal Amount field!");
		} else if (Double.valueOf(this.amount_txtf.getText()) < 0) {
			this.amount_txtf.setStyle("-fx-border-color: red");
			this.errorPayment.setText("Fill Correct Amount field!");
		} else {

			if (this.paymentOptionsCB.getValue() == TypeOfPayment.CASH) {

				if (Double.valueOf(this.cash_txtf.getText()).equals(0.0)) {
					this.errorPayment.setText("The Amount Of Cash Is Illigal!");
					this.errorPayment.setText("Fill Payment Options Field!");
					this.amount_txtf.setStyle("-fx-border-color: red");
				} else if (Double.valueOf(this.cash_txtf.getText()) < Double.valueOf(this.amount_txtf.getText())) {
					this.errorPayment.setText("Fill Payment Options Field!");
					this.amount_txtf.setStyle("-fx-border-color: red");
					this.errorPayment.setText("The Amount Bigger Than Cash!");
				} else {
					double help = Double.valueOf(this.cash_txtf.getText()) - Double.valueOf(this.amount_txtf.getText());
					this.leftToPay += Double.valueOf(this.amount_txtf.getText());
					this.cash_txtf.setText(help + "");
					this.leftToPay_txtf.setText(this.leftToPay + "");
					this.amount_txtf.setStyle("-fx-border-color: black");
				}
			} else if (this.paymentOptionsCB.getValue() == TypeOfPayment.CREDITCARD) {
				if (Double.valueOf(this.credit_txtf.getText()).equals(0.0)) {
					this.errorPayment.setText("The Amount Of Cash Is Illigal!");
					this.errorPayment.setText("Fill Payment Options Field!");
					this.amount_txtf.setStyle("-fx-border-color: red");
				} else if (Double.valueOf(this.credit_txtf.getText()) < Double.valueOf(this.amount_txtf.getText())) {
					this.errorPayment.setText("Fill Payment Options Field!");
					this.amount_txtf.setStyle("-fx-border-color: red");
					this.errorPayment.setText("The Amount Bigger Than Credit!");
				} else {
					double help = Double.valueOf(this.credit_txtf.getText())
							- Double.valueOf(this.amount_txtf.getText());
					this.leftToPay += Double.valueOf(this.amount_txtf.getText());
					this.credit_txtf.setText(help + "");
					this.leftToPay_txtf.setText(this.leftToPay + "");
					this.amount_txtf.setStyle("-fx-border-color: black");
				}

			} else if (this.paymentOptionsCB.getValue() == TypeOfPayment.BALANCE) {
				
				if(firstBalance- ChatClient.customer.getBalance() >= Double.valueOf(this.amount_txtf.getText())) {
					 ChatClient.customer.setBalance( ChatClient.customer.getBalance()+Double.valueOf(this.amount_txtf.getText()));
					 this.leftToPay += Double.valueOf(this.amount_txtf.getText());
					 this.balance_txtf.setText(ChatClient.customer.getBalance() + "");
						this.leftToPay_txtf.setText(this.leftToPay + "");
						this.amount_txtf.setStyle("-fx-border-color: black");
				}
				else {
					this.amount_txtf.setStyle("-fx-border-color: red");
					this.errorPayment.setText("Return Correct Value To Balance");
				}
//				if (Double.valueOf(this.balance_txtf.getText()).equals(0.0)) {
//					this.errorPayment.setText("The Amount Of Cash Is Illigal!");
//					this.errorPayment.setText("Fill Payment Options Field!");
//					this.amount_txtf.setStyle("-fx-border-color: red");
//				} else if (Double.valueOf(this.balance_txtf.getText()) < Double.valueOf(this.amount_txtf.getText())) {
//					this.errorPayment.setText("Fill Payment Options Field!");
//					this.amount_txtf.setStyle("-fx-border-color: red");
//					this.errorPayment.setText("The Amount Bigger Than Credit!");
//				} else {
//					double help = Double.valueOf(this.balance_txtf.getText())
//							- Double.valueOf(this.amount_txtf.getText());
//					this.leftToPay += Double.valueOf(this.amount_txtf.getText());
//					this.balance_txtf.setText(help + "");
//					this.leftToPay_txtf.setText(this.leftToPay + "");
//					this.amount_txtf.setStyle("-fx-border-color: black");
//				}

			}

		}
		this.amount_txtf.setText("");
		this.amount_txtf.setPromptText("0");
	}

	double firstBalance=0;	
	/**
	 * Initialize the details of the payment 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GiveBalanceEmailCustomerType,ChatClient.user));
		firstBalance=ChatClient.customer.getBalance();
		if (CustomerMainController.backToDeliveryOrTakeAwayl == true) {
			this.leftToPay = CatalogOfSelfdefinedItemsController.order.getDeliveryFee();
		}
		this.leftToPay += CatalogOfPredefinedProductsController.order.getTotalPrductsPrice()
				+ CatalogOfSelfdefinedItemsController.order.getTotalItemsPrice();
		this.credit_txtf.setDisable(true);
		this.cash_txtf.setDisable(true);
		this.balance_txtf.setDisable(true);
		this.leftToPay_txtf.setDisable(true);
		paymentOptionsCB.getItems().setAll(TypeOfPayment.CASH, TypeOfPayment.CREDITCARD,TypeOfPayment.BALANCE);
		this.leftToPay_txtf.setText(this.leftToPay + "");
		this.cash_txtf.setText("0.0");
		this.credit_txtf.setText("0.0");
		this.balance_txtf.setText(ChatClient.customer.getBalance() + "");

	}
}
