package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
/**
 * Representing as controller of the Main screen of the Zerli App
 *@author Majd Zbedat
 */
public class WelcomeToZerliController {
/**
 * Representing the Exit action ending the action
 * @param event An ActionEvent representing the exit button 
 */
    @FXML
    void exitFunction(ActionEvent event) {
     
	    System.exit(0);
    }
/**
 * login the system and continue to the next window
 * @param event An ActionEvent Representing the login button 
 */
    @FXML
    void pushFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }

    
    
	int initialX, initialY;
/**
 * Starting the main stage of the main screen 
 * @param primaryStage A Stage representing the primary stage of the main screen of the app
 * @throws Exception An exception thrown in case of exception 
 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/WelcomeToZerli.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Welcome to Zerli ");
		if (ClientConnectionController.flagMove) {
			primaryStage.initStyle(StageStyle.UNDECORATED);
			ClientConnectionController.flagMove = false;
		}
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
}
