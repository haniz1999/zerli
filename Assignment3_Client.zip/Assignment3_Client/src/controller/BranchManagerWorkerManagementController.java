package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.Users;
import common.BranchWorker;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller displays the worker management for the branch manager
 * @author Majd Zbedat
 *
 */
public class BranchManagerWorkerManagementController  implements Initializable{

	private int initialX, initialY;
	public static  BranchWorker  branchPrimaryKeyOfIdWorker;

	public static ObservableList<BranchWorker> branchWorkerList;

    @FXML
    private Text Alarttxt;

    @FXML
    private Button Backbtn;
 

    @FXML
    private TableView<BranchWorker> BranchWorkerTable;

    @FXML
    private TableColumn<BranchWorker, String> Worker_StatusColumn;
   

    @FXML
    private Button Edit_statusbnt;

    @FXML
    private TableColumn<BranchWorker, String> First_NameColumn;

    @FXML
    private TableColumn<BranchWorker, String> Last_NameColumn;

    @FXML
    private TableColumn<BranchWorker, String> Worker_IdColumn;

    @FXML
    private Button exitBtn;
    /**
     * Representing the back button
     * @param event An ActionEvent representing the back button action
     */
    @FXML
    void backFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerMainController BMMC= new BranchManagerMainController();
		try {
			BMMC.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
/**
 * Representing the edit status button 
 * @param event An ActionEvent representing the edit status button action
 */
    @FXML
    void editStatusFunction(ActionEvent event) {
    	branchPrimaryKeyOfIdWorker = this.BranchWorkerTable.getSelectionModel().getSelectedItem();
		 if (branchPrimaryKeyOfIdWorker == null) {
			 Alarttxt.setText("Please select row");
			 Alarttxt.setFill(Color.RED);
			 Alarttxt.setFont(Font.font("Arial", 14));
		      Alarttxt.setStyle("-fx-text-fill: red;");
		 }
		 else {
    	 Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	 BranchManagerWorkerPermissionController BMWPC= new BranchManagerWorkerPermissionController();
			try {
				BMWPC.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }
    }

	/**
	 * Representing the exit button controller for branch manager worker management screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exit(ActionEvent event) {
    	Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
    }
    
    
    
/**
 * Representing the refresh button 
 * @param event An ActionEvent represeting the refresh button action
 */
	@FXML
	void refresh(ActionEvent event) {
		this.BranchWorkerTable.getItems().clear();
		initialize(null, null);
	}
    
	  /**
	  * Representing the Starting screen of the branch manager worker management
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */

    public void start(Stage stage) throws IOException {
    	try {
			AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerWorkerManagement.fxml"));
			Scene scene = new Scene(root);
			stage.setTitle("Branch Worker Management");
			stage.setScene(scene);
			stage.show();

			scene.setOnMousePressed(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					scene.setCursor(Cursor.MOVE);
					initialX = (int) (stage.getX() - move.getScreenX());
					initialY = (int) (stage.getY() - move.getScreenY());
				}
			});

			scene.setOnMouseDragged(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					stage.setX(move.getScreenX() + initialX);
					stage.setY(move.getScreenY() + initialY);
				}
			});

			scene.setOnMouseReleased(move -> {
				scene.setCursor(Cursor.DEFAULT);
			});
    	}catch(Exception e) {
    		e.printStackTrace();
    	}
		}
/**
 * Initialize the worker's details
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		try {
			
			
		
			Object obj = ChatClient.user.getId()+",";
			
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.BranchManager, obj));
			
           Object obj1 = ChatClient.branchManagerList.get(0).getBranchName()+",";	
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.BranchWorker, obj1));
			

                 System.out.println(ChatClient.branchWorker.get(0).getWorkerPosition());


		this.Worker_IdColumn.setCellValueFactory(new PropertyValueFactory<BranchWorker, String>("Id"));
		this.First_NameColumn.setCellValueFactory(new PropertyValueFactory<BranchWorker, String>("FirstName"));
		this.Last_NameColumn.setCellValueFactory(new PropertyValueFactory<BranchWorker, String>("LastName"));
		this.Worker_StatusColumn.setCellValueFactory(new PropertyValueFactory<BranchWorker, String>("workerPosition"));
		
	
		branchWorkerList = FXCollections.observableArrayList(ChatClient.branchWorker);
		BranchWorkerTable.setItems(branchWorkerList);
	}		
	
		catch(Exception e) {
			e.printStackTrace();
		}

}
	
	
	
	
	
	
	
}
