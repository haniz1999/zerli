package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.Year;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.IncomeQuarterDataReports;
import common.OrderDataReport;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing as controller for the CEO equal reports screen
 * @author Laith Sadik
 *
 */
public class CEOViewEqualReportsController implements Initializable {

	public static String year1 = "";
	public static String quarter1 = "";
	public static String year2 = "";
	public static String quarter2 = "";

	private int initialX, initialY;
/**
 * Representing the screen of the primary screen of the CEO equal reports
 * @param primaryStage  A Stage representing the primary stage of the equal reports
 * @throws Exception thrown if an error happen 
 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CEOViewEqualsQuarterReports.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	@FXML
	private Text firstErrorText;

	@FXML
	private Text secondErrorText;
	@FXML
	private Button exitBtn;

	@FXML
	private ComboBox<String> firstBranchCB;

	@FXML
	private ComboBox<String> firstQuarterCB;

	@FXML
	private ComboBox<String> fisrtYearCB;

	@FXML
	private ComboBox<String> secondBranchCB;

	@FXML
	private ComboBox<String> secondQuarterCB;

	@FXML
	private ComboBox<String> secondYearCB;

	@FXML
	private Button viewReportsBtn;
/**
 * Initialize the details of the equal reports 
 * @param location  A URL representing the location 
 * @param resources A ResourceBundle representing the resources
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		this.fisrtYearCB.setValue("Year");
		this.firstBranchCB.setValue("Branch");
		this.firstQuarterCB.setValue("Quarter");
		this.secondBranchCB.setValue("Branch");
		this.secondQuarterCB.setValue("Quarter");
		this.secondYearCB.setValue("Year");
		this.firstErrorText.setFill(Color.RED);
		this.firstErrorText.setFont(Font.font("Arial", 14));
		this.firstErrorText.setStyle("-fx-text-fill: red;");
		this.firstErrorText.setStyle("-fx-border-color: red");
		this.secondErrorText.setFill(Color.RED);
		this.secondErrorText.setFont(Font.font("Arial", 14));
		this.secondErrorText.setStyle("-fx-text-fill: red;");
		this.secondErrorText.setStyle("-fx-border-color: red");
		int i;
		Year y = Year.now();
		for (i = y.getValue(); i > 2000; --i) {
			this.fisrtYearCB.getItems().add("" + i);
		}

		for (i = 1; i < 5; ++i) {
			this.firstQuarterCB.getItems().add("" + i);
		}
		ArrayList<String> list = new ArrayList<>();
		list.add("NORTH");
		list.add("SOUTH");
		list.add("CENTER");
		this.firstBranchCB.getItems().addAll(list);

		Year y1 = Year.now();
		for (i = y1.getValue(); i > 2000; --i) {
			this.secondYearCB.getItems().add("" + i);
		}

		for (i = 1; i < 5; ++i) {
			this.secondQuarterCB.getItems().add("" + i);
		}

		this.secondBranchCB.getItems().addAll(list);

	}
/**
 * Representing the reports 
 * @param event An ActionEvent representing the view report button action
 */
	@FXML
	void viewReports(ActionEvent event) {
		boolean flag1 = true, flag2 = true;
		if (checkTheFields()) {
			Object obj = this.firstBranchCB.getValue() + "," + this.fisrtYearCB.getValue() + ","
					+ this.firstQuarterCB.getValue();
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CheckIfThereFirstQIncomeReport, obj));
			flag1 = ChatClient.checkQuarterIncome;
			if (ChatClient.checkQuarterIncome == false)
				this.firstErrorText.setText("No Report In This Quarter And Branch And Year");
			obj = this.secondBranchCB.getValue() + "," + this.secondYearCB.getValue() + ","
					+ this.secondQuarterCB.getValue();
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CheckIfThereFirstQIncomeReport, obj));
			flag2 = ChatClient.checkQuarterIncome;
			if (ChatClient.checkQuarterIncome == false)
				this.secondErrorText.setText("No Report In This Quarter And Branch And Year");

			if (flag1 == true && flag2 == true) {

				this.year1 = this.fisrtYearCB.getValue();
				this.quarter1 = this.firstQuarterCB.getValue();
				this.year2 = this.secondYearCB.getValue();
				this.quarter2 = this.secondQuarterCB.getValue();

				obj = this.firstBranchCB.getValue() + "," + this.fisrtYearCB.getValue() + ","
						+ this.firstQuarterCB.getValue();
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetReadyQuarterIncomeRerports, obj));

				if ((boolean) ChatClient.objectList.get(0)==false) {
					obj = this.firstBranchCB.getValue() + "," + this.fisrtYearCB.getValue() + ","
							+ this.firstQuarterCB.getValue();
					ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetQuarterIncomeRerports, obj));
				} else {
					ChatClient.quarterIncomeReports = new ArrayList<IncomeQuarterDataReports>();
					for (int i = 1; i < ChatClient.objectList.size(); i++) {
						ChatClient.quarterIncomeReports.add((IncomeQuarterDataReports) ChatClient.objectList.get(i));
					}
				}
				obj = this.secondBranchCB.getValue() + "," + this.secondYearCB.getValue() + ","
						+ this.secondQuarterCB.getValue();
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetReadyQuarterIncomeRerports, obj));

				if ((boolean) ChatClient.objectList.get(0)==false) {
					obj = this.secondBranchCB.getValue() + "," + this.secondYearCB.getValue() + ","
							+ this.secondQuarterCB.getValue();
					ClientUI.chat
							.accept(new TranslateMessage(TranslateMessageType.GetSecondQuarterIncomeRerports, obj));
				} else {
				
					ChatClient.secondQuarterIncomeReports = new ArrayList<IncomeQuarterDataReports>();
					for (int i = 1; i < ChatClient.objectList.size(); i++) {
						ChatClient.secondQuarterIncomeReports
								.add((IncomeQuarterDataReports) ChatClient.objectList.get(i));
					}
				}

				Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
				ViewQuarterIncomeReportsController CEOVSR = new ViewQuarterIncomeReportsController();
				try {
					CEOVSR.start(stage);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}
/**
 * checking the fields if its fill in the true way
 * @return true if the fields true else return false
 */
	private boolean checkTheFields() {

		boolean Flag = true;
		if (this.fisrtYearCB.getValue().toString().equals("Year")
				&& this.firstBranchCB.getValue().toString().equals("Branch")
				&& this.firstQuarterCB.getValue().toString().equals("Quarter")) {
			this.firstErrorText.setText("Please Fill All The Fields In The Option1");
			Flag = false;
		} else if (this.fisrtYearCB.getValue().toString().equals("Year")
				&& this.firstBranchCB.getValue().toString().equals("Branch")) {
			this.firstErrorText.setText("Please Fill The Year And The Branch In The Option1");
			Flag = false;
		} else if (this.fisrtYearCB.getValue().toString().equals("Year")
				&& this.firstQuarterCB.getValue().toString().equals("Quarter")) {
			Flag = false;
			this.firstErrorText.setText("Please Fill The Year And The Quarter In The Option1");
		} else if (this.firstQuarterCB.getValue().toString().equals("Quarter")
				&& this.firstBranchCB.getValue().toString().equals("Branch")) {
			Flag = false;
			this.firstErrorText.setText("Please Fill The Quarter And Branch In Option1");
		} else if (this.firstBranchCB.getValue().toString().equals("Branch")) {
			Flag = false;
			this.firstErrorText.setText("Please Fill The Branch In Option1");
		} else if (this.firstQuarterCB.getValue().toString().equals("Quarter")) {
			Flag = false;
			this.firstErrorText.setText("Please Fill The Quarter In Option1");
		} else if (this.fisrtYearCB.getValue().toString().equals("Year")) {
			Flag = false;
			this.firstErrorText.setText("Please Fill The Year In Option1");
		}

		if (this.secondYearCB.getValue().toString().equals("Year")
				&& this.secondBranchCB.getValue().toString().equals("Branch")
				&& this.secondQuarterCB.getValue().toString().equals("Quarter")) {
			this.secondErrorText.setText("Please Fill All The Fields In Option2");
			Flag = false;
		} else if (this.secondYearCB.getValue().toString().equals("Year")
				&& this.secondBranchCB.getValue().toString().equals("Branch")) {
			this.secondErrorText.setText("Please Fill The Year And Branch In Option2");
			Flag = false;
		} else if (this.secondYearCB.getValue().toString().equals("Year")
				&& this.secondQuarterCB.getValue().toString().equals("Quarter")) {
			Flag = false;
			this.secondErrorText.setText("Please Fill The Year And Quarter In Option2");
		} else if (this.secondQuarterCB.getValue().toString().equals("Quarter")
				&& this.secondBranchCB.getValue().toString().equals("Branch")) {
			Flag = false;
			this.secondErrorText.setText("Please Fill The Quarter And Branch In Option2");
		} else if (this.secondBranchCB.getValue().toString().equals("Branch")) {
			Flag = false;
			this.secondErrorText.setText("Please Fill The Branch In Option2");
		} else if (this.secondQuarterCB.getValue().toString().equals("Quarter")) {
			Flag = false;
			this.secondErrorText.setText("Please Fill The Quarter In Option2");
		} else if (this.secondYearCB.getValue().toString().equals("Year")) {
			Flag = false;
			this.secondErrorText.setText("Please Fill The Year In Option2");
		}

		return Flag;
	}
	/**
	 * Exit from the equal reports screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
/**
 * representing the first branch 
 * @param event An ActionEvent representing the first branch text field
 */
	@FXML
	void firstBranch(ActionEvent event) {
this.firstErrorText.setText("");
	}
/**
 * Representing the first quarter
 * @param event  An ActionEvent representing the first quarter text field 
 */
	@FXML
	void firstQuarter(ActionEvent event) {
		this.firstErrorText.setText("");
	}
	/**
	 * Representing the first year
	 * @param event  An ActionEvent representing the first year text field 
	 */
	@FXML
	void firstYear(ActionEvent event) {
		this.firstErrorText.setText("");
	}
	/**
	 * Representing the second branch 
	 * @param event  An ActionEvent representing the second branch text field 
	 */
	@FXML
	void secondBranch(ActionEvent event) {
		this.secondErrorText.setText("");
	}
	/**
	 * Representing the second quarter
	 * @param event  An ActionEvent representing the second quarter text field 
	 */
	@FXML
	void secondQuarter(ActionEvent event) {
		this.secondErrorText.setText("");
	}
	/**
	 * Representing the second year
	 * @param event  An ActionEvent representing the second year text field 
	 */
	@FXML
	void secondYear(ActionEvent event) {
		this.secondErrorText.setText("");
	}

	@FXML
	private Button backBtn;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CEOMainController CEOVSR = new CEOMainController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
