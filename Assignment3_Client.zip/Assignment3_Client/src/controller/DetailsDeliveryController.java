package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Delivery;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the delivery details screen 
 * @author Laith Sadik
 *
 */
public class DetailsDeliveryController implements Initializable {

	@FXML
	private ComboBox<String> Prefix_cmbx;

	@FXML
	private Button back_btn;

	@FXML
	private ComboBox<String> city_cmbx;

	@FXML
	private TextField deliveryprice_txtf;

	@FXML
	private Text error_txt;

	@FXML
	private Button exit_btn;

	@FXML
	private TextField firstName_txtf;

	@FXML
	private TextField lastName_txtf;

	@FXML
	private Button next_btn;

	@FXML
	private TextField number_txtf;

	@FXML
	private ComboBox<String> street_cmbx;

	@FXML
	void city(ActionEvent event) {

	}

	@FXML
	void prefix(ActionEvent event) {

	}

	@FXML
	void street(ActionEvent event) {

	}

	private int initialX;
	private int initialY;
	/**
	 * Representing the screen of the primary screen of the delivery details
	 * @param primaryStage  A Stage representing the primary stage of the delivery details
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/DetailsDelivery.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Filling Order Details");
		primaryStage.setScene(scene);

		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	static {
		CustomerMainController.backToDeliveryOrTakeAwayl = true;
	}
	/**
	 * Initialize the details of the delivery details 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		List<String> prefixtype = new ArrayList<>();
		prefixtype.add("04");
		prefixtype.add("054");
		prefixtype.add("052");
		prefixtype.add("050");
		Prefix_cmbx.getItems().addAll((Collection<? extends String>) prefixtype);
		prefixtype.clear();
		prefixtype.add("shafamr");
		prefixtype.add("skhneen");
		prefixtype.add("Ein Mahel");
		prefixtype.add("Haifa");
		city_cmbx.getItems().addAll((Collection<? extends String>) prefixtype);
		prefixtype.clear();
		prefixtype.add("ben gurion");
		prefixtype.add("hotsot hamfrts");
		prefixtype.add("grnata");
		prefixtype.add("tal hai");
		street_cmbx.getItems().addAll((Collection<? extends String>) prefixtype);
		deliveryprice_txtf.setDisable(true);

	}
/**
 * Representing the next screen the next step
 * @param event An ActionEvent representing the next button
 */
	@FXML
	void Next(ActionEvent event) {
		boolean flag = false;
		if (this.Prefix_cmbx.getValue() == null) {
			Prefix_cmbx.setStyle("-fx-border-color: red");
			this.error_txt.setText("Fill all the fields!");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else {
			this.Prefix_cmbx.setStyle("-fx-border-color: black");
		}
		if (this.city_cmbx.getValue() == null) {
			city_cmbx.setStyle("-fx-border-color: red");
			this.error_txt.setText("Fill all the fields!");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else {
			this.city_cmbx.setStyle("-fx-border-color: black");
		}

		if (this.street_cmbx.getValue() == null) {
			street_cmbx.setStyle("-fx-border-color: red");
			this.error_txt.setText("Fill all the fields!");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else {
			this.street_cmbx.setStyle("-fx-border-color: black");
		}
		if (this.firstName_txtf.getText().equals("")) {
			firstName_txtf.setStyle("-fx-border-color: red");
			this.error_txt.setText("Fill all the fields!");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else {
			firstName_txtf.setStyle("-fx-border-color: black");
		}
		if (this.lastName_txtf.getText().equals("")) {
			lastName_txtf.setStyle("-fx-border-color: red");
			this.error_txt.setText("Fill all the fields!");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else {
			lastName_txtf.setStyle("-fx-border-color: black");
		}
		if (this.number_txtf.getText().equals("") || checktext(number_txtf.getText()) == false) {
			number_txtf.setStyle("-fx-border-color: red");
			this.error_txt.setText("Fill all the fields!");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else if (this.number_txtf.getText().length() > 7 || this.number_txtf.getText().length() < 7) {
			number_txtf.setStyle("-fx-border-color: red");
			this.error_txt.setText("The last digit in phone number is not 7 digits");
			this.error_txt.setFill(Color.RED);
			this.error_txt.setFont(Font.font("Arial", 14));
			this.error_txt.setStyle("-fx-text-fill: red;");
			flag = true;
		} else {
			number_txtf.setStyle("-fx-border-color: black");
		}

		if (!flag) {

			Delivery ta = new Delivery();
			ta.setFirstName(this.firstName_txtf.getText());
			ta.setLastName(this.lastName_txtf.getText());
			ta.setPhoneNumber(this.Prefix_cmbx.getValue().toString() + "" + this.number_txtf.getText());
			ta.setCity(this.city_cmbx.getValue());
			ta.setStreet(this.street_cmbx.getValue());
			CatalogOfPredefinedProductsController.order.setDelivery(ta);
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			PaymentController cpc = new PaymentController();
			try {
				cpc.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	/**
	 * checking the text if its fill in a true way
	 * @return true if the fields true else return false
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Integer.parseInt(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
/**
 * Back to the previous window 
 * @param event An ActionEvent representing the back button
 */
	@FXML
	void Back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		DetailsOrderController obcc = new DetailsOrderController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the delievry details screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

}
