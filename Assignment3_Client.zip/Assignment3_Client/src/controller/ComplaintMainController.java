package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * Representing a controller of the compliant main screen 
 * @author Laith Sadik
 *
 */
public class ComplaintMainController implements Initializable {

	public static boolean warn = false;

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub

	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the compliant 
	 * @param primaryStage  A Stage representing the primary stage of the compliant 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ComplaintMainController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
/**
 * log out from the compliant screen 
 * @param event An ActionEvent representing the log out button 
 */
	@FXML
	void LogoutBtn(ActionEvent event) {

		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.complaintswarn, null));
		if (ChatClient.warncomplaints.size() > 0) {
			warn = true;
			StringBuilder temp = new StringBuilder();
			Alert alert = new Alert(AlertType.WARNING);
			alert.setTitle("Warning");
			if (ChatClient.warncomplaints.size() == 1) {
				temp.append("The Complint with Id:(");
				temp.append(ChatClient.warncomplaints.get(0).getIdcomplaint() + ") ");
				temp.append("that you have not yet answered that!!");
				alert.setContentText("You Must Response That Please.");
			} else {
				temp.append("The Complints with Id:(");
				for (int i = 0; i < ChatClient.warncomplaints.size(); i++) {
					if (ChatClient.warncomplaints.size() == i + 1)
						temp.append(ChatClient.warncomplaints.get(i).getIdcomplaint() + ") ");
					else
						temp.append(ChatClient.warncomplaints.get(i).getIdcomplaint() + ", ");
				}
				temp.append("that you have not yet answered them!!");
				alert.setContentText("You Must Response Them Please.");
			}
			alert.setHeaderText(temp.toString());
			alert.showAndWait();

			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			DetailsComplaintController gui = new DetailsComplaintController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Object logout = ChatClient.user;
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
			ChatClient.user.setLoggedIn(false);
			LogInController login = new LogInController();
			try {
				login.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
/**
 * Representing the register compliant 
 * @param event An ActionEvent representing the register button
 */
	@FXML
	void Registercomplaint(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		RegisterComplaintController gui = new RegisterComplaintController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Representing the response compliant 
	 * @param event An ActionEvent representing the response button
	 */
	@FXML
	void Responsecomplaint(ActionEvent event) {
		warn = false;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		DetailsComplaintController gui = new DetailsComplaintController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the compliant screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
}
