package controller;

import common.MyListener;
import common.Products;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
/**
 * Representing a controller of the product main screen 
 * @author Othman Laith Sadik
 *
 */
public class ProductsController {


	@FXML
	private ImageView p_ImageView;

    @FXML
    private Label pName_label;

    @FXML
    private Label pPrice_label;


	private Products product;
    MyListener myListener;
    /**
     * Representing the click action on product 
     * @param event An ActionEvent representing the click action 
     */
    @FXML
    void click(MouseEvent event) { 
    	myListener.OnClickListener(product); 
    }
	/**
	 * Sets the product data 
	 * @param product     A product representing the product details 
	 * @param myListener  MyListener representing the listener 
	 */
	public void setData(Products product,MyListener myListener) {
		this.myListener = myListener;
		this.product = product;
		pName_label.setText(product.getProductName());
		pPrice_label.setText(""+product.getPrice()+"");
		Image image = new Image(getClass().getResourceAsStream(product.getImagePath()));
		 p_ImageView.setImage(image);
	}
}
