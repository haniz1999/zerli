package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Orders;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
/**
 * Representing a controller of the order by catalog screen 
 * @author Othman
 *
 */
public class OrderByCatalogController implements Initializable {

	public static boolean backFlag;

	@Override
	public void initialize(URL location, ResourceBundle resources) {

	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the  order by catalog
	 * @param primaryStage  A Stage representing the primary stage of the  order by catalog
	 * @throws Exception thrown if an error happen 
	 */ 
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/OrderByCatalogController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Order Options");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private Button backBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private Button predefinedBtn;

	@FXML
	private Button selfdefinedBtn;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		CatalogOfSelfdefinedItemsController.order.getItemsList().clear();
		CatalogOfSelfdefinedItemsController.order.setTotalItemsPrice(0);
		CatalogOfPredefinedProductsController.order.getProductsList().clear();
		CatalogOfPredefinedProductsController.order.setTotalPrductsPrice(0);
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CustomerMainController cmc = new CustomerMainController();
		try {
			cmc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	/**
	 * Exit from the  screen order by catalog
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
/**
 * Representing the predefined catalog 
 * @param event An ActionEvent representing the predefined catalog button 
 */
	@FXML
	void predefined(ActionEvent event) {
		OrderByCatalogController.backFlag = false;
		if (CustomerMainController.viewOrOrderFlag == false) {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			CatalogOfPredefinedProductsController cpc = new CatalogOfPredefinedProductsController();
			try {
				cpc.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		} else {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			ViewCatalogOfPredefinedProductsController vocpc = new ViewCatalogOfPredefinedProductsController();
			try {
				vocpc.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	/**
	 * Representing the self defined catalog 
	 * @param event An ActionEvent representing the self defined catalog button 
	 */
	@FXML
	void selfdefined(ActionEvent event) {
		OrderByCatalogController.backFlag=true;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		DetailsSelfdefinedItemController cs = new DetailsSelfdefinedItemController();

		try {
			cs.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
