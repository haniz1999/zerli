package controller;

import common.Item;
import common.MyListener;
import common.Products;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
/**
 * Representing a controller of the item screen 
 * @author Othman
 *
 */
public class ItemController {

    @FXML
    private Label iName_label;

    @FXML
    private Label iPrice_label;

    @FXML
    private ImageView i_ImageView;


	private Item item;
    MyListener myListener;
    /**
     * Representing the click action on item
     * @param event An ActionEvent representing the click action 
     */
    @FXML
    void click(MouseEvent event) {
    	myListener.OnClickListener(item); 
    }
/**
 * Sets the data of the item 
 * @param item        An Item representing the item details to set 
 * @param myListener  MyLiser representing the lisener 
 */
	public void setData(Item item,MyListener myListener) {
		this.myListener = myListener;
		this.item = item;
		iName_label.setText(item.getItemName());
		iPrice_label.setText(""+item.getPrice()+"");
		Image image = new Image(getClass().getResourceAsStream(item.getPicturePath()));
		 i_ImageView.setImage(image);
	}
}