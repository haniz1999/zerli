package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.text.Text;
import javafx.scene.control.TextField;
/**
 * Representing a controller of the monetary compensation screen 
 * @author Othman
 *
 */
public class MonetaryCompensationController implements Initializable {

	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		monetaryCompensation.setText("0.0");
	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the  monetary compensation
	 * @param primaryStage  A Stage representing the primary stage of the monetary compensation
	 * @throws Exception thrown if an error happen 
	 */ 
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/Monetarycompensation.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private Text alert_txt;
	@FXML
	private TextField monetaryCompensation;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		DetailsComplaintController obcc = new DetailsComplaintController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
    /**
     * Exit from the marketing worker screen 
     * @param event An ActionEvent representing the exit button action 
     */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
	/**
	 * Finishing the operation 
	 * @param event An ActionEvent representing the finish button 
	 */
    @FXML
    void Finish_btn(ActionEvent event) {
    	boolean flag = true;
    	if (monetaryCompensation.getText().isEmpty()) {
    		flag = false;
    		alert_txt.setText("Please fill the field of monetary compensation:");
    		alert_txt.setFill(Color.RED);
    		alert_txt.setFont(Font.font("Arial", 12));
    		alert_txt.setStyle("-fx-text-fill: red;");
    	}
    	if (!checktext(monetaryCompensation.getText())) {
    		flag = false;
    		alert_txt.setText("Please Fill Valid monetary compensation: ");
    		alert_txt.setFill(Color.RED);
    		alert_txt.setFont(Font.font("Arial", 12));
    		alert_txt.setStyle("-fx-text-fill: red;");
    	}
    	if(flag==true)
    	{
    		Object Obj=monetaryCompensation.getText()+" / "+DetailsComplaintController.idCustomer+" / "+DetailsComplaintController.idcomplaint;
    		System.out.println("xxxxxxxxxxxxxxxxxxxxxx");
    		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.responseComplaint,Obj));
    		
    		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

    		DetailsComplaintController obcc = new DetailsComplaintController();
    		try {
    			obcc.start(stage);
    		} catch (Exception e) {
    			// TODO Auto-generated catch block
    			e.printStackTrace();
    		}
    	}
    }



    /**
     * checking the fields if its fill in the true way
     * @return true if the fields true else return false
     */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}

}
