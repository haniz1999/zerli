package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.IncomeQuarterDataReports;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the quarter income reports screen 
 * @author Laith Sadik
 *
 */
public class ViewQuarterIncomeReportsController implements Initializable {


	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the quarter income report 
	 * @param primaryStage  A Stage representing the primary stage of the quarter income reports
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewQuarterIncomeReports.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	/**
	 * Initialize the details of the quarter income reports 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.optionOneText.setFill(Color.RED);
		this.optionOneText.setFont(Font.font("Arial", 14));
		this.optionOneText.setStyle("-fx-text-fill: red;");
		this.optionOneText.setStyle("-fx-border-color: red");
		this.optionTwoText.setFill(Color.RED);
		this.optionTwoText.setFont(Font.font("Arial", 14));
		this.optionTwoText.setStyle("-fx-text-fill: red;");
		this.optionTwoText.setStyle("-fx-border-color: red");
		double totalCost1 = 0,totalCost2=0;
		this.firstCategortAxis.setLabel("Months");
		this.firstNumberAxis.setLabel("Total Cost In Month");
		XYChart.Series<String, Number> series;
		for(IncomeQuarterDataReports idr : ChatClient.quarterIncomeReports) {
			series = new XYChart.Series<>();
			Data<String, Number> data = new XYChart.Data<>(idr.getMonth(), idr.getTotlaCostMonth());
			series.getData().add(data);
			series.setName(idr.getMonth());
			this.firstBarChart.getData().add(series);
			totalCost1 += idr.getTotlaCostMonth();
		}
		 
		this.secondCategoryAxis.setLabel("Months");
		this.secondNumberAxis.setLabel("Total Cost In Month");
		XYChart.Series<String, Number> series2;
		for(IncomeQuarterDataReports idr : ChatClient.secondQuarterIncomeReports) {
			series2 = new XYChart.Series<>();
			Data<String, Number> data = new XYChart.Data<>(idr.getMonth(), idr.getTotlaCostMonth());
			series2.getData().add(data);
			series2.setName(idr.getMonth());
			this.secondBarChart.getData().add(series2);
			totalCost2 += idr.getTotlaCostMonth();
		}
		
		this.optionOneText.setText("Reports Of Year " + CEOViewEqualReportsController.year1 + " The " +CEOViewEqualReportsController.quarter1 + " Quarter ");
		this.optionTwoText.setText("Reports Of Year " + CEOViewEqualReportsController.year2 + " The " +CEOViewEqualReportsController.quarter2 + " Quarter ");
	}


    @FXML
    private Text optionOneText;

    @FXML
    private Text optionTwoText;
    
	@FXML
	private Button backBtn;

	@FXML
	private Button exitBtn;

	@FXML
	private BarChart<String, Number> firstBarChart;

	@FXML
	private CategoryAxis firstCategortAxis;

	@FXML
	private NumberAxis firstNumberAxis;

	@FXML
	private BarChart<String, Number> secondBarChart;

	@FXML
	private CategoryAxis secondCategoryAxis;

	@FXML
	private NumberAxis secondNumberAxis;
	/**
	 * Exit from the quarter income reports screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CEOViewEqualReportsController CEOVSR = new CEOViewEqualReportsController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
