package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Item;
import common.ProductType;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.control.ComboBox;
/**
 * Representing a controller that displays a screen for 
 *  updating the Product's details with product's id,name,type,composition,price and image path
 * @author Othman
 *
 */
public class AddUpdateProductController implements Initializable {
/**
 * Initialize the details of the product to update
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ObservableList<String> producttype = FXCollections.observableArrayList("StylesBouquet","SeedlingFlowers","SpecailZerli","BridalBouquet");
		productTypecmb.setItems(producttype);
		if (UpdateProductsController.me != null) {
			productID_txtf.setText(UpdateProductsController.me.getProductId());
			productID_txtf.setDisable(true);
			productName_txtf.setText(UpdateProductsController.me.getProductName());
			productTypecmb.setValue(UpdateProductsController.me.getProductType().name());
			productComposition_txtf.setText(UpdateProductsController.me.getProductComposition());
			price_txtf.setText(String.valueOf(UpdateProductsController.me.getPrice()));
			imagepath_txtf.setText(UpdateProductsController.me.getImagePath());
			imagepath_txtf.setVisible(false);
		} else {
			imagepath_txtf.setText("/images/white.png");
			imagepath_txtf.setVisible(false);
		}

	}

	private int initialX, initialY;
/**
 * Representing the main screen for updating the product
 * @param primaryStage   A stage representing the primary stage of the updating product
 * @throws Exception     An Exception that the method throws in station of exception
 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ProductDetailsUpdate.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private TextField imagepath_txtf;
	@FXML
	private Text alerttxt;

	@FXML
	private Button backbtn;

	@FXML
	private Button exitbtn;

	@FXML
	private TextField price_txtf;

	@FXML
	private TextField productComposition_txtf;

	@FXML
	private TextField productID_txtf;

	@FXML
	private TextField productName_txtf;


    @FXML
    private ComboBox<String> productTypecmb;



    @FXML
    void productType(ActionEvent event) {

    }
    /**
     * Representing the back button action 
     * @param event An ActionEvent representing the back click action
     */
	@FXML
	void Back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		UpdateProductsController gui = new UpdateProductsController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Representing the save action to saves the updating details
	 * @param event An ActionEvent representing the save's click
	 */
	@FXML
	void save(ActionEvent event) {
		if (productID_txtf.getText().isEmpty() ||productTypecmb.getValue()==null
				|| productComposition_txtf.getText().isEmpty()
				|| price_txtf.getText().isEmpty() || imagepath_txtf.getText().isEmpty()) {
			UpdateProductsController.flag = false;
			alerttxt.setText("Please Fill all fields");
			alerttxt.setFill(Color.RED);
			alerttxt.setFont(Font.font("Arial", 14));
			alerttxt.setStyle("-fx-text-fill: red;");
		}
		if(!checktext(productID_txtf.getText()))
		{
			UpdateProductsController.flag = false;
			alerttxt.setText("Please Fill Valid ID ");
			alerttxt.setFill(Color.RED);
			alerttxt.setFont(Font.font("Arial", 14));
			alerttxt.setStyle("-fx-text-fill: red;");
		}
		if(!checktext(price_txtf.getText()))
		{
			UpdateProductsController.flag = false;
			alerttxt.setText("Please Fill Valid price ");
			alerttxt.setFill(Color.RED);
			alerttxt.setFont(Font.font("Arial", 14));
			alerttxt.setStyle("-fx-text-fill: red;");
		}
		
		if (UpdateProductsController.flag == true && UpdateProductsController.me == null) {
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ProductListInCatalog, null));
			for (Products t1 : ChatClient.productList) {
				if (t1.getProductId().equals(productID_txtf.getText())) {
					UpdateProductsController.flag = false;
					alerttxt.setText("Please Fill another ID ");
					alerttxt.setFill(Color.RED);
					alerttxt.setFont(Font.font("Arial", 14));
					alerttxt.setStyle("-fx-text-fill: red;");
				}
			}
		}
		if (UpdateProductsController.flag == true) {
			if (UpdateProductsController.me != null) {
				Object ObjRemoveproduct;
				ObjRemoveproduct = (UpdateProductsController.me.getProductId());
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Deleteproduct, ObjRemoveproduct));
			}
			Products objAddproduct = new Products(productID_txtf.getText(), productName_txtf.getText(),
					ProductType.valueOf(productTypecmb.getValue()), productComposition_txtf.getText(),
					Double.valueOf(price_txtf.getText()), imagepath_txtf.getText(),0.0);

			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.addProduct, objAddproduct));

			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			UpdateProductsController gui = new UpdateProductsController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		UpdateProductsController.flag = true;
	}
	/**
	 * return true if the string strNum parse as double else return false
	 * @param strNum A string representing the text to check  
	 * @return false if the strNum is null or get exception else if the strNum representing as double returs true
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	/**
	 * Representing the exit button controller for 
	 * exiting from the updating item screen
	 * @param event An ActionEvent representing the exit's button
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}

}
