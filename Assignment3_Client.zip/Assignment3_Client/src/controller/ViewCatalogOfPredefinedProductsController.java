package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Item;
import common.MyListener;
import common.Orders;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * Representing a controller of the view catalog of the predefined products screen 
 * @author Othman Laith Sadik
 *
 */
public class ViewCatalogOfPredefinedProductsController implements Initializable {
	
	int initialX,initialY;
	/**
	 * Representing the screen of the primary screen of the view catalog of the predefined products 
	 * @param primaryStage  A Stage representing the primary stage of the view catalog of the predefined products
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewCatalogOfPredefinedProducts.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Catalog Selfdefiend Items");
		primaryStage.setScene(scene);
		primaryStage.show();
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});

	} 
	
	
	static Products addToCartProduct;
	public static Orders order;
	MyListener myListener;
	ArrayList<Products> list = new ArrayList<>();
	public static ArrayList<Products> addToCartList = new ArrayList<>();
	public static double totalPrice = 0;
	/**
	 * Initialize the details of the catalog
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		addToCartList.addAll(CatalogOfPredefinedProductsController.order.getProductsList());
		list.addAll(getData());
		setChooseProduct(list.get(0));
		myListener = new MyListener() {

			@Override
			public void OnClickListener(Products product) {
				setChooseProduct(product);
			}

			@Override
			public void OnClickListener(Item item) {
				// TODO Auto-generated method stub
				
			}

		};

		int col = 0, row = 1;
		try {
			for (int i = 0; i < list.size(); i++) {
				FXMLLoader fxmlLoader = new FXMLLoader();
				fxmlLoader.setLocation(getClass().getResource("/gui/Products.fxml"));

				AnchorPane ap = fxmlLoader.load();

				ProductsController pc = fxmlLoader.getController();
				pc.setData(list.get(i), myListener);

				if (col == 3) {
					col = 0;
					row++;
				}
				grid.add(ap, col++, row);

				GridPane.setMargin(ap, new Insets(10));
				grid.setMaxHeight(Region.USE_COMPUTED_SIZE);
				grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
				grid.setMinHeight(Region.USE_COMPUTED_SIZE);
				grid.setMaxWidth(Region.USE_COMPUTED_SIZE);
				grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
				grid.setMinWidth(Region.USE_COMPUTED_SIZE);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
/**
 * Gets the data of the products 
 * @return An ArrayList<Products> representing the product 
 */
	private ArrayList<Products> getData() {

		ArrayList<Products> pList = new ArrayList<>();
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.CatalogViewProducts, null));
		pList.addAll(ChatClient.productList);
		Products product;
		return pList;
	}
/**
 * Sets the products 
 * @param product An products representing the product details 
 */
	public void setChooseProduct(Products product) {
		addToCartProduct = product;
		idCart.setText(product.getProductId());
		nameCart.setText(product.getProductName());
		typeCart.setText(String.valueOf(product.getProductType()));
		compositionCart.setText(product.getProductComposition());
		priceCart.setText(product.getPrice() + "");
		discount_percentage_label.setText(product.getDiscount()+" %");
		Image image = new Image(getClass().getResourceAsStream(product.getImagePath()));
		imageCart.setImage(image);
		chooseProductCard.setStyle("-fx-background-color: " + "#CCCCCC" + ";\n" + "-fx-background-radius: 30;");
	}
	
	@FXML
	private Button back_btn;

	@FXML
	private VBox chooseProductCard;

	@FXML
	private Label compositionCart;

	@FXML
	private Text errorAddToCart;

	@FXML
	private Button exit_btn;

	@FXML
	private GridPane grid;

	@FXML
	private Label idCart;

	@FXML
	private ImageView imageCart;

	@FXML
	private Label nameCart;

	@FXML
	private Label priceCart;

	@FXML
	private ScrollPane scroll;

	@FXML
	private Label typeCart;

    @FXML
    private Label discount_percentage_label;
    /**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		CustomerMainController.viewOrOrderFlag =true;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		OrderByCatalogController obcc = new OrderByCatalogController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the catalog of the predefined products  screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

}
