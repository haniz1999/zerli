package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.SurveyAnswer;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * this window will show table view that include all the answered surveys 
 * @author rani
 * @author hani
 *
 */
public class ServiceSpecialistViewSurveysAnswersController implements Initializable {
	
	private int initialX;
	private int initialY;
	
	public static ObservableList<SurveyAnswer> surveysAnswersList;
	
	public static SurveyAnswer selected_surveyAnswer;


    @FXML
    private Button addPdfConclusionBtn;

    @FXML
    private Button backBtn;


    @FXML
    private Text errorText;

    @FXML
    private Button exitBtn;

    @FXML
    private Button helpBtn;

    @FXML
    private TableColumn<SurveyAnswer, String> branchWorkerIdCol;
    
    @FXML
    private TableColumn<SurveyAnswer, String> fillDateCol;
    
    @FXML
    private TableColumn<SurveyAnswer, String> q1AnswerCol;

    @FXML
    private TableColumn<SurveyAnswer, String> q2AnswerCol;

    @FXML
    private TableColumn<SurveyAnswer, String> q3AnswerCol;

    @FXML
    private TableColumn<SurveyAnswer, String> q4AnswerCol;

    @FXML
    private TableColumn<SurveyAnswer, String> q5AnswerCol;

    @FXML
    private TableColumn<SurveyAnswer, String> q6AnswerCol;

    @FXML
    private TableColumn<SurveyAnswer, String> surveyAnswerIdCol;

    @FXML
    private TableColumn<SurveyAnswer, String> surveyQuestionId;

    @FXML
    private TableView<SurveyAnswer> surveysAnswersTable;
    
    
/**
 * when the service special want to attach pdf that contains his conclusions
 * @param event
 */
    @FXML
    void addPdfConclusion(ActionEvent event) {
    	
    	selected_surveyAnswer = surveysAnswersTable.getSelectionModel().getSelectedItem();
    	
    	if(selected_surveyAnswer == null) {
    		errorText.setText("you shoud select a survey Answer first");
    	}
    	else {
    		Platform.runLater(new Runnable() {

				@Override
				public void run() {
			    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			    	ServiceSpecialistAOR ssaor = new ServiceSpecialistAOR();
					try {
						ssaor.start(stage);
					} catch (Exception e) {
						System.out.println("Error while openning view surveys window\n");
						e.printStackTrace();
					}	
				}
    		});
    	}
    }
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
    @FXML
    void back(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	ServiceSpecialistMainController BMMC= new ServiceSpecialistMainController();
		try {
			BMMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    /**
     * Exit from the view survey screen 
     * @param event An ActionEvent representing the exit button action 
     */
    @FXML
    void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
    }

    @FXML
    void help(ActionEvent event) {

    }
	
	

    /**
	 * Representing the screen of the primary screen of the view survey
	 * @param primaryStage  A Stage representing the primary stage of the view survey 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ServiceSpecialistViewSurveysAnswers.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("View Surveys Answers");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});		
	}

/**
 * Initialize the survey answers 
* @param location  A URL representing the location 
 * @param resources A ResourceBundle representing the resources
 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetSurveysAnswersList, null));

		
		
		surveyAnswerIdCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("surveyAnswerId"));
		surveyQuestionId.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("surveyQuestionId"));
		q1AnswerCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("q1answer"));
		q2AnswerCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("q2answer"));
		q3AnswerCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("q3answer"));
		q4AnswerCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("q4answer"));
		q5AnswerCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("q5answer"));
		q6AnswerCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("q6answer"));
		fillDateCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("fillDate"));
		branchWorkerIdCol.setCellValueFactory(new PropertyValueFactory<SurveyAnswer, String>("branchWorkerId"));


		surveysAnswersList = FXCollections.observableArrayList(ChatClient.surveysAnswersList);
		surveysAnswersTable.setItems(surveysAnswersList);
	}

}
