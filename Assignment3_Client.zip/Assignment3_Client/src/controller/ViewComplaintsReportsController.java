package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ComplaintsDataReports;
import common.IncomeDataReport;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
/**
 * Representing a controller of the complaints reports screen 
 * @author Othman Laith Sadik
 *
 */
public class ViewComplaintsReportsController implements Initializable {

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the complaints reports
	 * @param primaryStage  A Stage representing the primary stage of the compliants reports
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewComplaintsReports.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private NumberAxis NumberAxis;

	@FXML
	private CategoryAxis categoryAxis;
	@FXML
	private Button backBtn;

	@FXML
	private BarChart<String, Number> barChart;

	@FXML
	private TextArea complaints_txtarea;

	@FXML
	private Button exitBtn;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ViewSystemReportsController CEOVSR = new ViewSystemReportsController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the compliant reports screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Initialize the details of the compliants reports  
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		int totalComplaints=0;
		this.complaints_txtarea.setEditable(false);
		this.categoryAxis.setLabel("Months");
		this.NumberAxis.setLabel("Number Of Complaints Per Month");
		XYChart.Series<String, Number> series;
		for(ComplaintsDataReports idr : ChatClient.quarterComplaintsReports) {
			series = new XYChart.Series<>();
			Data<String, Number> data = new XYChart.Data<>(idr.getMonth(),idr.getNumberOfComplaint());
				series.getData().add(data);
			series.setName(idr.getMonth());
			this.barChart.getData().add(series);
			totalComplaints+=idr.getNumberOfComplaint();
		}

		this.complaints_txtarea.setText(createComplaintsReport(totalComplaints));
	}
/**
 * Creating an compliants reports 
 * @param totalComplaints an int the number of the compliants 
 * @return A string representgn the reports 
 */
	private String createComplaintsReport(int totalComplaints) {
	
		String bs="\n";
		bs+= "                Complaints Report Of Year " + ViewSystemReportsController.year1 + " Quarter " + ViewSystemReportsController.quarter1;		
		bs+= "\n                Month " + ChatClient.quarterComplaintsReports.get(0).getMonth() + "\n                Number Of Complaints Is "+ChatClient.quarterComplaintsReports.get(0).getNumberOfComplaint()
				+"\n                Number Of Completed Status is " +ChatClient.quarterComplaintsReports.get(0).getNumberCompleted() + "\n                Number Of Processing Status is " 
				+ChatClient.quarterComplaintsReports.get(0).getNumberProcessing();	
		bs+= "\n                Month " + ChatClient.quarterComplaintsReports.get(1).getMonth() + "\n                Number Of Complaints Is "+ChatClient.quarterComplaintsReports.get(1).getNumberOfComplaint()
				+"\n                Number Of Completed Status is " +ChatClient.quarterComplaintsReports.get(1).getNumberCompleted() + "\n                Number Of Processing Status is " 
				+ChatClient.quarterComplaintsReports.get(1).getNumberProcessing();	
		bs+= "\n                Month " + ChatClient.quarterComplaintsReports.get(2).getMonth() + "\n                Number Of Complaints Is "+ChatClient.quarterComplaintsReports.get(2).getNumberOfComplaint()
				+"\n                Number Of Completed Status is " +ChatClient.quarterComplaintsReports.get(2).getNumberCompleted() + "\n                Number Of Processing Status is " 
				+ChatClient.quarterComplaintsReports.get(2).getNumberProcessing();	
		bs+= "\n                Total Complaints Number Is " + totalComplaints;
		bs+="\n                Zerli Complaints Increase In Percentage Of " + (totalComplaints/10)*100;
		return bs;
	}

}
