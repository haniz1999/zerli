package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Orders;
import common.Status;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the list of orders for the customer screen 
 * @author Laith Sadik
 *
 */
public class ListOfOrdersForCustomerController implements Initializable {

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the customer list of orders
	 * @param primaryStage  A Stage representing the primary stage of the customer list of orders
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ListOfOrdersForCustomer.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	private static ObservableList<Orders> listOfOrdersForCustomer;
	/**
	 * Initialize the details of the customer 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GiveOrdersForCustomer, ChatClient.user));

		this.orderId.setCellValueFactory(new PropertyValueFactory<Orders, String>("OrderId"));
		this.itemsInOrder.setCellValueFactory(new PropertyValueFactory<Orders, String>("itemsInOrder"));
		this.dateOfDelivery.setCellValueFactory(new PropertyValueFactory<Orders, Date>("OrderDeliveryDate"));
		this.status.setCellValueFactory(new PropertyValueFactory<Orders, Status>("status"));
		
		ListOfOrdersForCustomerController.listOfOrdersForCustomer = FXCollections
				.observableArrayList(ChatClient.listToGiveOrders);

		this.tableView.setItems(ListOfOrdersForCustomerController.listOfOrdersForCustomer);
		this.tableView.setOnMouseClicked(new EventHandler<Event>() {
			@Override
			public void handle(final Event event) {
				ListOfOrdersForCustomerController.this.tableView.getSelectionModel();
			}
		});
	}

	@FXML
	private Button backBtn;

	@FXML
	private Button cancelBtn;

	@FXML
	private TableColumn<Orders, Date> dateOfDelivery;

	@FXML
	private Button exitBtn;

	@FXML
	private TableColumn<Orders, String> itemsInOrder;

	@FXML
	private TableColumn<Orders, String> orderId;

	@FXML
	private Button refreshBtn;

	@FXML
	private TableColumn<Orders, Status> status;

	@FXML
	private TableView<Orders> tableView;

	@FXML
	private Text errorText;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		listOfOrdersForCustomer.clear();
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CustomerMainController obcc = new CustomerMainController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * representing the operation of canceling the order action 
	 * @param event An ActionEvent representing the cancel button 
	 */
	@FXML
	void cancel(ActionEvent event) {

		if (this.tableView.getSelectionModel().getSelectedItem() != null
				&& this.tableView.getSelectionModel().getSelectedItem() instanceof Orders) {
			final Orders cancelOrder = this.tableView.getSelectionModel().getSelectedItem();
			if (cancelOrder.getStatus() == Status.APPROVED) {
				this.tableView.getItems().remove(cancelOrder);
				Date orderExecuteDate = new Date();/////
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");/////
				String cancelDate = sdf.format(orderExecuteDate);////
				Object obj = cancelOrder.getOrderId() + "," + cancelDate;
				ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ChangeOrderToCanceled, obj));
			} else {
				errorText.setText("cant to canceled the order!");
				errorText.setFill(Color.RED);
				errorText.setFont(Font.font("Arial", 14));
				errorText.setStyle("-fx-text-fill: red;");
			}
		} else {
			errorText.setText("can not caanceled!");
			errorText.setFill(Color.RED);
			errorText.setFont(Font.font("Arial", 14));
			errorText.setStyle("-fx-text-fill: red;");
		}
	}
	/**
	 * Exit from the list of orders screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Refresh the data 
	 * @param eventAn ActionEvent representing the refresh button action 
	 */
	@FXML
	void refresh(ActionEvent event) {
		this.tableView.getItems().clear();
		initialize(null, null);
	}

}
