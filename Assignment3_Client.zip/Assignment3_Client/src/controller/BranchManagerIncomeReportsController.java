package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.IncomeDataReport;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * Representing a controller that displays a screen for the branch manager income reports
 * @author Laith Sadik & Majd Zbedat
 *
 */
public class BranchManagerIncomeReportsController implements Initializable {

	int initialX;
	int initialY;
	  /**
	  * Representing the Starting screen of the branch manager income reports
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */
	public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerIncomeReports.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("Report Options");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private NumberAxis NumberAxis;

	@FXML
	private Button backBtn;

	@FXML
	private BarChart<String, Number> barChart;

	@FXML
	private CategoryAxis categoryAxis;

	@FXML
	private Button exitBtn;

	@FXML
	private TextArea income_txtarea;
	   /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerDetailsIncomeReportsController BMMC = new BranchManagerDetailsIncomeReportsController();
		try {
			BMMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Representing the exit button controller for branch manager income report screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
    /**
     * Initializing the details of the branch Manager's fields
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		double totalCost=0;
		this.income_txtarea.setEditable(false);
		this.categoryAxis.setLabel("Weeks");
		this.NumberAxis.setLabel("Total Cost per week");
		XYChart.Series<String, Number> series;
		for (IncomeDataReport idr : ChatClient.incomeDataList) {
			series = new XYChart.Series<>();
			Data<String, Number> data = new XYChart.Data<>(idr.getWeek(), idr.getTotalIncome());
			series.getData().add(data);
			series.setName(idr.getWeek());
			this.barChart.getData().add(series);
			totalCost+=idr.getTotalIncome();
		} 
		this.income_txtarea.setText(createIncomeReport(totalCost));

	}
/**
 * Represents creating an income report
 * @param totalCost  A double representing the total cost about income
 * @return A string representing the income report
 */
	private String createIncomeReport(double totalCost) {
		
		String bs = "\n\n";
		bs+= "        Income Report of " + BranchManagerDetailsIncomeReportsController.year1 +"/" + BranchManagerDetailsIncomeReportsController.month1+" \n";
		bs+= "               total income " + totalCost+" \n";
		bs+= "      first week total income: " + ChatClient.incomeDataList.get(0).getTotalIncome() + " \n";
		bs+= "      second week total income: " + ChatClient.incomeDataList.get(1).getTotalIncome() + " \n";
		bs+= "      third week total income: " + ChatClient.incomeDataList.get(2).getTotalIncome() + " \n";
		bs+= "      forth week total income: " + ChatClient.incomeDataList.get(3).getTotalIncome() + " \n";
		bs+= "      fifth week total income: " + ChatClient.incomeDataList.get(4).getTotalIncome() + " \n";
		bs+= "      Zerli increase in percentage: "+ (totalCost/10000)*100+"%";
		return bs;
	}

}
