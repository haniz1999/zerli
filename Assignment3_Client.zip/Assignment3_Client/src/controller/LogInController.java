package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.StatusInSystem;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing  a controller of the log in screen 
 * @author Laith Sadik
 *
 */
public class LogInController implements Initializable {
	/**
	 * Initialize the details of the log in  
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		check_txtf.setDisable(false);
		check_txtf.setFont(Font.font("Arial", 12));
		check_txtf.setStyle("-fx-text-fill: red;");

	}

	int initialX;
	int initialY;
	
	/**
	 * Representing the screen of the primary screen of the log in 
	 * @param primaryStage  A Stage representing the primary stage of the log in 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/LogInController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("LogIn");
		primaryStage.setScene(scene);

		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	   @FXML
	    private Text check_txtf;

	@FXML
	private Button backBtn;

	@FXML
	private Button loginBtn;

	@FXML
	private TextField password_txtf;

	@FXML
	private TextField username_txtf;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) throws IOException {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ClientConnectionController c = new ClientConnectionController();
		try {
			c.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Object clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
				+ "," + "Connected";
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	}
/**
 * Log in to the system 
 * @param event An ActionEvent representign the log in button 
 */
	@FXML
	void login(ActionEvent event) {
		if (username_txtf.getText().isEmpty() && password_txtf.getText().isEmpty()) {
			check_txtf.setText("your username and password is empty");
			check_txtf.setFill(Color.RED);
			check_txtf.setFont(Font.font("Arial", 14));
			check_txtf.setStyle("-fx-text-fill: red;");
		} else if (username_txtf.getText().isEmpty()) {
			check_txtf.setText("your username is empty");
			check_txtf.setFill(Color.RED);
			check_txtf.setFont(Font.font("Arial", 14));
			check_txtf.setStyle("-fx-text-fill: red;");
		} else if (password_txtf.getText().isEmpty()) {
			check_txtf.setText("your password is empty");
			check_txtf.setFill(Color.RED);
			check_txtf.setFont(Font.font("Arial", 14));
			check_txtf.setStyle("-fx-text-fill: red;");
		}

		else {
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Object login = username_txtf.getText() + " " + password_txtf.getText();
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Login, login));

			if (ChatClient.user == null) {
				check_txtf.setText("User is not confirmed");
				check_txtf.setFill(Color.RED);
				check_txtf.setFont(Font.font("Arial", 14));
				check_txtf.setStyle("-fx-text-fill: red;");
			}
			      
			else {
				if (ChatClient.user.isLoggedIn() == false) {
				//	ChatClient.user.setLoggedIn(true); remove this and add to all
			 // important to return it to true
					switch (ChatClient.user.getUserType()) {
					case "customer":
						
						if(ChatClient.user.getStatusInSystem().equals("NA")) {
							check_txtf.setText("User is not confirmed");
							check_txtf.setFill(Color.RED);
							check_txtf.setFont(Font.font("Arial", 14));
							check_txtf.setStyle("-fx-text-fill: red;");
						}else {
						
						CustomerMainController cmc = new CustomerMainController();
						try {
							cmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
						break;
						
					case "branchmanager":
						ChatClient.user.setLoggedIn(true);
						BranchManagerMainController bmmc = new BranchManagerMainController();
						try {
							bmmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
					case "branchworker":
						ChatClient.user.setLoggedIn(true);
						BranchWorkerMainController bwmc = new BranchWorkerMainController();
						try {
							bwmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
					case "ceozerli":
						ChatClient.user.setLoggedIn(true);
						CEOMainController czmc = new CEOMainController();
						try {
							czmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
					case "markatingdepartmentworker":
						MainMarketingWorkerController mdwmc = new MainMarketingWorkerController();
						try {
							mdwmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
					case "departmentserviceworker":
						ChatClient.user.setLoggedIn(true);
						ComplaintMainController dswmc = new ComplaintMainController();
						try {
							dswmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
					case "expertservice":
						ChatClient.user.setLoggedIn(true);
						ServiceSpecialistMainController esmc = new ServiceSpecialistMainController();
						try {
							esmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
					case "delivery":
						ChatClient.user.setLoggedIn(true);
						DeliveryMainController dmc = new DeliveryMainController();
						try {
							dmc.start(stage);
						} catch (Exception e) {
							e.printStackTrace();
						}
						break;
						
						
					default:
					break;
					
					}

				} else {
					check_txtf.setText("User already is loggedin");
					check_txtf.setFill(Color.RED);
					check_txtf.setFont(Font.font("Arial", 14));
					check_txtf.setStyle("-fx-text-fill: red;");
				}
			}

		}
	}

	@FXML
	private Button exitBtn;
	/**
	 * Exit from the log in screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
/**
 * Representing the password text field 
 * @param event
 */
	@FXML
	void password(ActionEvent event) {

	}
/**
 * Representing the user name field 
 * @param event
 */
	@FXML
	void username(ActionEvent event) {

	}

}
