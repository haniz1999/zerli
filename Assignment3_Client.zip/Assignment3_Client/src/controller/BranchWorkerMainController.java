package controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller displays the main branch worker screen 
 * @author Rani Khori
 *
 */
public class BranchWorkerMainController implements Initializable{
	
	


    @FXML
    private Text branchName;

    @FXML
    private Button exitBtn;

  

    @FXML
    private Button logoutBtn;
    

    @FXML
    private Text statusTxt;

    @FXML
    private Text workerName;
    
    @FXML
    private Text workerPositionTxt;
    
    @FXML
    private Button fillSurveyBtn;
   

	private int initialX,initialY;

	
	
	/**
	 * Representing the fill survey button 
	 * @param event An ActionEvent representing the  fill survey button action
	 */
    @FXML
    void fillSurvey(ActionEvent event) {
    	
    	Platform.runLater(new Runnable() {

			@Override
			public void run() {
		    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		    	BranchWorkerViewSurveysController bwvsc = new BranchWorkerViewSurveysController();
				try {
					bwvsc.start(stage);
				} catch (Exception e) {
					System.out.println("Error while openning view surveys window\n");
					e.printStackTrace();
				}				
			}
    	});

    }
	
	/**
	 * Representing the exit button controller for branch manager income report screen
	 * exiting from the branch worker main  screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exit(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

    }

   
/**
 * Representing the log out button
 * @param event An ActionEvent representing the log out button 
 */
    @FXML
    void logout(ActionEvent event) {
    	
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}

    }


	  /**
	  * Representing the Starting screen of the branch worker main screen
	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
	  * @throws IOException   An Exception that the method throws in station of exception
	  */	  
	public void start(Stage primaryStage) throws Exception {	
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchWorkerMain.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Branch Worker Home");
		primaryStage.setScene(scene);
		primaryStage.show();	
		
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 * Initialize the details of the branch worker
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetBranchWorkerByUserId, ChatClient.user));
		
		statusTxt.setText(ChatClient.user.getStatusInSystem());
		workerName.setText(ChatClient.user.getFirstName() + " " + ChatClient.user.getLastName());
		branchName.setText(ChatClient.branchWorkerById.getBranchName());
		
		if(ChatClient.branchWorkerById.getWorkerPosition().equals("NORMAL") || ChatClient.user.getStatusInSystem().equals("FROZEN")){
			System.out.println("the worker is normal or frozen account");
			workerPositionTxt.setText("Normal");

			fillSurveyBtn.setDisable(true);
		}
		else {
			workerPositionTxt.setText("Professional");
		}
	}
}
