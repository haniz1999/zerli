package controller;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Survey;
import common.SurveyAnswer;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller displays fill survey for the branch manager
 * @author Rani Khori
 *
 */
public class BranchWorkerFillSurveyController implements Initializable {

    @FXML
    private Text errortxt;
    
    @FXML
    private TextField fillDateTxtf;
	
    @FXML
    private ComboBox<String> q1AnswerBox;

    @FXML
    private Text q1txt;

    @FXML
    private ComboBox<String> q2AnswerBox;

    @FXML
    private Text q2txt;

    @FXML
    private ComboBox<String> q3AnswerBox;

    @FXML
    private Text q3txt;

    @FXML
    private ComboBox<String> q4AnswerBox;

    @FXML
    private Text q4txt;

    @FXML
    private ComboBox<String> q5AnswerBox;

    @FXML
    private Text q5txt;

    @FXML
    private ComboBox<String> q6AnswerBox;

    @FXML
    private Text q6txt;

    @FXML
    private Button saveBtn;
    

	private int initialX;
	private int initialY;
	/**
	 * Representing the back button
	 * @param event An ActionEvent representing the back button action
	 */
    @FXML
    void back(ActionEvent event) {
    	
    	Platform.runLater(new Runnable() {

			@Override
			public void run() {
		 	 	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		 	 	BranchWorkerViewSurveysController bwvsc = new BranchWorkerViewSurveysController();
		 		try {
		 			bwvsc.start(stage);
		 		} catch (Exception e) {
		 			e.printStackTrace();
		 		}				
			}
    	});

    }
	/**
	 * Representing the exit button controller for branch manager income report screen
	 * exiting from the fill survey branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exitbtn(ActionEvent event) {
    	
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
/**
 * Representing the save button for saving the details
 * @param event An ActionEvent representing the save button action 
 */
    @FXML
    void save(ActionEvent event) {
    	
    	if(q1AnswerBox.getSelectionModel().isEmpty() || q2AnswerBox.getSelectionModel().isEmpty()||
    			q3AnswerBox.getSelectionModel().isEmpty()|| q4AnswerBox.getSelectionModel().isEmpty()||
    			q5AnswerBox.getSelectionModel().isEmpty() || q6AnswerBox.getSelectionModel().isEmpty()) {
    		
    		errortxt.setText("you must answer all the questions");
    	}
    	
    	
    	else {
    		
    		
        	Survey questionsSurvey = BranchWorkerViewSurveysController.chosenSurveyToFill;
        	int maxSurveyAnswerId = 0;
        	

        	for(SurveyAnswer sa:ChatClient.surveysAnswersList) {
        		int id = Integer.parseInt(sa.getSurveyAnswerId());
        		if(id>maxSurveyAnswerId)
        			maxSurveyAnswerId = id;
        	}
        	
        	        	
        	SurveyAnswer surveyAnswerToSave = new SurveyAnswer( Integer.toString(maxSurveyAnswerId+ 1),
        			questionsSurvey.getIdsurvey(),
        			q1AnswerBox.getSelectionModel().getSelectedItem(),q2AnswerBox.getSelectionModel().getSelectedItem(),
        			q3AnswerBox.getSelectionModel().getSelectedItem(),q4AnswerBox.getSelectionModel().getSelectedItem(),
        			q5AnswerBox.getSelectionModel().getSelectedItem(),q6AnswerBox.getSelectionModel().getSelectedItem(),
        			fillDateTxtf.getText(),ChatClient.user.getId());
        	
        	if(ChatClient.surveysAnswersList.contains(surveyAnswerToSave)) {
        		errortxt.setText("This survey answer is already saved");

        	}
        	else {
        		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.SaveSurveyAnswer, surveyAnswerToSave));
        		errortxt.setText("survey answer saved succefully");
        	}


    	}


    }
	
	

	

    /**
  	  * Representing the Starting screen of the branch manager survey screen
  	  * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
  	  * @throws IOException   An Exception that the method throws in station of exception
  	  */
	public void start(Stage stage) throws IOException {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchWorkerFillSurvey.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("View Surveys");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
	/**
	 * Initialize the survey answers 
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		
		q1txt.setText(BranchWorkerViewSurveysController.chosenSurveyToFill.getQ1question());
		q2txt.setText(BranchWorkerViewSurveysController.chosenSurveyToFill.getQ2question());
		q3txt.setText(BranchWorkerViewSurveysController.chosenSurveyToFill.getQ3question());
		q4txt.setText(BranchWorkerViewSurveysController.chosenSurveyToFill.getQ4question());
		q5txt.setText(BranchWorkerViewSurveysController.chosenSurveyToFill.getQ5question());
		q6txt.setText(BranchWorkerViewSurveysController.chosenSurveyToFill.getQ6question());
		

		for(int i=1;i<=10;i++) {
			q1AnswerBox.getItems().add(Integer.toString(i));
			q2AnswerBox.getItems().add(Integer.toString(i));
			q3AnswerBox.getItems().add(Integer.toString(i));
			q4AnswerBox.getItems().add(Integer.toString(i));
			q5AnswerBox.getItems().add(Integer.toString(i));
			q6AnswerBox.getItems().add(Integer.toString(i));
		}
		
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");  
		LocalDateTime now = LocalDateTime.now();  
		   
		fillDateTxtf.setText(dateFormatter.format(now));
		fillDateTxtf.setEditable(false);
		   
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.GetSurveysAnswersList, null));



	}
	
	
	

}
