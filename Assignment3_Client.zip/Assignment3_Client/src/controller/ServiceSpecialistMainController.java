package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * this is the main window for service special of "expert service"
 * @author rani
 * @author hani
 */
public class ServiceSpecialistMainController implements Initializable{
    private int initialX, initialY;
    @FXML
    private Button exitBtn;
    @FXML
    private Text username;

    @FXML
    void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
    }
    /**
     * when the service special want to start giving analyze
     * @param event
     */
    @FXML
    void getSurveysAnswers(ActionEvent event) {
    	
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	ServiceSpecialistViewSurveysAnswersController ssvsac = new ServiceSpecialistViewSurveysAnswersController();
		try {
			ssvsac.start(stage);
		}catch (Exception e) {
			System.out.println("Error while openning surveys answers window\n");
			e.printStackTrace();
		}
    }
    
/**
 * Log out from the service special
 * @param event An ActionEvent representing the log out button 
 */
    @FXML
    void logout(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		LogInController login = new LogInController();
		try {
			login.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    /**
	 * Representing the screen of the primary screen of the service special 
	 * @param primaryStage  A Stage representing the primary stage of the service special
	 * @throws Exception thrown if an error happen 
	 */
    public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ServiceSpecialistMainController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Service Specialist Home");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

    
    scene.setOnMouseDragged(move -> {
		if (move.getButton() == MouseButton.PRIMARY) {
			primaryStage.setX(move.getScreenX() + initialX);
			primaryStage.setY(move.getScreenY() + initialY);
		}
	});

	scene.setOnMouseReleased(move -> {
		scene.setCursor(Cursor.DEFAULT);
	});
	}
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		username.setText(ChatClient.user.getFirstName());

		
	}

}
