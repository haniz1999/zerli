package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.OrderDataReport;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.chart.XYChart.Data;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
/**
 * Representing a controller of the corder reports screen 
 * @author Laith Sadik
 *
 */
public class ViewOrdersReportsController implements Initializable {

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the orders report 
	 * @param primaryStage  A Stage representing the primary stage of the order reports
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/ViewOrdersReports.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private TextArea order_txtarea;

	@FXML
	private Button backBtn;

	@FXML
	private BarChart<String, Number> barChart;

	@FXML
	private Button exitBtn;

	@FXML
	private CategoryAxis catagoryAxis;

	@FXML
	private NumberAxis numberAxis;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ViewSystemReportsController CEOVSR = new ViewSystemReportsController();
		try {
			CEOVSR.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the orders reports screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Initialize the details of the order  
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.order_txtarea.setFont(Font.font("Arial", 12));
		double totalCost = 0;
		this.order_txtarea.setEditable(false);
		this.catagoryAxis.setLabel("Items And Products");
		this.numberAxis.setLabel("Total Cost per Item/Product");
		XYChart.Series<String, Number> series;
		for (OrderDataReport idr : ChatClient.OrderDataList) {
			series = new XYChart.Series<>();
			Data<String, Number> data = new XYChart.Data<>(idr.getPieceName(), idr.getTotlaCost());
			series.getData().add(data);
			series.setName(idr.getPieceName());
			this.barChart.getData().add(series);
			totalCost += idr.getTotlaCost();
		}
		
		this.order_txtarea.setText(createOrderReport(totalCost));

	}
	/**
	 * Creating an order reports 
	 * @param totalComplaints an int the number of the order
	 * @return A string representing the reports 
	 */
	private String createOrderReport(double totalCost) {

		String bs = "\n\n";
		bs += "                            Order Report of " + ViewSystemReportsController.year1 + "/" + ViewSystemReportsController.month1
				+ " \n";
		bs += "                                  total benefits " + totalCost + " \n";
		bs += "             Pot Item: number of sells: " + ChatClient.OrderDataList.get(0).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(0).getTotlaCost() + " \n";
		bs += "             Bouquet Item: number of sells:" + ChatClient.OrderDataList.get(1).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(1).getTotlaCost() + " \n";
		bs += "             Flower Item: number of sells: " + ChatClient.OrderDataList.get(2).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(2).getTotlaCost() + " \n";
		bs += "             Seedling Item: number of sells:" + ChatClient.OrderDataList.get(3).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(3).getTotlaCost() + " \n";
		bs += "             Branch Item: number of sells: " + ChatClient.OrderDataList.get(4).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(4).getTotlaCost() + " \n";
		bs += "  StylesBouquet Product: number of sells:" + ChatClient.OrderDataList.get(5).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(5).getTotlaCost() + " \n";
		bs += "  SeedlingFlowers Product: number of sells:" + ChatClient.OrderDataList.get(6).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(6).getTotlaCost() + " \n";
		bs += "  SpecailZerli Product: number of sells:" + ChatClient.OrderDataList.get(7).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(7).getTotlaCost() + " \n";
		bs += "  BridalBouquet Product: number of sells:" + ChatClient.OrderDataList.get(8).getNumberOfPiece()
				+ " total income: " + ChatClient.OrderDataList.get(8).getTotlaCost() + " \n";
		bs += "                          Zerli increase in percentage: " + (totalCost / 10000) * 100 + "%";
		return bs;
	}

}