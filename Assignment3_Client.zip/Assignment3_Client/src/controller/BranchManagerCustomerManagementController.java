package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Client;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller displays the branch manager customer management screen
 * @author Majd Zbedat
 *
 */
public class BranchManagerCustomerManagementController implements Initializable {

	public static ObservableList<Users> userList;

	private int initialX, initialY;
	public static Users PrimaryKeyOfId;
	
    @FXML
	    private Text Alarttxt;

	@FXML
	private TableColumn<Users, String> Customer_IdColumn;

	@FXML
	private TableColumn<Users, String> Customer_StatusColumn;

	@FXML
	private TableColumn<Users, String> First_NameColumn;

	@FXML
	private TableColumn<Users, String> Last_NameColumn;

	@FXML
	private TableView<Users> userTable;

	@FXML
	private Button Edit_statusbnt;

	@FXML
	private Button Removebtn;

	@FXML
	private Button exitBtn;
	/**
	 * Representing the field to  the status text controller
	 * @param event An ActionEvent representing the text field of the status
	 */
	@FXML
	void editStatusFunction(ActionEvent event) {
		PrimaryKeyOfId = this.userTable.getSelectionModel().getSelectedItem();
		 if (PrimaryKeyOfId == null) {
			 Alarttxt.setText("Please select row");
			 Alarttxt.setFill(Color.RED);
			 Alarttxt.setFont(Font.font("Arial", 14));
		      Alarttxt.setStyle("-fx-text-fill: red;");
		 }
	 else {
		 Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		 BranchManagerCMeditStatusController bmcds = new BranchManagerCMeditStatusController();
			try {
				bmcds.start(stage);
			} catch (Exception e) {
				System.out.println("Error while openning edit status window\n");
				e.printStackTrace();
			}
		 }
	}
	/**
	 * Representing the exit button controller for branch manager customer management screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
	}

//	@FXML
//	void removeFunction(ActionEvent event) {
//		 if (this.userTable.getSelectionModel().getSelectedItem() == null) {
//			 Alarttxt.setText("Please select column");
//			 Alarttxt.setFill(Color.RED);
//			 Alarttxt.setFont(Font.font("Arial", 14));
//		      Alarttxt.setStyle("-fx-text-fill: red;");
//		 }
//		 else {
//		Object ObjRemoveCustomer;
//		ObjRemoveCustomer =  (userTable.getSelectionModel().getSelectedItem().getId());
//		
//		System.out.println((ObjRemoveCustomer) + "**********************");
//
//		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.DeleteCustomer,ObjRemoveCustomer));
//		initialize(null, null);
//		userTable.refresh();
//		 }
//	}
	
	

	
	
	
	
	/**
	 * Representing the refresh button controller 
	 * @param event An ActionEvent representing the refresh button
	 */
	@FXML
	void refresh(ActionEvent event) {
		this.userTable.getItems().clear();
		initialize(null, null);
	}
	
	

	
	
	
	
	   /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
	@FXML
	void backFunction(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerMainController BMMC = new BranchManagerMainController();
		try {
			BMMC.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	   /**
     * Representing the Starting screen of  of the branch manager customer management
     * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
     * @throws IOException   An Exception that the method throws in station of exception
     */
	public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerCustomerManagement.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("Customer Management");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	
	
    /**
     * Initializing the details of the branch Manager's fields
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.UserListStatus, null));
		this.Customer_IdColumn.setCellValueFactory(new PropertyValueFactory<Users, String>("id"));
		this.First_NameColumn.setCellValueFactory(new PropertyValueFactory<Users, String>("firstName"));
		this.Last_NameColumn.setCellValueFactory(new PropertyValueFactory<Users, String>("lastName"));
		this.Customer_StatusColumn.setCellValueFactory(new PropertyValueFactory<Users, String>("statusInSystem"));
		userList = FXCollections.observableArrayList(ChatClient.userList);
		System.out.println(userTable + " +++++++++++++++");
		userTable.setItems(userList);
	}

	
	
	
	
}
