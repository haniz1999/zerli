package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.Optional;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller of the datails of the self defined item screen 
 * @author Laith Sadik
 *
 */
public class DetailsSelfdefinedItemController implements Initializable {
	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of self defined details
	 * @param primaryStage  A Stage representing the primary stage of the customer
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/DetailsSelfdefinedItemController.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("View Selfdefined Catalog");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private Text error_text;

	@FXML
	private Button backBtn;

	@FXML
	private CheckBox choseColorCheckBox;

	@FXML
	private ComboBox<String> colorComboBox;

	@FXML
	private Button exitBtn;

	@FXML
	private ComboBox<String> itemTypeComboBox;

	@FXML
	private Button nextBtn;

	@FXML
	private TextField priceFromLabel;

	@FXML
	private TextField priceToLabel;

	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		OrderByCatalogController obcc = new OrderByCatalogController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
/**
 * Representing the action of choosing the color 
 * @param event An ActionEvent representing the choose color button
 */
	@FXML
	void choseColorCB(ActionEvent event) {
		if (choseColorCheckBox.isSelected()) {
			colorComboBox.setValue("color");
			colorComboBox.setDisable(false);

		} else {
			colorComboBox.setValue("color");
			colorComboBox.setDisable(true);
		}

	}

	@FXML
	void from_txtf(ActionEvent event) {

	}

	@FXML
	void to_txtf(ActionEvent event) {
		priceFromLabel.setStyle("-fx-border-color: black");
	}

	@FXML
	void color(ActionEvent event) {
		priceToLabel.setStyle("-fx-border-color: black");
	}
	/**
	 * Exit from the self defined item details screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}

	@FXML
	void itemTypeCB(ActionEvent event) {
		itemTypeComboBox.setStyle("-fx-border-color: black");

	}
/**
 * Representing the next window
 * @param event An ActionEvent representing the next button 
 */
	@FXML
	void next(ActionEvent event) {
		boolean flag = true;
		if (itemTypeComboBox.getValue() == null) {
			flag = false;
			error_text.setText("The Item Type is illogical");
			error_text.setFill(Color.RED);
			error_text.setFont(Font.font("Arial", 14));
			error_text.setStyle("-fx-text-fill: red;");
			itemTypeComboBox.setStyle("-fx-border-color: red");
		}
		if (checktext(priceFromLabel.getText()) == true) {
			if (Double.valueOf(priceFromLabel.getText()) < 0) {
				flag = false;
				error_text.setText("The range price is illogical");
				error_text.setFill(Color.RED);
				error_text.setFont(Font.font("Arial", 14));
				error_text.setStyle("-fx-text-fill: red;");
				priceFromLabel.setStyle("-fx-border-color: red");
			} else {
				priceFromLabel.setStyle("-fx-border-color: black");

			}
		} else {
			flag = false;
			error_text.setText("The range price is illogical");
			error_text.setFill(Color.RED);
			error_text.setFont(Font.font("Arial", 14));
			error_text.setStyle("-fx-text-fill: red;");
			priceFromLabel.setStyle("-fx-border-color: red");
		}

		if (checktext(priceToLabel.getText()) == true) {

			if (Double.valueOf(priceToLabel.getText()) <= 0
					|| Double.valueOf(priceToLabel.getText()) < Double.valueOf(priceFromLabel.getText())) {
				flag = false;
				error_text.setText("The range price is illogical");
				error_text.setFill(Color.RED);
				error_text.setFont(Font.font("Arial", 14));
				error_text.setStyle("-fx-text-fill: red;");
				priceToLabel.setStyle("-fx-border-color: red");
			} else {
				priceToLabel.setStyle("-fx-border-color: black");
			}
		} else {
			flag = false;
			error_text.setText("The range price is illogical");
			error_text.setFill(Color.RED);
			error_text.setFont(Font.font("Arial", 14));
			error_text.setStyle("-fx-text-fill: red;");
			priceToLabel.setStyle("-fx-border-color: red");
		}

		if (flag) {
			Object DetailsSelfdefinedItems;
			if (CustomerMainController.viewOrOrderFlag == false) {
				DetailsSelfdefinedItems = itemTypeComboBox.getValue() + "," + priceFromLabel.getText() + ","
						+ priceToLabel.getText();
				if (choseColorCheckBox.isSelected())
					DetailsSelfdefinedItems = itemTypeComboBox.getValue() + "," + priceFromLabel.getText() + ","
							+ priceToLabel.getText() + "," + colorComboBox.getValue();
				ClientUI.chat.accept(
						new TranslateMessage(TranslateMessageType.DetailsItemsForCatalog, DetailsSelfdefinedItems));
				if (ChatClient.ItemList.size() == 0) {
					Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			           alert.setTitle("Error");
			           alert.setHeaderText("Input Error !!!");
			           alert.setContentText("Fill Another Details!");
			           Optional<ButtonType> result = alert.showAndWait();
				} else {
					Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					CatalogOfSelfdefinedItemsController csc = new CatalogOfSelfdefinedItemsController();
					try {
						csc.start(stage);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			} else {
				DetailsSelfdefinedItems = itemTypeComboBox.getValue() + "," + priceFromLabel.getText() + ","
						+ priceToLabel.getText();
				if (choseColorCheckBox.isSelected())
					DetailsSelfdefinedItems = itemTypeComboBox.getValue() + "," + priceFromLabel.getText() + ","
							+ priceToLabel.getText() + "," + colorComboBox.getValue();
				ClientUI.chat.accept(
						new TranslateMessage(TranslateMessageType.DetailsItemsForCatalog, DetailsSelfdefinedItems));
				if (ChatClient.ItemList.size() == 0) {
					Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
			           alert.setTitle("Error");
			           alert.setHeaderText("Input Error !!!");
			           alert.setContentText("Fill Another Details!");
			           Optional<ButtonType> result = alert.showAndWait();
				} else {
					Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
					ViewCatalogOfSelfdefinedItemsController csc = new ViewCatalogOfSelfdefinedItemsController();
					try {
						csc.start(stage);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}

	}
	/**
	 * checking the fields if its fill in the true way
	 * @return true if the fields true else return false
	 */
	private boolean checktext(String strNum) {
		if (strNum == null) {
			return false;
		}
		try {
			double d = Double.parseDouble(strNum);
		} catch (NumberFormatException nfe) {
			return false;
		}
		return true;
	}
	/**
	 * Initialize the details of the self defined item
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		ObservableList<String> itemtype = FXCollections.observableArrayList("Pot", "Bouquet", "Flower", "Seedling",
				"Branch");
		itemTypeComboBox.setItems(itemtype);
		ObservableList<String> selectcolor = FXCollections.observableArrayList("GREEN", "RED", "WHITE", "BLUE",
				"PURPLE", "YELLOW", "RED AND GREEN", "YELLOW AND WHITE", "RED AND GREEN AND WHITE");
		colorComboBox.setItems(selectcolor);
		colorComboBox.setDisable(true);
		priceFromLabel.setText("0");
		priceToLabel.setText("0");

	}

}
