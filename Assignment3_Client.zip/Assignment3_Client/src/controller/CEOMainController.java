package controller;

import java.net.URL;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
/**
 * Representing as a controller of the the CEO main screen 
 * @author Laith Sadik
 *
 */
public class CEOMainController implements Initializable{


	    @FXML
	    private Button Exitbtn;

	  

	    @FXML
	    private Text userNameText;

	    @FXML
	    private Button userRegistrationBtn;

	    @FXML
	    private Button viewSystemReportsBtn;
/**
 * Exiting from the main screen of the CEO screen
 * @param event An ActionEvent representing the exit button action 
 */
	    @FXML
	    void exitFunction(ActionEvent event) {
	      	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Object logout = ChatClient.user;
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
			ChatClient.user.setLoggedIn(false);
			LogInController login = new LogInController();
			try {
				login.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }

	  
/**
 * Representing the compare action for the CEO 
 * @param event An ActionEvent representing the compare button
 */
	    @FXML
	    void compareFunction(ActionEvent event) {
	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
	    	CEOViewEqualReportsController CEOVSRCIRC = new CEOViewEqualReportsController();
			try {
				CEOVSRCIRC.start(stage);
			} catch (Exception e) {
		
				e.printStackTrace();
			}
	    }
/**
 * Representing the system reports for the CEO
 * @param event An ActionEvent representing the view system report button
 */
	    @FXML
	    void viewSystemReports(ActionEvent event) {
	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow(); 
			ViewSystemReportsController CEOVSR = new ViewSystemReportsController();
			try {
				CEOVSR.start(stage);
			} catch (Exception e) {
				System.out.println("Error while openning view system reports window\n");
				e.printStackTrace();
			}
	    }
/**
 * Representing the log out action of the CEO 
 * @param event An ActionEvent representing the log out button
 */
	    @FXML
	    void logOurFunction(ActionEvent event) {
	    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			Object logout = ChatClient.user;
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
			ChatClient.user.setLoggedIn(false);
			LogInController login = new LogInController();
			try {
				login.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}
	    }
	    
	    
		private int initialX,initialY;
		/**
		 * Representing the main screen of the CEO 
		 * @param primaryStage  A Stage representing the primary stage of the CEO
		 * @throws Exception  thrown if exiting an error
		 */
		public void start(Stage primaryStage) throws Exception {	
			AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CEOMain.fxml"));
			Scene scene = new Scene(root);
			primaryStage.setTitle("Customer Home");
			primaryStage.setScene(scene);
			primaryStage.show();	
			
			scene.setOnMousePressed(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					scene.setCursor(Cursor.MOVE);
					initialX = (int) (primaryStage.getX() - move.getScreenX());
					initialY = (int) (primaryStage.getY() - move.getScreenY());
				}
			});

			scene.setOnMouseDragged(move -> {
				if (move.getButton() == MouseButton.PRIMARY) {
					primaryStage.setX(move.getScreenX() + initialX);
					primaryStage.setY(move.getScreenY() + initialY);
				}
			});

			scene.setOnMouseReleased(move -> {
				scene.setCursor(Cursor.DEFAULT);
			});
		}
		/**
		 * Initialize the CEO details 
		 * @param location  A URL representing the location
		 * @param resources A ResourceBundle representing the resources
		 */
		@Override
		public void initialize(URL location, ResourceBundle resources) {
			userNameText.setText(ChatClient.user.getFirstName());		
			
		}
	    
		
	    
	    
	    
	    
	   
	    
	    
	    
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


