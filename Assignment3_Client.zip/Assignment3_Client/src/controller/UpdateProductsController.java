package controller;

import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.ProductType;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import common.Users;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import javafx.scene.text.Text;
/**
 * Representing a controller of the updating product screen 
 * @author Othman Laith Sadik
 *
 */
public class UpdateProductsController implements Initializable {
	public static ObservableList<Products> productList;
	public static Products me;
	public static boolean flag = false;
	/**
	 * Initialize the details of the  product 
	 * @param location  A URL representing the location 
	 * @param resources A ResourceBundle representing the resources
	 */ 
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		me = null;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.ProductListInCatalog, null));
		this.productId.setCellValueFactory(new PropertyValueFactory<Products, String>("productId"));
		this.productName.setCellValueFactory(new PropertyValueFactory<Products, String>("productName"));
		this.productprice.setCellValueFactory(new PropertyValueFactory<Products, Double>("price"));
		this.productType.setCellValueFactory(new PropertyValueFactory<Products, ProductType>("productType"));
		this.productcomposition.setCellValueFactory(new PropertyValueFactory<Products, String>("productComposition"));
		this.discount.setCellValueFactory(new PropertyValueFactory<Products, Double>("discount"));
		productList = FXCollections.observableArrayList(ChatClient.productList);
		ProductTable.setItems(productList);

	}

	private int initialX, initialY;
	/**
	 * Representing the screen of the primary screen of the update product
	 * @param primaryStage  A Stage representing the primary stage of the update product 
	 * @throws Exception thrown if an error happen 
	 */
	public void start(Stage primaryStage) throws Exception {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/UpdateProduct.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Customer Home");
		primaryStage.setScene(scene);
		primaryStage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}

	@FXML
	private TableView<Products> ProductTable;

	@FXML
	private Button back_btn;

	@FXML
	private Button exit_btn;

	@FXML
	private Button finishupdate_btn;

	@FXML
	private TableColumn<Products, String> productId;

	@FXML
	private TableColumn<Products, String> productName;
    @FXML
    private TableColumn<Products, Double> discount;
	@FXML
	private TableColumn<Products, ProductType> productType;
	@FXML
	private TableColumn<Products, String> productcomposition;

	@FXML
	private Text Alarttxt;

	@FXML
	private TableColumn<Products, Double> productprice;
	/**
	 *Back to the previous screen 
	 * @param event An ActionEvent representing the back button action 
	 */
	@FXML
	void back(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ChooseToUpdatecontroller gui = new ChooseToUpdatecontroller();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Exit from the update product screen 
	 * @param event An ActionEvent representing the exit button action 
	 */
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		ChatClient.user.setLoggedIn(false);
		System.exit(0);
	}
	/**
	 * Finishing the updating operation
	 * @param event An ActioEvent representign the finish button 
	 */
	@FXML
	void finishupdate(ActionEvent event) {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		MainMarketingWorkerController gui = new MainMarketingWorkerController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Adding an product action
	 * @param event An ActionEvent representing the add button 
	 */
	@FXML
	void addproduct(ActionEvent event) {
		flag = true;
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		AddUpdateProductController gui = new AddUpdateProductController();
		try {
			gui.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Deleting the product action 
	 * @param event An ActionEvent representing the delete button 
	 */
	@FXML
	void deleteproduct(ActionEvent event) {
		if (this.ProductTable.getSelectionModel().getSelectedItem() == null) {
			Alarttxt.setText("Please select column");
			Alarttxt.setFill(Color.RED);
			Alarttxt.setFont(Font.font("Arial", 14));
			Alarttxt.setStyle("-fx-text-fill: red;");
		} else {
			Object ObjRemoveproduct;
			ObjRemoveproduct = (ProductTable.getSelectionModel().getSelectedItem().getProductId());

			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Deleteproduct, ObjRemoveproduct));
			initialize(null, null);
			ProductTable.refresh();
		}

	}
	/**
	 * Updating the product 
	 * @param event An ActionEvent representing the update button 
	 */
	@FXML
	void updateproduct(ActionEvent event) {
		flag = true;
		if (this.ProductTable.getSelectionModel().getSelectedItem() == null) {
			Alarttxt.setText("Please select column");
			Alarttxt.setFill(Color.RED);
			Alarttxt.setFont(Font.font("Arial", 14));
			Alarttxt.setStyle("-fx-text-fill: red;");
		} else {
			me = this.ProductTable.getSelectionModel().getSelectedItem();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			AddUpdateProductController gui = new AddUpdateProductController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

	}
/**
 * Performing the promotions 
 * @param event An ACTIONEVENT representing the performing button 
 */
	@FXML
	void Performing_promotionsBTN(ActionEvent event) {
		if (this.ProductTable.getSelectionModel().getSelectedItem() == null) {
			Alarttxt.setText("Please select column");
			Alarttxt.setFill(Color.RED);
			Alarttxt.setFont(Font.font("Arial", 14));
			Alarttxt.setStyle("-fx-text-fill: red;");
		} else {
			me = this.ProductTable.getSelectionModel().getSelectedItem();
			Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
			DiscountProductController gui = new DiscountProductController();
			try {
				gui.start(stage);
			} catch (Exception e) {
				e.printStackTrace();
			}

		}
	}

}
