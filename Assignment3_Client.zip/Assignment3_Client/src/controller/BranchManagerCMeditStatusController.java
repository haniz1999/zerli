package controller;
import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
/**
 * Representing a controller that displays a screen for edit the branch manager status
 * @author Majd Zbedat
 *
 */
public class BranchManagerCMeditStatusController implements Initializable{

	private int GotIt=0;
	
	private String CurrentStatus,id;
	private String frozen="FROZEN",confirmed="CONFIRMED",send,isLoggedIn;
	
	private int initialX;
	
	private int initialY;
    @FXML
    private Button Back;

    @FXML
    private Text Alarttxt;
    @FXML
    private TextField Emailbtn;

    @FXML
    private Button Exit;

    @FXML
    private ImageView Exitbtn;

    @FXML
    private TextField First_Namebtn;

    @FXML
    private TextField ID;

    @FXML
    private TextField LastNamebtn;

    @FXML
    private TextField PhoneNumberbtn;

    @FXML
    private Button Save;

    @FXML
    private ComboBox<String> Status;
    /**
     * Represents the back button controller 
     * @param event  An ActionEvent representing the back click action
     */
    @FXML
    void backFunction(ActionEvent event) {
    	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
    	BranchManagerCustomerManagementController bmcmc= new BranchManagerCustomerManagementController();
		try {
			bmcmc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
/**
 * Representing the field of the email text controller
 * @param event An ActionEvent representing the text field of the email
 */
    @FXML
    void emailFunction(ActionEvent event) {

    }



    
	/**
	 * Representing the exit button controller for branch manager status editing screen
	 * exiting from the updating branch manager screen
	 * @param event An ActionEvent representing the exit's button
	 */ 
    @FXML
    void exitFunction(ActionEvent event) {
    	Object clientObj;
	    Object logout = ChatClient.user;
	    ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
	    try {
	      clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
	          + "," + "Connected";
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
	    } catch (UnknownHostException e) {
	      e.printStackTrace();
	    }
	    System.exit(0);
    }
	/**
	 * Representing the field of the id text controller
	 * @param event An ActionEvent representing the text field of the id
	 */
    @FXML
    void idFunction(ActionEvent event) {

    }
	/**
	 * Representing the field of the phone number text controller
	 * @param event An ActionEvent representing the text field of the phone number
	 */
    @FXML
    void phoneNumberFunction(ActionEvent event) {

    }
    /**
     * Representing the save action to saves the updating details
     * @param event An ActionEvent representing the save's click
     */
    @FXML
    void saveFunction(ActionEvent event) {
    	if(this.Status.getValue().equals(CurrentStatus)) {
    		Alarttxt.setText("it's current status!!");
			 Alarttxt.setFill(Color.RED);
			 Alarttxt.setFont(Font.font("Arial", 14));
		      Alarttxt.setStyle("-fx-text-fill: red;");
    	}
    	else {
        System.out.println(Status.getValue());
        if(CurrentStatus.equals("CONFIRMED")) {
        	send = "FROZEN";
        	isLoggedIn = "0";
        }
        	else {
        	    send = "CONFIRMED";
            	isLoggedIn = "0";

        	}
        		
        
        Object Obj = id + "," + send +","+isLoggedIn+",";
	     ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.editStatus,Obj));
	 	Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		BranchManagerCustomerManagementController BMCMC = new BranchManagerCustomerManagementController();
		try {
			BMCMC.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    	}

    }
	/**
	 * Representing the field of the status text controller
	 * @param event An ActionEvent representing the text field of the status
	 */
    @FXML
    void statusFunction(ActionEvent event) {

    }

    
    
    
    /**
     * Representing the Starting screen of the editing the status of the branch manager
     * @param primaryStage A Stage representing the primary stage of the branch maanger's screen
     * @throws IOException   An Exception that the method throws in station of exception
     */
    public void start(Stage stage) throws IOException {
		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/BranchManagerCMeditStatus.fxml"));
		Scene scene = new Scene(root);
		stage.setTitle("edit status");
		stage.setScene(scene);
		stage.show();

		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (stage.getX() - move.getScreenX());
				initialY = (int) (stage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				stage.setX(move.getScreenX() + initialX);
				stage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});
	}
    /**
     * Initializing the details of the branch Manager's fields
     */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
	      ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.getUserDetalts, null));
		 String CheckById;
	      int flag=1,i=0;
	      CheckById = BranchManagerCustomerManagementController.PrimaryKeyOfId.getId();
	      System.out.println(CheckById);
	      while(flag == 1) {
	    	 if( ChatClient.detailsCustomer.get(i).getId().equals(CheckById) ) {
	    		 GotIt = i;  
	    		 flag= 0;
	    	 }
	    	 i++;
	      }
	      
	      System.out.println(ChatClient.detailsCustomer.get(GotIt).getPhoneNumber());
	      Emailbtn.setText(ChatClient.detailsCustomer.get(GotIt).getEmail());
	      First_Namebtn.setText(ChatClient.detailsCustomer.get(GotIt).getFirstName());
	      LastNamebtn.setText(ChatClient.detailsCustomer.get(GotIt).getLastName());
	      id = ChatClient.detailsCustomer.get(GotIt).getId();
	      ID.setText(id);
	      PhoneNumberbtn.setText(ChatClient.detailsCustomer.get(GotIt).getPhoneNumber());	
	      First_Namebtn.setDisable(true);
	      LastNamebtn.setDisable(true);
	      ID.setDisable(true);
	      PhoneNumberbtn.setDisable(true);
	      Emailbtn.setDisable(true);
	      Status.getItems().add("CONFIRMED");
	      Status.getItems().add("FROZEN");
	      Emailbtn.setFont(Font.font("default", 15));
	      First_Namebtn.setFont(Font.font("default", 15));
	      LastNamebtn.setFont(Font.font("default", 15));
	      ID.setFont(Font.font("default", 15));
	      PhoneNumberbtn.setFont(Font.font("default", 15));
	      CurrentStatus = ChatClient.detailsCustomer.get(GotIt).getStatusInSystem();
  		  Status.setValue(CurrentStatus);
          


	      
	}
    

    
}
