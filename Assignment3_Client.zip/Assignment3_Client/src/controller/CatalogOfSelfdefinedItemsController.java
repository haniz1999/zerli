package controller;

import java.io.IOException;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import client.ChatClient;
import client.ClientUI;
import common.Item;
import common.MyListener;
import common.Orders;
import common.Products;
import common.TranslateMessage;
import common.TranslateMessageType;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;

import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Cursor;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseButton;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
/**
 * Representing a controller for the self defined catalog screen 
 * @author Laith Sadik
 *
 */
public class CatalogOfSelfdefinedItemsController implements Initializable {
	static Item addToCartProduct;
	public static Orders order;
	MyListener myListener;
	ArrayList<Item> list = new ArrayList<>();
	public static ArrayList<Item> addToCartList = new ArrayList<>();
	public static double totalPrice = 0;
	//static {
	//	CatalogOfSelfdefinedItemsController.order = new Orders();
//	}
	int initialX, initialY;
	/**
	 * Representing the starting stage of the self defined products catalog screen
	 * @param primaryStage A Stage representing the primary stage of the self defined products catalog
	 * @throws Exception An Exception that the method throws in station of exception
	 */
	public void start(Stage primaryStage) throws Exception {

		AnchorPane root = FXMLLoader.load(getClass().getResource("/gui/CatalogOfSelfdefinedItems.fxml"));
		Scene scene = new Scene(root);
		primaryStage.setTitle("Catalog Selfdefiend Items");
		primaryStage.setScene(scene);
		primaryStage.show();
		scene.setOnMousePressed(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				scene.setCursor(Cursor.MOVE);
				initialX = (int) (primaryStage.getX() - move.getScreenX());
				initialY = (int) (primaryStage.getY() - move.getScreenY());
			}
		});

		scene.setOnMouseDragged(move -> {
			if (move.getButton() == MouseButton.PRIMARY) {
				primaryStage.setX(move.getScreenX() + initialX);
				primaryStage.setY(move.getScreenY() + initialY);
			}
		});

		scene.setOnMouseReleased(move -> {
			scene.setCursor(Cursor.DEFAULT);
		});

	} 

	@FXML
	private Button addBtn;

	@FXML
	private Button addToCart_btn;

	@FXML
	private Button back_btn;

	@FXML
	private VBox chooseProductCard;

	@FXML
	private Button completeOrder_btn;

	@FXML
	private Label compositionCart;

	@FXML
	private Text errorAddToCart;

	@FXML
	private Button exit_btn;

	@FXML
	private GridPane grid;

	@FXML
	private Label idCart;

	@FXML
	private ImageView imageCart;

	@FXML
	private Button myListCart_btn;

	@FXML
	private Label nameCart;

	@FXML
	private Label priceCart;

	@FXML
	private TextField quantity_label;

	@FXML
	private ScrollPane scroll;

	@FXML
	private Button subBtn;

	@FXML
	private Label typeCart;

    @FXML
    private Label discountPercentage_label;

    /**
     * Representing the add to cart button to add the product 
     * @param event An ActionEvent representing the add to cart button action 
     */
	@FXML
	void addToCart(ActionEvent event) {
		totalPrice=order.getTotalItemsPrice();
		errorAddToCart.setText("");
		if (addToCartProduct != null && !quantity_label.getText().equals("0") && !quantity_label.getText().isEmpty()) {
			for (int i = 0; i < Integer.valueOf(quantity_label.getText()); i++) {
				addToCartList.add(addToCartProduct);
				order.getItemsList().add(addToCartProduct);
				totalPrice += addToCartProduct.getPrice();
				order.setTotalItemsPrice(totalPrice);
			}
		} else {
			errorAddToCart.setText("No items in the cart!");
			errorAddToCart.setFill(Color.RED);
			errorAddToCart.setFont(Font.font("Arial", 14));
			errorAddToCart.setStyle("-fx-text-fill: red;");
		}
		quantity_label.setText("0");
	}
	/**
	 * Representing the back button
	 * @param event An ActionEvent representing the back button action
	 */
	@FXML
	void back(ActionEvent event) {
		CustomerMainController.viewOrOrderFlag = false;
		errorAddToCart.setText("");
		addToCartList.clear();
		ChatClient.ItemList.clear();
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		DetailsSelfdefinedItemController obcc = new DetailsSelfdefinedItemController();
		try {
			obcc.start(stage);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Representing the complete order button to complete
	 * @param event An ActionEvent representing the completeOrder button action 
	 */
	@FXML
	void completeOrder(ActionEvent event) {
		errorAddToCart.setText("");
		quantity_label.setText("0");
		if(CatalogOfSelfdefinedItemsController.order.getItemsList().size()==0) {
			errorAddToCart.setText("Your Cart Is Empty!");
			errorAddToCart.setFill(Color.RED);
			errorAddToCart.setFont(Font.font("Arial", 14));
			errorAddToCart.setStyle("-fx-text-fill: red;");
		}
		else {
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		ListOfAllProductsAndListsController doc = new ListOfAllProductsAndListsController();
		try {
			doc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		}
	}
	/**
	 * Representing the exit button controller 
	 * exiting from the self defined product catalog	
	 * @param event An ActionEvent representing the exit's button
	 */ 
	@FXML
	void exit(ActionEvent event) {
		Object clientObj;
		Object logout = ChatClient.user;
		ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.Logout, logout));
		try {
			clientObj = InetAddress.getLocalHost().getHostAddress() + "," + InetAddress.getLocalHost().getHostName()
					+ "," + "Connected";
			ClientUI.chat.accept(new TranslateMessage(TranslateMessageType.TVDisconnectedClient, clientObj));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		System.exit(0);
	}
	/**
	 * Representing the my list cart button to show the list of cart 
	 * @param event An ActionEvent representing the my list cart button action 
	 */
	@FXML
	void myListCart(ActionEvent event) {
		errorAddToCart.setText("");
		quantity_label.setText("0");
		Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
		CartOfItemsController doc = new CartOfItemsController();
		try {
			doc.start(stage);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	void sub(ActionEvent event) {
		if (quantity_label.getText().equals("0")) {
			errorAddToCart.setText("Error quantity is zero!");
			errorAddToCart.setFill(Color.RED);
			errorAddToCart.setFont(Font.font("Arial", 14));
			errorAddToCart.setStyle("-fx-text-fill: red;");
		} else
			quantity_label.setText(Integer.valueOf(quantity_label.getText()) - 1 + "");
	}
/**
 * Representing the add button to add a product 
 * @param event An ActionEvent representing the add button 
 */
	@FXML
	void add(ActionEvent event) {
		quantity_label.setText(Integer.valueOf(quantity_label.getText()) + 1 + "");
		errorAddToCart.setText("");
	}

	/**
	 * Initialize the self defined catalog details 
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		this.priceCart.setText("0");
		this.totalPrice=0;
		addToCartList.addAll(CatalogOfSelfdefinedItemsController.order.getItemsList());
		list.addAll(getData());
		
		this.priceCart.setText("0");
		if(CatalogOfSelfdefinedItemsController.order.getTotalItemsPrice() ==0)///////////////////////////////////
		this.totalPrice=0;
		else
			this.totalPrice=CatalogOfSelfdefinedItemsController.order.getTotalItemsPrice();
		
		quantity_label.setEditable(false);
		quantity_label.setText("0");
		setChooseProduct(list.get(0));
		myListener = new MyListener() {

			@Override
			public void OnClickListener(Products product) {

			}

			@Override
			public void OnClickListener(Item item) {
				setChooseProduct(item);
				quantity_label.setText("0");
				errorAddToCart.setText("");
			}

		};

		int col = 0, row = 1;
		try {
			for (int i = 0; i < list.size(); i++) {
				FXMLLoader fxmlLoader = new FXMLLoader();
				fxmlLoader.setLocation(getClass().getResource("/gui/Item.fxml"));

				AnchorPane ap = fxmlLoader.load();

				ItemController pc = fxmlLoader.getController();
				pc.setData(list.get(i), myListener);

				if (col == 3) {
					col = 0;
					row++;
				}
				grid.add(ap, col++, row);

				GridPane.setMargin(ap, new Insets(10));
				grid.setMaxHeight(Region.USE_COMPUTED_SIZE);
				grid.setPrefHeight(Region.USE_COMPUTED_SIZE);
				grid.setMinHeight(Region.USE_COMPUTED_SIZE);
				grid.setMaxWidth(Region.USE_COMPUTED_SIZE);
				grid.setPrefWidth(Region.USE_COMPUTED_SIZE);
				grid.setMinWidth(Region.USE_COMPUTED_SIZE);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	/**
	 * Gets the data of the self defined products catalog 
	 * @return An ArrayList<Items> representing the list of the self defined products catalog
	 */
	private ArrayList<Item> getData() {
		ArrayList<Item> iList = new ArrayList<>();
		iList.addAll(ChatClient.ItemList);
		Item item;
		return iList;
	}
	/**
	 * Sets the chosen items into the cart 
	 * @param product A Products representing the details of the items
	 */
	public void setChooseProduct(Item item) {
		idCart.setText(item.getItemId());
		addToCartProduct = item;
		nameCart.setText(item.getItemName());
		typeCart.setText(String.valueOf(item.getItemType()));
		compositionCart.setText(item.getColor());
		priceCart.setText(item.getPrice()+"");
		discountPercentage_label.setText(item.getDiscount()+" %");
		Image image = new Image(getClass().getResourceAsStream(item.getPicturePath()));
		imageCart.setImage(image);
		if(item.getColor().equals("WHITE"))
		chooseProductCard.setStyle("-fx-background-color: " + "#f5f5f5" + ";\n" + "-fx-background-radius: 30;");
		else
			chooseProductCard.setStyle("-fx-background-color: " + item.getColor() + ";\n" + "-fx-background-radius: 30;");
	}

}
